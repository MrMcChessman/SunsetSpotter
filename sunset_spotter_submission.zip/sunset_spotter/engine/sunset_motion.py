"""Sunset Score: the time slider.

Frames of the sunset a few minutes either side of the sunset instant, as two pictures per frame that are
drawn from one shared state:
    ground_<t>.png   the sky as seen from the ground, facing the sunset (sunset colours)
    top_<t>.png      the same clouds seen from above, with state outlines and the day / night boundary
    frames.json      what each frame is (minutes from sunset, local clock, sun height, ...)

What moves, and why it is not counted twice
  * The forecast: the model's hourly fields around sunset are cross-faded to the sunset instant (that is the
    score's own sky) and that field is carried on each layer's wind, back and forward in time.  The model's
    own hour-to-hour change is deliberately not replayed on top (blending two hourly snapshots along the wind
    makes ghost copies of every cloud), so nothing is counted twice.  Cells are 30 km, the squares they move
    over are 3 km, so a cell is free of its grid.
  * The satellite scan is carried from the scan time to the frame on the same winds (bilinear, so a slow
    layer glides instead of jumping a square), and loses potency with its age (sat_weights), as at sunset.
What is lit, and what colour
  * The sun's height and bearing come from the NOAA solar equations.  A cloud at height z sees the sun until
    the sun is below the horizon of its own ground point by the dip of that height (acos(R / (R + z))), so
    high cloud keeps the light longer than low cloud, and cloud toward the sun keeps it longer than cloud
    away from the sun (the Earth's shadow rises from the east).  Colour follows the sun's height AT THE
    CLOUD'S GROUND POINT (cream, gold, orange, red, rose, purple).  How much hue a cloud shows is the score's
    own decoration for it (sunset_lit), scaled by how lit it is and how low the sun is.
Views (see Timeline): the same state can be drawn as the sunset view, a data view (every layer in its own colour),
forecast-only or satellite-only (Timeline.frame(source=...)), with any subset of the cloud layers (only_layers); as
the reverse view (facing away from the sun: sky_extra draws the Earth's shadow and the Belt of Venus, anti_twilight),
as the straight-up fisheye (render_dome_view) and as the current moment (state["now"]).  The top-down map draws the
score's own regions (sunset wedge, opposite wedge, overhead disc, sight-line rays) at their real radii.
Not modelled: the gate (how much of the sun the low cloud lets through) is the sunset-instant value for every
frame, and the decoration of each region is the score's value at sunset (it does not change as the cloud
moves).  The light model is an estimate: nothing here has been checked against a live sunset.
"""
import datetime
import json
import math
import os

import sunset_v1_1 as s

R_KM = s.EARTH_RADIUS_KM
SUNSET_GEO_DEG = -0.833                    # sun centre's geometric height at the sunset instant (NOAA convention)
PENUMBRA_DEG = 0.54                        # the sun's own width: how gradually a cloud goes from lit to shadow
FRAME_MINUTES = tuple(range(-45, 31, 3))   # the slider: 45 minutes before sunset to 30 after, every 3
TOP_SCALE = 2                              # screen pixels per 3 km square on the top-down map
SHADE_LEVELS = (0.52, 0.80, 1.0)           # how dark cloud in shadow, in half light and in light is, if it has no hue
HUE_LEVELS = 3                             # steps of hue strength (beyond grey)
WARM_LEVELS = 5                            # steps of colour from cream (sun high) to purple (last light)
HUE_STOPS = ((0.00, (255, 232, 170)), (0.25, (255, 190, 90)), (0.50, (255, 130, 50)),
             (0.75, (226, 70, 86)), (1.00, (150, 50, 120)))
VIEW_NAMES = {"sunset": "SUNSET VIEW", "data": "DATA VIEW", "forecast": "FORECAST VIEW", "satellite": "SATELLITE VIEW"}
LAYER_WORD = {"low": "LOW", "mid": "MID", "high": "HIGH"}
NIGHT_GROUND = (7, 10, 18)
DAY_GROUND = (34, 48, 68)


# ------------------------------------------------------------------ the sun
def sun_geometry(lat, lon, when_utc):
    """(geometric elevation, bearing) of the sun in degrees at `when_utc` (NOAA solar equations)."""
    jd = when_utc.timestamp() / 86400.0 + 2440587.5
    t = (jd - 2451545.0) / 36525.0
    l0 = (280.46646 + t * (36000.76983 + t * 0.0003032)) % 360.0
    m = math.radians(357.52911 + t * (35999.05029 - 0.0001537 * t))
    ecc = 0.016708634 - t * (0.000042037 + 0.0000001267 * t)
    c = (math.sin(m) * (1.914602 - t * (0.004817 + 0.000014 * t)) + math.sin(2 * m) * (0.019993 - 0.000101 * t)
         + math.sin(3 * m) * 0.000289)
    omega = math.radians(125.04 - 1934.136 * t)
    app_long = math.radians(l0 + c - 0.00569 - 0.00478 * math.sin(omega))
    eps = math.radians(23.0 + (26.0 + (21.448 - t * (46.815 + t * (0.00059 - t * 0.001813))) / 60.0) / 60.0
                       + 0.00256 * math.cos(omega))
    decl = math.asin(math.sin(eps) * math.sin(app_long))
    y = math.tan(eps / 2.0) ** 2
    l0r = math.radians(l0)
    eqtime = 4.0 * math.degrees(y * math.sin(2 * l0r) - 2 * ecc * math.sin(m)
                                + 4 * ecc * y * math.sin(m) * math.cos(2 * l0r)
                                - 0.5 * y * y * math.sin(4 * l0r) - 1.25 * ecc * ecc * math.sin(2 * m))
    minutes = when_utc.hour * 60.0 + when_utc.minute + when_utc.second / 60.0
    hour_angle = math.radians(((minutes + eqtime + 4.0 * lon) % 1440.0) / 4.0 - 180.0)
    phi = math.radians(lat)
    sin_el = math.sin(phi) * math.sin(decl) + math.cos(phi) * math.cos(decl) * math.cos(hour_angle)
    el = math.degrees(math.asin(max(-1.0, min(1.0, sin_el))))
    az = math.degrees(math.atan2(math.sin(hour_angle),
                                 math.cos(hour_angle) * math.sin(phi) - math.tan(decl) * math.cos(phi))) + 180.0
    return el, az % 360.0


def apparent_elevation(geo_deg):
    """The sun's height as seen through the air (refraction lifts it about 0.6 degree at the horizon)."""
    if geo_deg < -1.0:
        return geo_deg + 0.65
    return geo_deg + 1.02 / math.tan(math.radians(geo_deg + 10.3 / (geo_deg + 5.11))) / 60.0


# ------------------------------------------------------------------ small helpers
def _lerp(a, b, k):
    return tuple(x + (y - x) * k for x, y in zip(a, b))


def _smooth(x, np):
    x = np.clip(x, 0.0, 1.0)
    return x * x * (3.0 - 2.0 * x)


def hue_at(u):
    """Cloud colour for warmth u in 0 (sun high: cream) .. 1 (last light: purple)."""
    u = max(0.0, min(1.0, u))
    for (u0, c0), (u1, c1) in zip(HUE_STOPS[:-1], HUE_STOPS[1:]):
        if u <= u1:
            return _lerp(c0, c1, (u - u0) / (u1 - u0))
    return HUE_STOPS[-1][1]


def _shift_int(a, dj, di, np, fill=0.0):
    """out[j, i] = a[j - dj, i - di] (squares not covered by the old array take `fill`)."""
    out = np.full(a.shape, fill, dtype=float)
    n0, n1 = a.shape
    if abs(dj) >= n0 or abs(di) >= n1:
        return out
    out[max(dj, 0):n0 + min(dj, 0), max(di, 0):n1 + min(di, 0)] = a[max(-dj, 0):n0 - max(dj, 0), max(-di, 0):n1 - max(di, 0)]
    return out


def advect(a, east_sq, north_sq, np, fill=0.0):
    """The field `a` ([north, east]) carried east_sq squares east and north_sq squares north (fractions allowed,
    bilinear): out[x] = a[x - shift]."""
    j0, i0 = int(math.floor(north_sq)), int(math.floor(east_sq))
    fj, fi = north_sq - j0, east_sq - i0
    out = (1 - fj) * (1 - fi) * _shift_int(a, j0, i0, np, fill)
    if fi > 1e-9:
        out = out + (1 - fj) * fi * _shift_int(a, j0, i0 + 1, np, fill)
    if fj > 1e-9:
        out = out + fj * (1 - fi) * _shift_int(a, j0 + 1, i0, np, fill)
        if fi > 1e-9:
            out = out + fj * fi * _shift_int(a, j0 + 1, i0 + 1, np, fill)
    return out


def frame_style(geo, app, gate):
    """The sunset picture's look at one moment: the sky and plain darken through twilight, the sun's colour and
    the warmth of the glow follow how low it is."""
    base = s.GROUND_STYLES["sunset"]
    q = max(0.0, min(1.0, (SUNSET_GEO_DEG - geo) / 5.2))            # 0 up to sunset, 1 at the end of civil twilight
    st = dict(base)
    st["sky_zenith"] = _lerp((30, 72, 160), (9, 16, 46), q)
    st["sky_horizon"] = _lerp((176, 210, 240), (86, 88, 132), q ** 0.8)
    st["glow_rgb"] = _lerp((255, 175, 115), (255, 120, 96), q)
    st["glow_k"] = 0.30 + 0.24 * math.sin(math.pi * min(1.0, 1.3 * q))
    st["ground_near"] = tuple(c * (1.0 - 0.68 * q) for c in base["ground_near"])
    st["ground_line"] = tuple(c * (1.0 - 0.55 * q) for c in base["ground_line"])
    st["ground_glow"] = base["ground_glow"] * (1.0 - 0.7 * q)
    st["sun_bright"] = (_lerp((255, 200, 90), (248, 96, 28), max(0.0, min(1.0, (6.0 - app) / 5.0))) if app > 1.0
                        else _lerp((248, 96, 28), (240, 66, 16), max(0.0, min(1.0, (1.0 - app) / 1.3))))
    st["sun_ring"] = (255, 190, 120)
    return st


# ------------------------------------------------------------------ the timeline
class Timeline:
    """Everything needed to build any frame of one query.  `inputs` is run(..., frames=True)["motion_inputs"]."""

    def __init__(self, inputs, np):
        self.np = np
        self.i = inputs
        self.lat, self.lon, self.az, self.elev = inputs["lat"], inputs["lon"], inputs["az"], inputs["elev_m"]
        self.sunset = inputs["sunset_utc"]
        self.tz = inputs["sunset_local"].tzinfo
        self.winds = inputs["winds"]
        sat = inputs.get("sat")
        self.sat = sat
        scene = sat.get("scene") if sat else None
        self.cells = s.scene_cells(scene, "observed", np) if scene else None
        self.scan_utc = sat["scan_utc"] if sat else None
        local = inputs["sunset_local"]
        self.hours = sorted(inputs["hours"])
        self.hour_utc = {h: datetime.datetime(local.year, local.month, local.day, h, tzinfo=self.tz)
                         .astimezone(datetime.timezone.utc) for h in self.hours}
        self.fc = {h: s.forecast_lattice(inputs["sky"][h], self.elev, np) for h in self.hours}
        self.base = self._forecast_base()
        n, step = s.GROUND_CELLS, s.GROUND_STEP_KM
        centre = (np.arange(n) - n / 2.0 + 0.5) * step
        self.east, self.north = np.meshgrid(centre, centre)             # [north, east]
        self.dist = np.hypot(self.east, self.north)
        self.bearing = np.arctan2(self.east, self.north)
        self.delta = self.dist / R_KM
        # the score's sunset bearing is an approximation; the drawn sun is nudged so that at sunset it stands on it
        self.az_bias = sun_geometry(self.lat, self.lon, self.sunset)[1] - self.az
        # how far out each layer's cloud top is visible: the radius of the score's wedges (as in score_sky)
        typical = inputs.get("typical")
        self.rad = {L: s.visibility_radius((typical[L][1] - self.elev) if typical else s.LAYER_HEIGHT_M[L], self.elev)
                    for L in s.LAYERS}
        self.rmax = max(self.rad.values())

    # ---- winds
    def _wind_sq(self, L, hours):
        """Squares (east, north) that layer L's wind moves cloud in `hours` hours."""
        if not self.winds:
            return 0.0, 0.0
        u, v = self.winds[L]
        return u * 3.6 * hours / s.GROUND_STEP_KM, v * 3.6 * hours / s.GROUND_STEP_KM

    # ---- the forecast at time t: the sunset-time forecast, carried on the wind
    def _forecast_base(self):
        """The forecast at the sunset instant: the two hourly fields around it, cross-faded (no motion)."""
        np = self.np
        times = [self.hour_utc[h] for h in self.hours]
        t = self.sunset
        if t <= times[0]:
            parts = [(1.0, self.hours[0])]
        elif t >= times[-1]:
            parts = [(1.0, self.hours[-1])]
        else:
            k = max(i for i in range(len(times) - 1) if times[i] <= t)
            w = (t - times[k]).total_seconds() / (times[k + 1] - times[k]).total_seconds()
            parts = [(1.0 - w, self.hours[k]), (w, self.hours[k + 1])]
        base = {}
        for L in s.LAYERS:
            cov, nb, nt = (np.zeros((s.GROUND_CELLS,) * 2) for _ in range(3))
            for wgt, h in parts:
                f, fb, ft = self.fc[h][L]
                cov += wgt * f
                nb += wgt * f * fb
                nt += wgt * f * ft
            safe = np.maximum(cov, 1e-9)
            base[L] = (cov, np.where(cov > 1e-6, nb / safe, 0.0), np.where(cov > 1e-6, nt / safe, 0.0))
        return base

    def forecast_at(self, t):
        """The forecast at time t.  The model's own hour-to-hour change is NOT replayed (an hourly snapshot
        cannot tell where its clouds came from, and blending two snapshots along the wind makes ghosts);
        the field at the sunset instant is carried on each layer's wind, so a 30 km cell is free of its grid
        and the picture at sunset is the score's own."""
        np = self.np
        out = {}
        hours = (t - self.sunset).total_seconds() / 3600.0
        for L, (f, fb, ft) in self.base.items():
            de, dn = self._wind_sq(L, hours)
            cov = advect(f, de, dn, np)
            nb, nt = advect(f * fb, de, dn, np), advect(f * ft, de, dn, np)
            safe = np.maximum(cov, 1e-9)
            out[L] = (np.clip(cov, 0.0, 1.0), np.where(cov > 1e-6, nb / safe, 0.0), np.where(cov > 1e-6, nt / safe, 0.0))
        return out

    # ---- the scan at time t: carried from the scan time on each layer's wind
    def cells_at(self, t):
        np = self.np
        if self.cells is None:
            return None, None, {"total": 0.0, "unshifted": 0.0, "shifted": 0.0}
        signed = (t - self.scan_utc).total_seconds() / 3600.0      # negative before the scan: wind runs backwards
        age = max(0.0, signed)                                      # trust only falls with age, never rises before it
        weights = s.sat_weights(age, have_winds=bool(self.winds))
        if not self.winds or signed == 0:
            return self.cells, None, weights
        c = self.cells
        moved = {"share": {}, "top": {}}
        known = np.zeros_like(c["known"])
        for L in s.LAYERS:
            de, dn = self._wind_sq(L, signed)
            sh = advect(c["share"][L], de, dn, np)
            num = advect(c["share"][L] * np.nan_to_num(c["top"][L]), de, dn, np)
            moved["share"][L] = sh
            moved["top"][L] = np.where(sh > 1e-9, num / np.maximum(sh, 1e-9), np.nan)
            known = np.maximum(known, advect(c["known"], de, dn, np))
        moved["known"] = np.clip(known, 0.0, 1.0)
        de, dn = self._wind_sq("mid", signed)
        moved["nohgt"] = np.clip(advect(c["nohgt"], de, dn, np), 0.0, 1.0)
        return c, moved, weights

    # ---- one frame
    def frame(self, minutes, source="fused"):
        """The state of the sky `minutes` after sunset (a float is fine).  source: "fused" (forecast and satellite
        united, as the score has them), "forecast" (the forecast alone) or "satellite" (the scan alone, carried on
        the wind: the cloud it could not see is missing)."""
        np = self.np
        t = self.sunset + datetime.timedelta(minutes=minutes)
        geo, sun_az = sun_geometry(self.lat, self.lon, t)
        app = apparent_elevation(geo)
        fl = self.forecast_at(t)
        cells, moved, weights = self.cells_at(t)
        if source == "satellite" and cells is None:
            raise ValueError("there is no satellite scan for this query")
        if cells is None or source == "forecast":
            none = {"share": {L: np.zeros((s.GROUND_CELLS,) * 2) for L in s.LAYERS},
                    "top": {L: np.full((s.GROUND_CELLS,) * 2, np.nan) for L in s.LAYERS},
                    "known": np.zeros((s.GROUND_CELLS,) * 2), "nohgt": np.zeros((s.GROUND_CELLS,) * 2)}
            lat = s.unify_lattice(fl, none, None, {"total": 0.0, "unshifted": 1.0, "shifted": 0.0}, self.elev, np)
            weights = {"total": 0.0, "unshifted": 1.0, "shifted": 0.0}
        elif source == "satellite":
            lat = s.unify_lattice(None, cells, moved, weights, self.elev, np, forecast=False)
        else:
            lat = s.unify_lattice(fl, cells, moved, weights, self.elev, np)
        state = {"minutes": minutes, "utc": t, "local": t.astimezone(self.tz), "geo": geo, "app": app,
                 "sun_az": sun_az, "lattice": lat, "weights": weights, "source": source}
        self._light(state)
        return state

    def only_layers(self, st, layers):
        """The state with every cloud layer that is not in `layers` taken out of the sky (None: all of them).
        The light (what is lit, and the hue) was worked out with the whole sky and is left as it was."""
        if not layers or set(layers) >= set(s.LAYERS):
            return st
        np = self.np
        lat = dict(st["lattice"])
        lat["cover"] = {L: (c if L in layers else np.zeros_like(c)) for L, c in st["lattice"]["cover"].items()}
        out = dict(st)
        out["lattice"] = lat
        return out

    def _light(self, st):
        """Per square and layer: how lit it is (Earth's shadow), the colour of the light, and the hue it shows."""
        np = self.np
        lat = st["lattice"]
        e, azs = math.radians(st["geo"]), math.radians(st["sun_az"])
        sin_loc = (math.sin(e) * np.cos(self.delta)
                   + math.cos(e) * np.cos(azs - self.bearing) * np.sin(self.delta))
        eloc = np.degrees(np.arcsin(np.clip(sin_loc, -1.0, 1.0)))             # sun's height at each ground point
        st["eloc"] = eloc
        warm = np.clip((6.0 - eloc) / 9.0, 0.0, 1.0)                           # 0 sun high .. 1 last light
        satur = _smooth((8.0 - eloc) / 7.0, np)                                # a high sun colours nothing
        dec = s.sunset_lit(lat, self.az, self.elev, self.i["detail"], self.i["gate"], np, sun_deg=st["app"])
        st["illum"], st["hue"], st["keys"] = {}, {}, {}
        n_grey = len(SHADE_LEVELS)
        for L in s.LAYERS:
            z_km = np.clip(np.nan_to_num(lat["bottom"][L] + self.elev, nan=0.0), 0.0, None) / 1000.0
            dip = np.degrees(np.arccos(R_KM / (R_KM + z_km)))
            margin = eloc + dip - SUNSET_GEO_DEG
            illum = _smooth(margin / PENUMBRA_DEG, np)
            hs = dec[L] * illum * satur
            hq = np.rint(np.clip((hs - s.GROUND_LIT_FLOOR) / (1.0 - s.GROUND_LIT_FLOOR), 0.0, 1.0) * HUE_LEVELS).astype(int)
            uq = np.rint(warm * (WARM_LEVELS - 1)).astype(int)
            sq = np.where(illum < 0.25, 0, np.where(illum < 0.75, 1, 2))
            keys = np.where(hq == 0, sq, n_grey + (np.maximum(hq, 1) - 1) * WARM_LEVELS + uq)
            st["illum"][L], st["hue"][L], st["keys"][L] = illum, hs, keys.astype(np.int16)

    def palette(self, L):
        np = self.np
        grey = np.array(s._GREY[L], dtype=float)
        shade = [grey * np.array(m) for m in ((SHADE_LEVELS[0] * 0.95, SHADE_LEVELS[0], SHADE_LEVELS[0] * 1.2),
                                              (SHADE_LEVELS[1] * 0.97, SHADE_LEVELS[1], SHADE_LEVELS[1] * 1.1),
                                              (1.0, 1.0, 1.0))]
        rows = list(shade)
        for h in range(1, HUE_LEVELS + 1):
            for u in range(WARM_LEVELS):
                rows.append(s._lit_shade(grey, np.array(hue_at(u / (WARM_LEVELS - 1)), dtype=float), h / HUE_LEVELS, np))
        return np.clip(np.array(rows), 0, 255)

    # ---- the pictures
    def _tag(self, layers):
        if not layers or set(layers) >= set(s.LAYERS):
            return ""
        return "  -  " + "+".join(LAYER_WORD[L] for L in s.LAYERS if L in layers) + " CLOUD ONLY"

    def _when(self, st):
        if st.get("now"):
            return "NOW  %s" % st["local"].strftime("%H:%M")
        m = st["minutes"]
        return "%s  SUNSET %s%d MIN" % (st["local"].strftime("%H:%M"), "+" if m >= 0 else "-", abs(round(m)))

    def ground_frame(self, st, view="sunset", layers=None, title_prefix=None, yaw=None):
        """The sky from the ground facing `yaw` (the sunset by default).  view: "sunset" (sunset colours),
        or "data" / "forecast" / "satellite" (every layer in its own colour; the state must have been made
        with the matching `source`).  layers: only these cloud layers are drawn."""
        np = self.np
        st = self.only_layers(st, layers)
        yaw = self.az if yaw is None else yaw
        w = st["weights"]["total"]
        if view == "sunset":
            style = frame_style(st["geo"], st["app"], self.i["gate"])
            keys = st["keys"]
            palette = {L: self.palette(L) for L in s.LAYERS}
            legend = [[(hue_at(u / (WARM_LEVELS - 1)), name) for u, name in
                       enumerate(("CREAM SUN HIGH", "GOLD", "ORANGE", "ROSE", "PURPLE LAST LIGHT"))]
                      + [((128, 132, 142), "GREY NOT DECORATED"), ((68, 72, 90), "IN SHADOW")]]
        else:
            style = dict(s.GROUND_STYLES["data"])
            keys = {L: np.zeros(st["lattice"]["cover"][L].shape, dtype=np.int16) for L in s.LAYERS}
            palette = {L: np.array([s.MASK_COLORS[2 + i]], dtype=float) for i, L in enumerate(s.LAYERS)}
            legend = [[(s.MASK_COLORS[2 + i], LAYER_WORD[L] + " CLOUD") for i, L in enumerate(s.LAYERS)]]
        frame = {"style": style, "keys": keys, "palette": palette, "sun_radius": 1.0}
        prefix = title_prefix or VIEW_NAMES[view]
        title = "%s%s  %.3f,%.3f  FACING %d  %s" % (prefix, self._tag(layers), self.lat, self.lon, round(yaw % 360),
                                                   self._when(st))
        sub = "SUN %.1f DEG  %s  SATELLITE WEIGHT %d%%" % (st["app"], "UP" if st["app"] > -0.5 else "DOWN", round(100 * w))
        boxes = np.zeros((0, s.GROUND_BOX_COLS))
        sun_az = st["sun_az"] - self.az_bias
        return s.render_ground_view(boxes, yaw, self.elev, sun_az, st["app"], self.i["gate"], title, sub,
                                    legend, np, lattice=st["lattice"], frame=frame)

    def reverse_frame(self, st, layers=None, view="sunset"):
        """The sky facing away from the sun, at the same height and field as the sunset view, with its own physics:
        the sun is behind the viewer, so cloud is lit from the front (a little brighter, no silhouettes against a
        glow); the Earth's shadow rises from the horizon (its top as high as the sun is deep, sinking away from
        the anti-solar bearing) with the pink Belt of Venus above it; and cloud goes dark from the horizon up,
        because the cloud far to the east lost the sun first (per square, as everywhere in this module)."""
        np = self.np
        if view != "sunset":                       # every layer in its own colour: no lighting, so no shadow either
            return self.ground_frame(st, view, layers, title_prefix="REVERSE " + VIEW_NAMES[view], yaw=(self.az + 180.0) % 360.0)
        st = self.only_layers(st, layers)
        yaw = (self.az + 180.0) % 360.0
        depression = max(0.0, -st["geo"])
        style = dict(frame_style(st["geo"], st["app"], self.i["gate"]))
        q = max(0.0, min(1.0, (SUNSET_GEO_DEG - st["geo"]) / 5.2))
        style["glow_k"] = 0.0
        style["sky_horizon"] = _lerp((172, 200, 232), (84, 86, 130), q ** 0.8)
        palette = {L: np.clip(self.palette(L) * 1.08 + 5.0, 0, 255) for L in s.LAYERS}

        def sky_extra(canvas, ppd, yaw_, w, h, dip, np_):
            el = s.GROUND_EL_MAX - (np_.arange(h) + 0.5) / ppd
            rel = (np_.arange(w) + 0.5 - w / 2.0) / ppd
            shadow, belt = s.anti_twilight(el[:, None], rel[None, :], depression, np_)
            canvas[:] = canvas * (1.0 - 0.75 * shadow[..., None]) + np_.array(s.SHADOW_RGB, dtype=float) * 0.75 * shadow[..., None]
            canvas[:] = canvas * (1.0 - 0.50 * belt[..., None]) + np_.array(s.BELT_RGB, dtype=float) * 0.50 * belt[..., None]

        frame = {"style": style, "keys": st["keys"], "palette": palette, "sun_radius": 1.0, "sky_extra": sky_extra}
        legend = [[(hue_at(u / (WARM_LEVELS - 1)), name) for u, name in
                   enumerate(("CREAM SUN HIGH", "GOLD", "ORANGE", "ROSE", "PURPLE LAST LIGHT"))]
                  + [((128, 132, 142), "GREY NOT DECORATED"), ((68, 72, 90), "IN SHADOW")],
                  [(s.SHADOW_RGB, "EARTH SHADOW"), (s.BELT_RGB, "BELT OF VENUS")]]
        title = "REVERSE VIEW AWAY FROM THE SUN%s  %.3f,%.3f  FACING %d  %s" % (
            self._tag(layers), self.lat, self.lon, round(yaw), self._when(st))
        sub = "SUN %.1f DEG  SHADOW TOP %.1f DEG ABOVE THE HORIZON AT THE ANTI-SOLAR POINT" % (st["app"], depression)
        boxes = np.zeros((0, s.GROUND_BOX_COLS))
        return s.render_ground_view(boxes, yaw, self.elev, st["sun_az"] - self.az_bias, st["app"], self.i["gate"],
                                    title, sub, legend, np, lattice=st["lattice"], frame=frame)

    def dome_frame(self, st, layers=None, view="sunset"):
        """The sky straight up, as a fisheye (render_dome_view), in sunset colours, or (view "data", "forecast",
        "satellite") with every layer in its own colour."""
        np = self.np
        st = self.only_layers(st, layers)
        if view == "sunset":
            frame = {"style": frame_style(st["geo"], st["app"], self.i["gate"]), "keys": st["keys"],
                     "palette": {L: self.palette(L) for L in s.LAYERS}}
            legend = [[(hue_at(u / (WARM_LEVELS - 1)), name) for u, name in
                       enumerate(("CREAM", "GOLD", "ORANGE", "ROSE", "PURPLE"))]
                      + [((128, 132, 142), "GREY NOT DECORATED"), ((68, 72, 90), "IN SHADOW")],
                      [(s.SHADOW_RGB, "EARTH SHADOW"), (s.BELT_RGB, "BELT OF VENUS")]]
        else:
            frame = {"style": dict(s.GROUND_STYLES["data"]),
                     "keys": {L: np.zeros(st["lattice"]["cover"][L].shape, dtype=np.int16) for L in s.LAYERS},
                     "palette": {L: np.array([s.MASK_COLORS[2 + i]], dtype=float) for i, L in enumerate(s.LAYERS)}}
            legend = [[(s.MASK_COLORS[2 + i], LAYER_WORD[L] + " CLOUD") for i, L in enumerate(s.LAYERS)]]
        title = "OVERHEAD VIEW%s  %s" % (self._tag(layers), self._when(st))
        sub = "CENTRE IS OVERHEAD  RIM IS THE HORIZON  N UP  E LEFT"
        return s.render_dome_view(st["lattice"], self.elev, st["sun_az"] - self.az_bias, st["app"], self.i["gate"], frame,
                                  title, sub, legend, np, depression=max(0.0, -st["geo"]))

    def top_frame(self, st, view="sunset", layers=None, yaw=None, scale=TOP_SCALE):
        """The clouds seen from above, north up, with what the score looks at drawn on them:
        orange wedge  the sunset direction, +-15 degrees, out to the farthest a cloud top can be seen
                      (short arcs mark how far low, mid and high cloud can be seen)
        cyan wedge    the sky away from the sun, the same size
        green disc    the sky overhead, 45 km
        red rays      the sun's line of sight (az-10, az, az+10): bright as far as low cloud is seen (the rain
                      and low-cloud average), thin on to the end of the sight line
        pale lines    the edges of the ground view (the field it shows, 100 degrees across)
    Cloud outside all three regions is dimmed: the score does not read it.  The sunset view also dims cloud that the
    Earth's shadow has reached; the other views draw every layer in its own colour."""
        np = self.np
        st = self.only_layers(st, layers)
        lat = st["lattice"]
        yaw = self.az if yaw is None else yaw
        n, S = s.GROUND_CELLS, scale
        night = np.array(NIGHT_GROUND, dtype=float)
        day = np.array(DAY_GROUND, dtype=float)
        f = _smooth((st["eloc"] + 6.0) / 8.0, np)[..., None]
        img = (night * (1 - f) + day * f)
        lit = view == "sunset"
        for i, L in enumerate(s.LAYERS):                                        # low first, high cloud on top
            cap = (0.80, 0.66, 0.52)[i]
            a = cap * (0.30 + 0.70 * lat["cover"][L]) * (1.0 - 0.40 * lat["sat"][L]) * (lat["cover"][L] > 0)
            shade = (0.38 + 0.62 * st["illum"][L])[..., None] if lit else 1.0
            col = np.array(s.MASK_COLORS[2 + i], dtype=float)[None, None, :] * shade
            img = img * (1 - a[..., None]) + col * a[..., None]
        deg = np.degrees(self.bearing)
        off_sun, off_anti = np.abs(s._wrap_deg(deg - self.az)), np.abs(s._wrap_deg(deg - (self.az + 180.0)))
        sun_reg = (off_sun <= s.WEDGE_HALF) & (self.dist <= self.rmax) & (self.dist > 0)
        anti_reg = (off_anti <= s.WEDGE_HALF) & (self.dist <= self.rmax) & (self.dist > 0)
        over_reg = self.dist <= s.OVERHEAD_KM
        img = np.where((sun_reg | anti_reg | over_reg)[..., None], img, img * 0.62)
        for mask, rgb in ((sun_reg, (255, 140, 0)), (anti_reg, (0, 220, 220)), (over_reg, (80, 230, 80))):
            img = np.where(mask[..., None], img * 0.90 + np.array(rgb, dtype=float) * 0.10, img)
        img = img[::-1]                                                         # north up
        img = np.repeat(np.repeat(img, S, axis=0), S, axis=1)
        east = st["eloc"][::-1] - SUNSET_GEO_DEG                               # sun's height above its setting height
        side = east >= 0.0
        edge = np.zeros(east.shape, dtype=bool)                                # the sunset line: where it changes sign
        edge[:-1] |= side[:-1] != side[1:]
        edge[:, :-1] |= side[:, :-1] != side[:, 1:]
        edge = np.repeat(np.repeat(edge, S, axis=0), S, axis=1)
        img = np.where(edge[..., None], img * 0.25 + np.array([255.0, 175.0, 80.0]) * 0.75, img).astype(np.uint8)
        reach = n * s.GROUND_STEP_KM / 2.0
        step = s.GROUND_STEP_KM
        to_px = lambda e, nn: ((reach - nn) / step * S, (e + reach) / step * S)
        self._context(img, to_px, reach, S)

        def polar(bearing, radius):
            b = math.radians(bearing)
            return to_px(radius * math.sin(b), radius * math.cos(b))

        def wedge(bearing, radius, half):
            pts = [polar(0, 0)] + [polar(bearing - half + k * 0.5, radius) for k in range(int(4 * half) + 1)]
            return [pts + [polar(0, 0)]]

        s._blend_lines(img, wedge(self.az, self.rmax, s.WEDGE_HALF), (255, 140, 0), 0.90, np)
        s._blend_lines(img, wedge(self.az + 180.0, self.rmax, s.WEDGE_HALF), (0, 220, 220), 0.90, np)
        s._blend_lines(img, [[polar(k * 1.5, s.OVERHEAD_KM) for k in range(0, 241)]], (80, 230, 80), 0.90, np)
        for i, L in enumerate(s.LAYERS):                                        # how far each layer can be seen
            rgb = s.MASK_COLORS[2 + i]
            s._blend_lines(img, [[polar(self.az - s.WEDGE_HALF + k * 0.5, self.rad[L]) for k in range(int(4 * s.WEDGE_HALF) + 1)]],
                           rgb, 0.85, np)
            r, c = polar(self.az + s.WEDGE_HALF + 2.5, self.rad[L])
            s._draw_text(img, int(r) - 3, int(c) - 2, LAYER_WORD[L][0], color=rgb, scale=1)
        far = [[polar(0, 0), polar(self.az + d, reach * 0.96)] for d in (-s.RAY_SPREAD_DEG, 0, s.RAY_SPREAD_DEG)]
        near = [[polar(0, 0), polar(self.az + d, self.rad["low"])] for d in (-s.RAY_SPREAD_DEG, 0, s.RAY_SPREAD_DEG)]
        s._blend_lines(img, far, (255, 60, 60), 0.35, np)
        s._blend_lines(img, near, (255, 60, 60), 0.90, np)
        dashes = []
        for edge_b in (yaw - s.GROUND_HFOV / 2.0, yaw + s.GROUND_HFOV / 2.0):  # the ground view's field, dashed
            for d0 in range(0, int(reach * 0.96), 24):
                dashes.append([polar(edge_b, d0), polar(edge_b, d0 + 12)])
        s._blend_lines(img, dashes, (255, 235, 190), 0.55, np)
        for k in range(-12, 13):                                                # the observer
            for r, c in ((to_px(k * 0.5, 0)), (to_px(0, k * 0.5))):
                img[int(r) - 1:int(r) + 1, int(c) - 1:int(c) + 1] = (255, 255, 255)
        sb = math.radians(st["sun_az"])
        r, c = to_px(reach * 0.93 * math.sin(sb), reach * 0.93 * math.cos(sb))
        yy, xx = np.mgrid[-5:6, -5:6]
        disc = (yy ** 2 + xx ** 2) <= 20
        ri, ci = int(r), int(c)
        if 6 <= ri < img.shape[0] - 6 and 6 <= ci < img.shape[1] - 6:
            img[ri - 5:ri + 6, ci - 5:ci + 6][disc] = (255, 205, 90) if st["app"] > -0.5 else (150, 110, 70)
        rows = [[(s.MASK_COLORS[2], "LOW CLOUD"), (s.MASK_COLORS[3], "MID CLOUD"), (s.MASK_COLORS[4], "HIGH CLOUD"),
                 ((90, 90, 100), "DIMMED: NOT SCORED"), ((255, 175, 80), "SUNSET LINE")],
                [((255, 140, 0), "SUNSET WEDGE"), ((0, 220, 220), "OPPOSITE WEDGE"),
                 ((80, 230, 80), "OVERHEAD DISC 45 KM"), ((255, 60, 60), "SUN RAYS"), ((255, 235, 190), "VIEW FIELD")]]
        head, foot = 46, 10 + 15 * len(rows)
        out = np.zeros((head + img.shape[0] + foot, img.shape[1], 3), dtype=np.uint8)
        out[head:head + img.shape[0]] = img
        s._draw_text(out, 6, 8, "TOP-DOWN %s%s  %s" % (VIEW_NAMES[view][:-5],
                                                       self._tag(layers), self._when(st)))
        s._draw_text(out, 26, 8, "SUN %.1f DEG  SUN AZIMUTH %d  WEDGES TO %d KM" % (st["app"], round(st["sun_az"]), round(self.rmax)),
                     color=(190, 200, 215))
        for r_i, row in enumerate(rows):
            col = 8
            top = head + img.shape[0] + 6 + r_i * 15
            for rgb, label in row:
                out[top:top + 10, col:col + 12] = rgb
                s._draw_text(out, top, col + 16, label, scale=1)
                col += 16 + 6 * len(label) + 18
        s._draw_text(out, head + 4, img.shape[1] - 20, "N", scale=2)
        return out

    def _context(self, img, to_px, reach, S):
        np = self.np
        rings = []
        for radius in (100, 200, 300, 400):
            rings.append([to_px(radius * math.sin(a / 40.0), radius * math.cos(a / 40.0))
                          for a in range(0, int(2 * math.pi * 40) + 2)])
        s._blend_lines(img, rings, (150, 170, 200), 0.18, np)
        for radius in (100, 200, 300, 400):
            r, c = to_px(radius * math.sin(math.radians(112)), radius * math.cos(math.radians(112)))
            s._draw_text(img, int(r) - 3, int(c) - 8, "%d" % radius, color=(120, 140, 170), scale=1)
        kx = s.KM_PER_DEG * math.cos(math.radians(self.lat))
        us, ca, labels = [], [], []
        for ab, country, lines in s.us_borders():
            inside = []
            for line in lines:
                px = []
                for la, lo in line:
                    e, nn = (lo - self.lon) * kx, (la - self.lat) * s.KM_PER_DEG
                    px.append(to_px(e, nn))
                    if abs(e) < reach * 0.92 and abs(nn) < reach * 0.92:
                        inside.append((e, nn))
                (us if country == "US" else ca).append(px)
            if len(inside) >= 8:
                labels.append((ab, sum(p[0] for p in inside) / len(inside), sum(p[1] for p in inside) / len(inside)))
        s._blend_lines(img, ca, (235, 235, 235), 0.30, np)
        s._blend_lines(img, us, (255, 255, 255), 0.55, np)
        for ab, e, nn in labels:
            r, c = to_px(e, nn)
            s._draw_text(img, int(r) - 4, int(c) - 3 * len(ab), ab, color=(205, 215, 230), scale=1)


# ------------------------------------------------------------------ files
def frame_name(kind, minutes):
    return "%s_%s%03d.png" % (kind, "m" if minutes < 0 else "p", abs(minutes))


def render_frames(inputs, out_dir, minutes=FRAME_MINUTES, np=None, log=print):
    """Write ground_*.png and top_*.png for each minute offset, and frames.json.  Returns the metadata list."""
    if np is None:
        import numpy as np
    os.makedirs(out_dir, exist_ok=True)
    tl = Timeline(inputs, np)
    meta = []
    for mi in minutes:
        st = tl.frame(mi)
        s._write_png(os.path.join(out_dir, frame_name("ground", mi)), tl.ground_frame(st), np)
        s._write_png(os.path.join(out_dir, frame_name("top", mi)), tl.top_frame(st), np)
        meta.append({"minutes": mi, "local": st["local"].strftime("%H:%M"), "sun_elevation": round(st["app"], 2),
                     "satellite_weight": round(st["weights"]["total"], 3),
                     "ground": frame_name("ground", mi), "top": frame_name("top", mi)})
        log("frame %+d min  sun %.1f deg" % (mi, st["app"]))
    with open(os.path.join(out_dir, "frames.json"), "w") as fh:
        json.dump({"lat": inputs["lat"], "lon": inputs["lon"], "sunset_local": inputs["sunset_local"].strftime("%H:%M"),
                   "azimuth": round(inputs["az"], 1), "frames": meta}, fh)
    return meta
