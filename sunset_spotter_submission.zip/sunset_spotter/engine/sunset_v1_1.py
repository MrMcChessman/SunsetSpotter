#!/usr/bin/env python3
"""Sunset Score v1.1 -- one location, one date, one score.

    python sunset_v1_1.py                          (asks for lat / lon / date)
    python sunset_v1_1.py 41.4278 -74.1654 2026-11-06

Pipeline (see the HackRPI build guide):
    sun geometry -> forecast sky grid (NOAA GFS, or Open-Meteo as a fallback)
    -> gate x decoration -> range over the hours around sunset -> confidence
    -> optional GOES satellite check (cloud heights, dapple, infrared texture)
    -> short explanation.

New in 1.1: the GFS cloud base/top heights place every layer in the vertical,
so the gate is the sight line to the sun (cloud at the sun's own height blocks
it, cloud above it decorates), and the satellite adds a small infrared
cloud-top roughness term.

Pictures (these need numpy, which the satellite step installs anyway; they are written to
the folder the program is run from and replaced by every query):
    masked_result.png  forecast_result.png  ground_view.png  and the folder Masks/
    ground_view.png is the sky as seen from the ground, facing the sunset: forecast and
    satellite united as translucent boxes on a shared 3 km grid (blue low, amber mid,
    magenta high) over a flat plain; ground_sunset_view.png is the same sky in sunset colours.
    --no-masks skips every picture, --no-ground skips only the ground views.

Everything except the satellite step uses only the standard library.  The
satellite step needs  pip install netCDF4  and is skipped (with a note) if
that package is missing or the data cannot be reached.

Network access is isolated in three injectable functions (fetch_json,
goes_get_text, goes_get_file) so the whole program can be tested offline.
"""
import datetime
import glob
import json
import math
import os
import re
import statistics
import sys
import time
import urllib.error
import urllib.request

# ----------------------------------------------------------------- constants
# Grid: 31 x 31 cells, 30 km apart, centred on the observer (+-450 km).
SPACING_KM = 30
N = 15
SIZE = 2 * N + 1
OBS = (N, N)                       # the observer is always the middle cell
KM_PER_DEG = 111.0

CLOUDY = 0.5                       # coverage at/above this counts as cloudy
WEDGE_HALF = 15                    # sunset direction +- this many degrees
OVERHEAD_KM = 45                   # radius of the overhead disc
LAYERS = ("low", "mid", "high")
LAYER_HEIGHT_M = {"low": 1000.0, "mid": 3000.0, "high": 10000.0}

W_FWD = {"low": 0.2, "mid": 0.3, "high": 0.5}
W_OVER = {"low": 0.2, "mid": 0.3, "high": 0.5}
W_ANTI = {"low": 0.1, "mid": 0.3, "high": 0.6}
LAYER_WEIGHTS = {"fwd": W_FWD, "over": W_OVER, "anti": W_ANTI}
R_WEIGHT = {"fwd": 0.55, "over": 0.25, "anti": 0.20}
REGION_NAMES = {"fwd": "sunset direction", "over": "overhead",
                "anti": "opposite (eastern) sky"}

TEXTURE_WEIGHT = 0.5               # how much dapple matters inside a layer
BASE = 0.25                        # floor for a visible sun, nothing to light
GATE_OPEN = 0.5                    # sun hidden by this share or less: gate = 1 (half the disc is plenty)
GATE_LOG_K = 20.0                  # bend of the gate curve: bigger = a sliver of sun earns more
GATE_SHUT = 0.03                   # sun showing less than this share counts as wholly hidden (sampling noise)
COVER_OPEN = 0.5                   # cover-fraction gate (v1 fallback + satellite): mean low cover at/below: gate = 1
COVER_CLOSED = 0.9                 # ... at/above this: gate = 0
RAIN_LIMIT = 0.5                   # mm/h along the sun direction
RAIN_FACTOR = 0.25

RAY_STEP_KM = 10                   # gate sampling: points along each ray
RAY_SPREAD_DEG = 10                # rays at az-10, az, az+10

CHUNK = 100                        # places per Open-Meteo request
RATE_PER_MIN = 450                 # Open-Meteo counts every PLACE as one call (free: 600/min)
RATE_WAIT_S = 65                   # wait this long after a "minutely limit" reply
_sleep = time.sleep                # replaced by tests
_clock = time.monotonic
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
HISTORICAL_URL = "https://historical-forecast-api.open-meteo.com/v1/forecast"
FORECAST_RECENT_DAYS = 80          # older dates go to the historical endpoint
TIMEZONE = "America/New_York"      # v1.1 is New York only

FORECAST_HORIZON_H = 18            # fine-scale model look-ahead
SAT_WINDOW_H = 3                   # live satellite check only this close
LOW_TOP_M = 3700.0                 # cloud tops below this count as "low"   (GFS: below ~642 hPa)
MID_TOP_M = 8100.0                 # tops below this (and above LOW_TOP_M) are "mid"; above, "high" (~350 hPa)
SAT_THICKNESS_M = {"low": 2000.0, "mid": 1800.0, "high": 2300.0}   # assumed depth below a satellite-measured cloud top
# Wind-shifted satellite: scans are carried to sunset on the model's steering
# wind, and trusted less the older they are (clouds form and dissipate; drift
# error grows with time).  Weights by scan age a, in hours:
#   total satellite potency  S(a) = FLOOR + (1 - FLOOR) * (1 - (a / SAT_FADE_H) ** SAT_FADE_POWER)   (FLOOR beyond SAT_FADE_H;
#                            a higher power keeps a fresh scan near full weight for longer)
#   share kept by the UNSHIFTED picture ("the same area stays cloudy")
#     p(a) = SHIFT_PERSIST_MAX * min(1, a / SAT_FADE_H);  shifted gets 1 - p(a)
SAT_FADE_H = 3.0
SAT_FLOOR = 0.4                    # a scan never drops below this share of its weight (decks persist)
SAT_FADE_POWER = 3.0
SHIFT_PERSIST_MAX = 0.25
SAT_GATE_MAX_W = 0.5               # most the satellite gate may pull the forecast gate (at a = 0)
GFS_WIND_VARS = ("u-component_of_wind_isobaric", "v-component_of_wind_isobaric")
WIND_LEVEL_HPA = {"low": 850.0, "mid": 550.0, "high": 250.0}   # steering level of each layer
SAT_STEP_KM = 3.0                  # spacing of the satellite sample grid for dapple (about 1 pixel)
GOES_URL = "https://noaa-goes19.s3.amazonaws.com/"
GOES_MASK_PRODUCT = "ABI-L2-ACMC"
GOES_HEIGHT_PRODUCT = "ABI-L2-ACHAC"
GOES_IR_PRODUCT = "ABI-L2-CMIPC"   # cloud and moisture imagery; band 13 is the 10.3 micron window
GOES_IR_BAND = "C13_"
IR_CLOUD_K = 265.0                 # window-band brightness temperature below this = cold cloud top
IR_SMOOTH_K = 0.7                  # mean neighbour-to-neighbour change of a smooth overcast
IR_ROUGH_K = 2.0                   # ... of a rippled, broken deck
IR_MIN_PAIRS = 40                  # fewer neighbouring cold-cloud pixel pairs than this: no reading
USER_AGENT = "sunset-score/1.1 (HackRPI project)"
GFS_URL = "https://thredds.ucar.edu/thredds/ncss/grid/grib/NCEP/GFS/Global_0p25deg/Best"
GFS_CLOUD_VARS = {"low": "Low_cloud_cover_low_cloud", "mid": "Medium_cloud_cover_middle_cloud",
                  "high": "High_cloud_cover_high_cloud"}
GFS_EXTRA_VARS = ("Precipitation_rate_surface", "Geopotential_height_surface")
GFS_CACHE_HOURS = 3                # a new model run lands every 6 h; reuse a download this long
GFS_MARGIN_DEG = 0.6               # box margin so edge cells can be interpolated

# v1.1 "cloud cube": the model's own cloud base / top pressure for each layer.
# These exist only as interval averages (3 h and 6 h means; a new reference time
# every 6 h), so the cloud covers are taken from the same family for consistency.
CUBE_SUFFIX = "_Mixed_intervals_Average"
GFS_CUBE_COVER = {"low": "Low_cloud_cover_low_cloud" + CUBE_SUFFIX,
                  "mid": "Medium_cloud_cover_middle_cloud" + CUBE_SUFFIX,
                  "high": "High_cloud_cover_high_cloud" + CUBE_SUFFIX}
_PRESSURE_WORD = {"low": "low", "mid": "middle", "high": "high"}
GFS_CUBE_PRESSURE = {(L, edge): "Pressure_%s_cloud_%s%s" % (_PRESSURE_WORD[L], edge, CUBE_SUFFIX)
                     for L in ("low", "mid", "high") for edge in ("bottom", "top")}
GFS_CUBE_PRECIP = "Precipitation_rate_surface" + CUBE_SUFFIX
GFS_ELEVATION_VAR = "Geopotential_height_surface"
DEFAULT_LAYER_ASL_M = {"low": (500.0, 2500.0), "mid": (3800.0, 5500.0),
                       "high": (8200.0, 10500.0)}     # used where the model has no cloud to measure

# Sight-line geometry (all angles in degrees, measured up from the observer's
# horizontal).  At sunset the sun's upper limb touches the horizon, so its
# centre is half a disc below it.
EARTH_RADIUS_KM = 6371.0
REFRACTION_K = 0.13                # terrestrial refraction: curvature drop is (1-k) d / 2R
SUN_HALF_DEG = 0.27                # half the sun's apparent diameter
SUN_REF_DEG = -SUN_HALF_DEG        # sun centre at the instant of sunset
SIGHT_SLICES = 9                   # the sun disc is tested in this many horizontal slices
CORR_KM = 30.0                     # cloud seen at samples closer than this is the same cloud
SIGHT_OPACITY = {"low": 1.0, "mid": 0.6, "high": 0.15}   # how much of its cover actually hides the sun
SIGHT_MAX_KM = 450                 # how far along the sun's direction the sight line is followed
GRID_REACH_KM = 700                # farther than any grid cell
SKY_WEIGHTING = True               # decoration cover = share of the sky, not of the ground cells
IR_MAX = 0.10                      # most that infrared texture may add to a region's value


class SatelliteUnavailable(Exception):
    """The live GOES check could not be done (reason in the message)."""


# ------------------------------------------------------------ Step 1: the sun
def day_of_year(year, month, day):
    return datetime.date(year, month, day).timetuple().tm_yday


def declination(n_day):
    """Solar declination in degrees (simple one-line approximation)."""
    return -23.44 * math.cos(math.radians(360.0 / 365.0 * (n_day + 10)))


def sunset_azimuth(lat, year, month, day):
    """Compass bearing (deg clockwise from north) where the sun sets."""
    d = math.radians(declination(day_of_year(year, month, day)))
    x = math.sin(d) / math.cos(math.radians(lat))
    x = max(-1.0, min(1.0, x))             # rounding must never crash acos
    return 360.0 - math.degrees(math.acos(x))


def eastern_utc_offset_hours(date):
    """-4 during US daylight time, else -5 (2nd Sun Mar .. 1st Sun Nov).
    Sunset is always after the 2 AM switch, so the date alone decides."""
    def nth_sunday(year, month, nth):
        first = datetime.date(year, month, 1)
        shift = (6 - first.weekday()) % 7          # days to the first Sunday
        return first + datetime.timedelta(days=shift + 7 * (nth - 1))
    start = nth_sunday(date.year, 3, 2)
    end = nth_sunday(date.year, 11, 1)
    return -4 if start <= date < end else -5


def sunset_time_utc(lat, lon, date):
    """Sunset instant (aware UTC datetime) from the NOAA solar equations.
    lon is degrees east (negative in New York).  Accurate to about a minute.
    """
    # (A shorter "fractional year" series was tried first and drifted by up to
    #  2 minutes; the Julian-century form below stays within about a minute.)
    jd0 = date.toordinal() + 1721424.5          # Julian day at 0h UTC of `date`
    hour_utc = 12.0 - lon / 15.0 + 6.0          # first guess: ~6 PM local
    minutes = 0.0
    for _ in range(3):                           # converge on the sunset instant
        t = (jd0 + hour_utc / 24.0 - 2451545.0) / 36525.0
        l0 = (280.46646 + t * (36000.76983 + t * 0.0003032)) % 360.0
        m = math.radians(357.52911 + t * (35999.05029 - 0.0001537 * t))
        ecc = 0.016708634 - t * (0.000042037 + 0.0000001267 * t)
        c = (math.sin(m) * (1.914602 - t * (0.004817 + 0.000014 * t))
             + math.sin(2 * m) * (0.019993 - 0.000101 * t)
             + math.sin(3 * m) * 0.000289)
        omega = math.radians(125.04 - 1934.136 * t)
        app_long = math.radians(l0 + c - 0.00569 - 0.00478 * math.sin(omega))
        eps = math.radians(23.0 + (26.0 + (21.448 - t * (46.815 + t * (0.00059 - t * 0.001813)))
                                    / 60.0) / 60.0 + 0.00256 * math.cos(omega))
        decl = math.asin(math.sin(eps) * math.sin(app_long))
        y = math.tan(eps / 2.0) ** 2
        l0r = math.radians(l0)
        eqtime = 4.0 * math.degrees(
            y * math.sin(2 * l0r) - 2 * ecc * math.sin(m)
            + 4 * ecc * y * math.sin(m) * math.cos(2 * l0r)
            - 0.5 * y * y * math.sin(4 * l0r) - 1.25 * ecc * ecc * math.sin(2 * m))
        phi = math.radians(lat)
        cos_ha = (math.cos(math.radians(90.833)) / (math.cos(phi) * math.cos(decl))
                  - math.tan(phi) * math.tan(decl))
        cos_ha = max(-1.0, min(1.0, cos_ha))
        ha = math.degrees(math.acos(cos_ha))
        minutes = 720.0 - 4.0 * (lon - ha) - eqtime
        hour_utc = minutes / 60.0
    midnight = datetime.datetime(date.year, date.month, date.day,
                                 tzinfo=datetime.timezone.utc)
    return midnight + datetime.timedelta(minutes=minutes)


def sunset_local(lat, lon, date):
    """(local_aware_datetime, utc_aware_datetime) of sunset on `date`."""
    utc = sunset_time_utc(lat, lon, date)
    tz = datetime.timezone(datetime.timedelta(hours=eastern_utc_offset_hours(date)))
    return utc.astimezone(tz), utc


def sunset_hours(local_dt):
    """The sunset hour and one hour either side, e.g. 16:39 -> [16, 17, 18]."""
    h = round(local_dt.hour + local_dt.minute / 60.0)
    return [x for x in (h - 1, h, h + 1) if 0 <= x <= 23]


# ------------------------------------------------- Step 2: flat-map geometry
def km_to_latlon(lat0, lon0, east_km, north_km):
    lat = lat0 + north_km / KM_PER_DEG
    lon = lon0 + east_km / (KM_PER_DEG * math.cos(math.radians(lat0)))
    return lat, lon


def offset_point(lat0, lon0, bearing, dist_km):
    b = math.radians(bearing)
    return km_to_latlon(lat0, lon0, dist_km * math.sin(b), dist_km * math.cos(b))


def cell_latlon(lat0, lon0, r, c):
    return km_to_latlon(lat0, lon0, (c - N) * SPACING_KM, (N - r) * SPACING_KM)


# ------------------------------------------------------ Step 3: visibility
def visibility_radius(height_m, elev_m=0.0):
    """km out to which a cloud top at height_m is visible from elev_m."""
    return 3.9 * (math.sqrt(max(height_m, 0.0)) + math.sqrt(max(elev_m, 0.0)))


# ------------------------------------------------ Step 4: the forecast data
def grid_points(lat0, lon0):
    """961 (lat, lon) pairs, row-major (row 0 = northern edge)."""
    return [cell_latlon(lat0, lon0, r, c) for r in range(SIZE) for c in range(SIZE)]


def _http_get(url, timeout=60, retries=3):
    """GET with a few polite retries; returns the body as text."""
    last = None
    for attempt in range(retries):
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read().decode("utf-8")
        except urllib.error.HTTPError as err:
            body = err.read().decode("utf-8", "replace")[:300]
            last = RuntimeError("HTTP %d from %s: %s" % (err.code, url[:80], body))
            if err.code == 429 or err.code not in (500, 502, 503, 504):
                raise last          # a bad request will not improve; 429 is handled by the caller
        except (urllib.error.URLError, TimeoutError, OSError) as err:
            last = RuntimeError("network error for %s: %s" % (url[:80], err))
        time.sleep(1.5 * (attempt + 1))
    raise last


def http_get_json(url, log=print):
    for attempt in range(4):
        try:
            text = _http_get(url)
            break
        except RuntimeError as err:
            if "HTTP 429" in str(err) and "inutely" in str(err) and attempt < 3:
                log("Open-Meteo minute limit reached; waiting %d s ..." % RATE_WAIT_S)
                _sleep(RATE_WAIT_S)
                continue
            raise
    data = json.loads(text)
    if isinstance(data, dict) and data.get("error"):
        raise RuntimeError("Open-Meteo says: %s" % data.get("reason", data))
    return data


def open_meteo_url(points, date_str, today=None):
    today = today or datetime.date.today()
    day = datetime.date.fromisoformat(date_str)
    base = HISTORICAL_URL if (today - day).days > FORECAST_RECENT_DAYS else FORECAST_URL
    lats = ",".join("%.4f" % p[0] for p in points)
    lons = ",".join("%.4f" % p[1] for p in points)
    return ("%s?latitude=%s&longitude=%s"
            "&hourly=cloud_cover_low,cloud_cover_mid,cloud_cover_high,precipitation"
            "&timezone=%s&start_date=%s&end_date=%s"
            % (base, lats, lons, TIMEZONE, date_str, date_str))


def hour_index(times, hour):
    """Position of local hour `hour` in Open-Meteo's list of 'YYYY-MM-DDTHH:MM'
    strings (searching, rather than assuming index == hour, is safe on
    daylight-saving days too)."""
    suffix = "T%02d:00" % hour
    for i, t in enumerate(times):
        if t.endswith(suffix):
            return i
    raise ValueError("hour %d not in response (times start %s)" % (hour, times[:2]))


def _clean(v, scale=1.0):
    if v is None:
        return 0.0
    v = float(v) * scale
    return 0.0 if math.isnan(v) else v


def parse_responses(responses, hours):
    """List of 961 Open-Meteo place dictionaries -> (sky, elev).

    sky[h]['low'|'mid'|'high'|'precip'] are 31x31 lists of lists (cloud as a
    0..1 fraction, precipitation in mm); elev is a 31x31 list in metres.
    """
    if len(responses) != SIZE * SIZE:
        raise ValueError("expected %d places, got %d" % (SIZE * SIZE, len(responses)))
    keys = {"low": "cloud_cover_low", "mid": "cloud_cover_mid",
            "high": "cloud_cover_high", "precip": "precipitation"}
    sky = {h: {k: [[0.0] * SIZE for _ in range(SIZE)] for k in keys} for h in hours}
    elev = [[0.0] * SIZE for _ in range(SIZE)]
    idx = None
    for i, place in enumerate(responses):
        r, c = divmod(i, SIZE)
        hourly = place["hourly"]
        if idx is None:
            idx = {h: hour_index(hourly["time"], h) for h in hours}
        elev[r][c] = _clean(place.get("elevation"))
        for h in hours:
            for k, name in keys.items():
                vals = hourly[name]
                scale = 1.0 if k == "precip" else 0.01
                v = _clean(vals[idx[h]], scale)
                sky[h][k][r][c] = v if k == "precip" else min(1.0, max(0.0, v))
    return sky, elev


def fetch_sky(lat0, lon0, date_str, hours, cache_dir="cache",
              fetch_json=None, today=None, log=print):
    """Download (or load from cache) the 961-place forecast; return (sky, elev)."""
    real_network = fetch_json is None
    fetch_json = fetch_json or http_get_json
    cache = os.path.join(cache_dir, "openmeteo_%.4f_%.4f_%s.json" % (lat0, lon0, date_str))
    part = cache + ".part"                          # progress of an interrupted download
    if os.path.exists(cache):
        log("Using cached forecast: %s" % cache)
        with open(cache) as f:
            responses = json.load(f)
    else:
        points = grid_points(lat0, lon0)
        responses = []
        if os.path.exists(part):
            with open(part) as f:
                responses = json.load(f)
            log("Resuming download: %d of %d places already saved" % (len(responses), len(points)))
        sent = []                                   # (time, places) of recent requests
        os.makedirs(cache_dir, exist_ok=True)
        try:
            for start in range(len(responses), len(points), CHUNK):
                chunk = points[start:start + CHUNK]
                if real_network:                    # every place counts as one call
                    now = _clock()
                    sent = [(t0, n) for t0, n in sent if now - t0 < 60]
                    if sent and sum(n for _, n in sent) + len(chunk) > RATE_PER_MIN:
                        wait = 61 - (now - sent[0][0])
                        log("Pausing %d s to respect Open-Meteo's per-minute limit ..." % wait)
                        _sleep(wait)
                        sent = []
                    sent.append((_clock(), len(chunk)))
                data = fetch_json(open_meteo_url(chunk, date_str, today))
                if isinstance(data, dict):          # a single place is a dict
                    data = [data]
                if len(data) != len(chunk):
                    raise RuntimeError("asked for %d places, got %d back"
                                       % (len(chunk), len(data)))
                responses.extend(data)
        except BaseException:                       # error or Ctrl-C: keep what we have
            if responses:
                with open(part, "w") as f:
                    json.dump(responses, f)
            raise
        tmp = cache + ".tmp"
        with open(tmp, "w") as f:
            json.dump(responses, f)
        os.replace(tmp, cache)
        if os.path.exists(part):
            os.remove(part)
    return parse_responses(responses, hours)


# ------------------------------------- Step 4 (alternative): NOAA GFS grid
# One NetCDF Subset Service request returns the whole region for every layer,
# so there is no per-place cost.  Open-Meteo is itself interpolation of model
# grids like this one.
def gfs_url(lat0, lon0, start_utc, end_utc, extras=True, cube=True, names=None):
    """NCSS request for the box around the observer.  cube=True asks for the
    interval-average family (cover, cloud base/top pressure, precipitation);
    cube=False asks for the plain instantaneous cover fields (v1 behaviour)."""
    dlat = N * SPACING_KM / KM_PER_DEG + GFS_MARGIN_DEG
    dlon = dlat / math.cos(math.radians(lat0))
    if names is not None:
        pass
    elif cube:
        names = (list(GFS_CUBE_COVER.values()) + [GFS_CUBE_PRECIP]
                 + list(GFS_CUBE_PRESSURE.values()) + ([GFS_ELEVATION_VAR] if extras else []))
    else:
        names = list(GFS_CLOUD_VARS.values()) + (list(GFS_EXTRA_VARS) if extras else [])
    fmt = "%Y-%m-%dT%H:%M:%SZ"
    return ("%s?%s&north=%.3f&south=%.3f&east=%.3f&west=%.3f&horizStride=1"
            "&time_start=%s&time_end=%s&accept=netcdf4"
            % (GFS_URL, "&".join("var=" + n for n in names), lat0 + dlat, lat0 - dlat,
               lon0 + dlon, lon0 - dlon, start_utc.strftime(fmt), end_utc.strftime(fmt)))


def gfs_elevation_url(lat0, lon0, when_utc):
    """Terrain height alone (one time step), for when the big request had to drop it."""
    return gfs_url(lat0, lon0, when_utc, when_utc, names=[GFS_ELEVATION_VAR])


def _time_base(var):
    """('Hour since 2026-11-01T00:00:00Z') -> (aware UTC base, seconds per unit)."""
    m = re.match(r"\s*(\w+?)s?\s+since\s+(\S+)", var.units, re.I)
    if not m:
        raise RuntimeError("cannot read the time units %r" % var.units)
    unit = {"hour": 3600.0, "minute": 60.0, "day": 86400.0, "second": 1.0}[m.group(1).lower()]
    stamp = m.group(2).rstrip("Z")
    if "T" not in stamp:
        stamp += "T00:00:00"
    return datetime.datetime.fromisoformat(stamp).replace(tzinfo=datetime.timezone.utc), unit


def _gfs_times(ds, dim="time"):
    """A time axis as aware UTC datetimes."""
    var = ds.variables[dim]
    base, unit = _time_base(var)
    return [base + datetime.timedelta(seconds=float(v) * unit) for v in var[:]]


def _gfs_intervals(ds, name):
    """[(index, start, end)] for each time step of variable `name`.  Interval
    averages carry bounds (the window they average over); other fields are
    instants (start == end)."""
    dim = ds.variables[name].dimensions[0]
    centres = _gfs_times(ds, dim)
    bname = getattr(ds.variables[dim], "bounds", dim + "_bounds")
    if bname not in ds.variables:
        return [(i, t, t) for i, t in enumerate(centres)]
    base, unit = _time_base(ds.variables[dim])
    b = ds.variables[bname][:]
    return [(i, base + datetime.timedelta(seconds=float(b[i][0]) * unit),
             base + datetime.timedelta(seconds=float(b[i][1]) * unit)) for i in range(len(centres))]


def _three_hour_bins(intervals):
    """Interval averages -> 3-hour windows [(start, end, parts)] sorted by time.

    The model stores a 3 h mean and a 6 h mean from the same reference time, so
    the second half of the 6 h window is  2 * mean6 - mean3  (exact for any
    quantity that averages linearly: cloud cover, precipitation rate).
    `parts` is (index,) for a stored window or (index6, index3) for a derived one.
    If there are no 3 h windows at all, the stored windows are used as they are."""
    h3 = datetime.timedelta(hours=3)
    close = lambda a, b, span: abs((b - a - span).total_seconds()) < 60
    three = [(i, a, b) for i, a, b in intervals if close(a, b, h3)]
    six = [(i, a, b) for i, a, b in intervals if close(a, b, 2 * h3)]
    bins = {a: (a, b, (i,)) for i, a, b in three}
    for i6, a6, b6 in six:
        for i3, a3, b3 in three:
            if a3 == a6 and a6 + h3 not in bins:
                bins[a6 + h3] = (a6 + h3, b6, (i6, i3))
    if not bins:
        bins = {a: (a, b, (i,)) for i, a, b in intervals}
    return [bins[k] for k in sorted(bins)]


def _pick_interval(intervals, when):
    """Index of the narrowest averaging window containing `when` (else the nearest)."""
    inside = [(b - a, i) for i, a, b in intervals if a <= when < b]
    if not inside:
        inside = [(b - a, i) for i, a, b in intervals if a <= when <= b]
    if inside:
        return min(inside)[1]
    return min(intervals, key=lambda t: abs((t[1] + (t[2] - t[1]) / 2 - when).total_seconds()))[0]


def _gfs_nearest(arr2d, rows, cols):
    """Nearest-cell sample at the 961 positions; None where the model has no value."""
    import numpy as np
    a = np.ma.filled(arr2d, np.nan).astype(float)
    out = [[None] * SIZE for _ in range(SIZE)]
    for r in range(SIZE):
        for c in range(SIZE):
            v = float(a[min(a.shape[0] - 1, max(0, int(round(rows[r][c])))),
                        min(a.shape[1] - 1, max(0, int(round(cols[r][c]))))])
            out[r][c] = None if math.isnan(v) else v
    return out


def pressure_to_height_m(p_pa):
    """Height above sea level from pressure (standard atmosphere)."""
    return 44330.77 * (1.0 - (p_pa / 101325.0) ** 0.190263)




def _axis_position(axis, value):
    """Fractional index of `value` on a monotonic axis (works if descending)."""
    n = len(axis)
    if axis[0] > axis[-1]:
        axis = axis[::-1]
        flip = True
    else:
        flip = False
    pos = None
    if value <= axis[0]:
        pos = 0.0
    elif value >= axis[-1]:
        pos = float(n - 1)
    else:
        lo = 0
        while axis[lo + 1] < value:
            lo += 1
        pos = lo + (value - axis[lo]) / (axis[lo + 1] - axis[lo])
    return (n - 1 - pos) if flip else pos


def _gfs_layer(arr2d, rows, cols):
    """Bilinear-sample a (lat, lon) array at the 961 fractional positions."""
    grid = [[float(v) for v in row] for row in arr2d]
    out = [[0.0] * SIZE for _ in range(SIZE)]
    for r in range(SIZE):
        for c in range(SIZE):
            v = bilinear(grid, rows[r][c], cols[r][c])
            if v is None:                       # exactly on an edge: take nearest
                v = grid[min(len(grid) - 1, max(0, round(rows[r][c])))][
                    min(len(grid[0]) - 1, max(0, round(cols[r][c])))]
            out[r][c] = v
    return out


def _parse_classic_sky(ds, rows, cols, date, hours, offset):
    """v1 file: instantaneous cover fields on one 'time' axis, linearly interpolated."""
    times = _gfs_times(ds)

    def at_hour(name, when):
        """Layer values at UTC time `when`, interpolated between file times."""
        var = ds.variables[name]
        if when <= times[0] or len(times) == 1:
            i, w = 0, 0.0
        elif when >= times[-1]:
            i, w = len(times) - 2, 1.0
        else:
            i = max(k for k in range(len(times) - 1) if times[k] <= when)
            w = (when - times[i]).total_seconds() / (times[i + 1] - times[i]).total_seconds()
        if len(times) == 1:
            return _gfs_layer(var[0], rows, cols)
        a = _gfs_layer(var[i], rows, cols)
        b = _gfs_layer(var[i + 1], rows, cols)
        return [[a[r][c] * (1 - w) + b[r][c] * w for c in range(SIZE)] for r in range(SIZE)]

    rain_name = next((n for n in ds.variables if n.startswith("Precipitation_rate")), None)
    sky = {}
    for h in hours:
        when = (datetime.datetime(date.year, date.month, date.day, h, tzinfo=datetime.timezone.utc)
                - datetime.timedelta(hours=offset))
        entry = {}
        for key, name in GFS_CLOUD_VARS.items():
            layer = at_hour(name, when)
            entry[key] = [[min(1.0, max(0.0, v / 100.0)) for v in row] for row in layer]
        if rain_name:                       # kg m-2 s-1 -> mm per hour
            entry["precip"] = [[max(0.0, v * 3600.0) for v in row] for row in at_hour(rain_name, when)]
        else:
            entry["precip"] = [[0.0] * SIZE for _ in range(SIZE)]
        sky[h] = entry
    return sky


def _parse_cube_sky(ds, rows, cols, date, hours, offset):
    """v1.1 file: interval-average cover / precipitation / cloud base and top."""
    grids = {}

    def grid(name, idx):
        if (name, idx) not in grids:
            grids[(name, idx)] = _gfs_layer(ds.variables[name][idx], rows, cols)
        return grids[(name, idx)]

    def bin_grid(name, parts):
        if len(parts) == 1:
            return grid(name, parts[0])
        six, three = grid(name, parts[0]), grid(name, parts[1])
        return [[max(0.0, 2.0 * six[r][c] - three[r][c]) for c in range(SIZE)] for r in range(SIZE)]

    def averaged_at(name, when):
        """Cover / precipitation at `when`: 3 h means placed at their centres, joined linearly."""
        bins = _three_hour_bins(_gfs_intervals(ds, name))
        centres = [a + (b - a) / 2 for a, b, _ in bins]
        if when <= centres[0] or len(bins) == 1:
            return bin_grid(name, bins[0][2])
        if when >= centres[-1]:
            return bin_grid(name, bins[-1][2])
        i = max(k for k in range(len(bins) - 1) if centres[k] <= when)
        w = (when - centres[i]).total_seconds() / (centres[i + 1] - centres[i]).total_seconds()
        a, b = bin_grid(name, bins[i][2]), bin_grid(name, bins[i + 1][2])
        return [[a[r][c] * (1 - w) + b[r][c] * w for c in range(SIZE)] for r in range(SIZE)]

    have_heights = all(n in ds.variables for n in GFS_CUBE_PRESSURE.values())
    sky = {}
    for h in hours:
        when = (datetime.datetime(date.year, date.month, date.day, h, tzinfo=datetime.timezone.utc)
                - datetime.timedelta(hours=offset))
        entry = {}
        for L, name in GFS_CUBE_COVER.items():
            entry[L] = [[min(1.0, max(0.0, v / 100.0)) for v in row] for row in averaged_at(name, when)]
        if GFS_CUBE_PRECIP in ds.variables:        # kg m-2 s-1 -> mm per hour
            entry["precip"] = [[max(0.0, v * 3600.0) for v in row]
                               for row in averaged_at(GFS_CUBE_PRECIP, when)]
        else:
            entry["precip"] = [[0.0] * SIZE for _ in range(SIZE)]
        if have_heights:
            cube = {}
            for L in LAYERS:
                edge = {}
                for e in ("bottom", "top"):
                    name = GFS_CUBE_PRESSURE[(L, e)]
                    idx = _pick_interval(_gfs_intervals(ds, name), when)
                    edge[e] = _gfs_nearest(ds.variables[name][idx], rows, cols)
                bottom = [[None] * SIZE for _ in range(SIZE)]
                top = [[None] * SIZE for _ in range(SIZE)]
                for r in range(SIZE):
                    for c in range(SIZE):
                        pb, pt = edge["bottom"][r][c], edge["top"][r][c]
                        if pb is None or pt is None or pb <= 0 or pt <= 0:
                            continue                       # no cloud in this layer here
                        b, t = pressure_to_height_m(pb), pressure_to_height_m(pt)
                        bottom[r][c], top[r][c] = b, max(t, b + 50.0)
                cube[L] = {"bottom": bottom, "top": top}
            entry["cube"] = cube
        sky[h] = entry
    return sky


def parse_gfs(path, lat0, lon0, date, hours, elev_path=None):
    """GFS subset file -> (sky, elev) in the same shape parse_responses gives.
    A v1.1 file also gives sky[h]["cube"][layer] = {"bottom", "top"} grids of
    cloud base / top height above sea level in metres (None = no cloud there)."""
    try:
        from netCDF4 import Dataset
    except ImportError:
        raise RuntimeError("reading the GFS file needs  pip install netCDF4")
    ds = Dataset(path)
    try:
        lats = [float(v) for v in ds.variables["latitude"][:]]
        lons = [float(v) for v in ds.variables["longitude"][:]]
        rows = [[0.0] * SIZE for _ in range(SIZE)]
        cols = [[0.0] * SIZE for _ in range(SIZE)]
        for r in range(SIZE):
            for c in range(SIZE):
                la, lo = cell_latlon(lat0, lon0, r, c)
                rows[r][c] = _axis_position(lats, la)
                cols[r][c] = _axis_position(lons, lo % 360.0 if max(lons) > 180 else lo)
        offset = eastern_utc_offset_hours(date)
        if all(n in ds.variables for n in GFS_CUBE_COVER.values()):
            sky = _parse_cube_sky(ds, rows, cols, date, hours, offset)
        else:
            sky = _parse_classic_sky(ds, rows, cols, date, hours, offset)
        elev = [[0.0] * SIZE for _ in range(SIZE)]
        if GFS_ELEVATION_VAR in ds.variables:
            elev = _gfs_layer(ds.variables[GFS_ELEVATION_VAR][0], rows, cols)
        elif elev_path and os.path.exists(elev_path):
            e_ds = Dataset(elev_path)
            try:
                elev = _gfs_layer(e_ds.variables[GFS_ELEVATION_VAR][0], rows, cols)
            finally:
                e_ds.close()
        return sky, [[max(0.0, v) for v in row] for row in elev]
    finally:
        ds.close()


def _is_http_error(err):
    return re.search(r"HTTP\D{0,8}[45]\d\d", str(err)) is not None


def fetch_sky_gfs(lat0, lon0, date_str, hours, sunset_utc, cache_dir="cache",
                  fetch_file=None, log=print, now=None, cube=True):
    """Download (or reuse) the GFS subset around sunset; return (sky, elev).

    cube=True asks for the v1.1 cloud-cube fields; if the server refuses them it
    falls back to the v1 request, and if it refuses the terrain height it asks
    for that on its own (a refusal never silently loses the observer's elevation
    for long, and never blocks the forecast)."""
    date = datetime.date.fromisoformat(date_str)
    fetch_file = fetch_file or _http_get_file
    tag = "%.4f_%.4f_%s.nc" % (lat0, lon0, date_str)
    paths = {True: os.path.join(cache_dir, "gfscube_" + tag),
             False: os.path.join(cache_dir, "gfs_" + tag)}
    elev_path = os.path.join(cache_dir, "gfselev_%.4f_%.4f.nc" % (lat0, lon0))
    now_ts = (now or datetime.datetime.now(datetime.timezone.utc)).timestamp()

    def fresh(p):
        return os.path.exists(p) and (now_ts - os.path.getmtime(p)) < GFS_CACHE_HOURS * 3600

    use = cube if fresh(paths[cube]) else None      # a plain (v1) file is never mistaken for a cube
    if use is not None:
        log("Using cached GFS forecast: %s" % paths[use])
    else:
        os.makedirs(cache_dir, exist_ok=True)
        start = sunset_utc - datetime.timedelta(hours=5)
        end = sunset_utc + datetime.timedelta(hours=5)
        tmp = paths[False] + ".dl"
        tries = ([(True, True), (True, False)] if cube else []) + [(False, True), (False, False)]
        err = None
        for mode, extras in tries:
            try:
                fetch_file(gfs_url(lat0, lon0, start, end, extras=extras, cube=mode), tmp)
                use = mode
                break
            except Exception as e:
                if not _is_http_error(e):
                    raise RuntimeError("GFS download failed: %s" % e)
                err = e
                log("GFS server rejected the %s request (%s); trying a simpler one"
                    % ("cloud-cube" if mode else "basic", str(e)[:80]))
        if use is None:
            raise RuntimeError("GFS download failed: %s" % err)
        os.replace(tmp, paths[use])
        if not extras and not os.path.exists(elev_path):         # terrain height alone, once
            try:
                fetch_file(gfs_elevation_url(lat0, lon0, sunset_utc), elev_path + ".dl")
                os.replace(elev_path + ".dl", elev_path)
            except Exception as e:
                log("Terrain height unavailable (%s); using sea level" % str(e)[:80])
    return parse_gfs(paths[use], lat0, lon0, date, hours, elev_path)


# ------------------------------------------------------ Step 5: regions
def _bearing_dist(dr, dc):
    dx, dy = dc * SPACING_KM, -dr * SPACING_KM      # east, north
    return math.degrees(math.atan2(dx, dy)) % 360.0, math.hypot(dx, dy)


def wedge_cells(az, radius_km, obs=OBS, half=WEDGE_HALF):
    """Set of (r, c) cells within `half` degrees of bearing `az`, 0 < d <= radius."""
    out = set()
    for r in range(SIZE):
        for c in range(SIZE):
            b, d = _bearing_dist(r - obs[0], c - obs[1])
            if 0 < d <= radius_km and abs((b - az + 180.0) % 360.0 - 180.0) <= half:
                out.add((r, c))
    return out


def disc_cells(obs=OBS, radius_km=OVERHEAD_KM):
    return {(r, c) for r in range(SIZE) for c in range(SIZE)
            if _bearing_dist(r - obs[0], c - obs[1])[1] <= radius_km}


def bilinear(grid, row, col):
    """Value at fractional (row, col); None if the 4 corners are not all inside."""
    r0, c0 = math.floor(row), math.floor(col)
    if r0 == len(grid) - 1 and row == r0:            # exactly on the last row
        r0 -= 1
    if c0 == len(grid[0]) - 1 and col == c0:
        c0 -= 1
    if r0 < 0 or c0 < 0 or r0 + 1 > len(grid) - 1 or c0 + 1 > len(grid[0]) - 1:
        return None
    fr, fc = row - r0, col - c0
    top = grid[r0][c0] * (1 - fc) + grid[r0][c0 + 1] * fc
    bottom = grid[r0 + 1][c0] * (1 - fc) + grid[r0 + 1][c0 + 1] * fc
    return top * (1 - fr) + bottom * fr


def ray_offsets(az, radius_km):
    """(east_km, north_km) sample points on three rays (az-10, az, az+10)."""
    out = []
    for delta in (-RAY_SPREAD_DEG, 0, RAY_SPREAD_DEG):
        b = math.radians(az + delta)
        k = 1
        while k * RAY_STEP_KM <= radius_km + 1e-9:
            d = k * RAY_STEP_KM
            out.append((d * math.sin(b), d * math.cos(b)))
            k += 1
    return out


def ray_mean(grid, offsets, obs=OBS):
    vals = []
    for east, north in offsets:
        v = bilinear(grid, obs[0] - north / SPACING_KM, obs[1] + east / SPACING_KM)
        if v is not None:
            vals.append(v)
    return (sum(vals) / len(vals) if vals else 0.0), len(vals)


# --------------------------------------------------------- Step 6: the gate
def gate_value(block, precip_mean=0.0):
    """How much of the sky's colour the sun can still reach, 0..1.

    block = share of the sun hidden by cloud (0 clear .. 1 wholly hidden).
    Even a little sun goes a long way: a sliver of disc under a deck still lights
    the cloud above it.  So the gate is a log-shaped curve of the share that shows
    (seen = 1 - block): 0 when the sun is wholly hidden (less than GATE_SHUT of
    it showing, which is within sampling noise of none), rising steeply from
    there, and full once GATE_OPEN's worth of the disc is out.
        gate = ln(1 + K * (seen - SHUT)) / ln(1 + K * (1 - GATE_OPEN - SHUT)),  0..1.
    Rain along the sun direction multiplies the result."""
    seen = 1.0 - max(0.0, min(1.0, block))
    full = 1.0 - GATE_OPEN - GATE_SHUT
    g = math.log1p(GATE_LOG_K * max(0.0, seen - GATE_SHUT)) / math.log1p(GATE_LOG_K * full)
    return min(1.0, g) * (RAIN_FACTOR if precip_mean > RAIN_LIMIT else 1.0)


def cover_gate(low_mean, precip_mean=0.0):
    """The v1 gate, kept for inputs that are a plain cloud-COVER fraction rather
    than the share of the sun's disc that is hidden: the no-cube fallback (mean
    low cover along the sun direction) and the satellite's share of low-cloud
    pixels.  A cover fraction is not a chance of seeing the sun (a ray crossing
    100 km of 75% cover is almost surely blocked), so it keeps the straight ramp."""
    g = (COVER_CLOSED - low_mean) / (COVER_CLOSED - COVER_OPEN)
    g = max(0.0, min(1.0, g))
    return g * (RAIN_FACTOR if precip_mean > RAIN_LIMIT else 1.0)


# ------------------------------------------- Step 7: decoration and dapple
def sweet_spot(c):
    if c <= 1.0 / 3.0:
        return 3.0 * c
    if c <= 2.0 / 3.0:
        return 1.0
    return 3.0 * (1.0 - c)


def sky_weights(cells, height_m, obs=OBS):
    """Share of the sky each ground cell fills, for a flat cloud sheet `height_m`
    above the eye: a patch of area A at ground distance d subtends about
    A * h / (d**2 + h**2) ** 1.5 steradians, so cloud 60 km out fills far more of
    the sky than the same cloud 300 km out.  d is floored at half a cell."""
    h = max(height_m, 200.0) / 1000.0
    out = {}
    for r, c in cells:
        d = max(_bearing_dist(r - obs[0], c - obs[1])[1], SPACING_KM / 2.0)
        out[(r, c)] = h / (d * d + h * h) ** 1.5
    return out


def mean_coverage(grid, cells, weights=None):
    """Mean cover over `cells`; with `weights` (cell -> weight) a weighted mean."""
    if not cells:
        return 0.0
    if weights is None:
        return sum(grid[r][c] for r, c in cells) / len(cells)
    total = sum(weights[p] for p in cells)
    return sum(grid[r][c] * weights[(r, c)] for r, c in cells) / total if total > 0 else 0.0


def texture(grid, cells, step=1):
    """1 - (mean fraction of a cloudy cell's neighbours that are cloudy).
    0.0 if no cloudy cells; None if no cloudy cell has a neighbour in `cells`."""
    cloudy = [p for p in cells if grid[p[0]][p[1]] >= CLOUDY]
    if not cloudy:
        return 0.0
    fracs = []
    for r, c in cloudy:
        nbrs = [p for p in ((r + step, c), (r - step, c), (r, c + step), (r, c - step))
                if p in cells]
        if nbrs:
            fracs.append(sum(1 for p in nbrs if grid[p[0]][p[1]] >= CLOUDY) / len(nbrs))
    return None if not fracs else 1.0 - sum(fracs) / len(fracs)


def dapple(grid, cells):
    t = [x for x in (texture(grid, cells, 1), texture(grid, cells, 2)) if x is not None]
    return sum(t) / len(t) if t else 0.5


def layer_decoration(grid, cells, dap=None, weights=None):
    """sweet-spot(coverage) x texture factor.  `dap` is a dapple value measured
    elsewhere (the satellite); if None it is computed from `grid`.  `weights`
    (cell -> sky share) makes the coverage the share of the SKY that is cloud."""
    if not cells:
        return 0.0
    if dap is None:
        dap = dapple(grid, cells)
    return sweet_spot(mean_coverage(grid, cells, weights)) * ((1 - TEXTURE_WEIGHT) + TEXTURE_WEIGHT * dap)


# ------------------------------------------- v1.1: vertical sight-line geometry
def apparent_elevation_deg(height_m, dist_km):
    """Angle above the observer's horizontal at which a point `height_m` above
    the observer's eye, `dist_km` away, appears: its height angle minus the
    earth's curvature drop (slightly reduced by refraction)."""
    return math.degrees(height_m / (dist_km * 1000.0)
                        - (1.0 - REFRACTION_K) * dist_km / (2.0 * EARTH_RADIUS_KM))


def horizon_dip_deg(elev_m):
    """How far below horizontal the visible horizon lies for an eye at elev_m."""
    return math.degrees(math.sqrt(2.0 * max(elev_m, 0.0) / (EARTH_RADIUS_KM * 1000.0)
                                  * (1.0 - REFRACTION_K)))


def layer_typical(sky_h, L):
    """Typical (bottom, top) height above sea level of layer L this hour: the
    median over cells with real cloud, or a standard layer if the model has none."""
    cube = sky_h["cube"][L]
    bottoms, tops = [], []
    for r in range(SIZE):
        for c in range(SIZE):
            if sky_h[L][r][c] >= 0.1 and cube["bottom"][r][c] is not None:
                bottoms.append(cube["bottom"][r][c])
                tops.append(cube["top"][r][c])
    if not bottoms:
        return DEFAULT_LAYER_ASL_M[L]
    return statistics.median(bottoms), statistics.median(tops)


def cell_interval(sky_h, L, r, c, typical, elev_m):
    """(bottom, top) of layer L in cell (r, c), metres above the observer's eye."""
    cube = sky_h["cube"][L]
    b, t = cube["bottom"][r][c], cube["top"][r][c]
    if b is None or t is None:
        b, t = typical
    return b - elev_m, t - elev_m


def sight_line(sky_h, az, elev_m, sun_deg, typical):
    """How much of the sun's disc is hidden by cloud at the sun's own height.

    Along the three rays every cloud layer is a slab with a bottom and a top;
    seen from `elev_m` at distance d it covers apparent elevations [e_bottom,
    e_top].  The sun disc is cut into horizontal slices; a slice is blocked by
    a layer when it lies inside that interval, with probability equal to the
    layer's cover times its opacity (SIGHT_OPACITY: low cloud hides the sun,
    thin high cloud mostly dims it).  Samples closer than CORR_KM are the same
    cloud, so a sample only counts (1 - hide) ** (step / CORR_KM).  Cloud
    wholly above the sun (it decorates) or below it (hidden, or a silhouette)
    blocks nothing, which is the point: a deck that ends before the horizon
    line does not close the gate and a high deck does not either."""
    half = SUN_HALF_DEG
    slices = [sun_deg - half + (k + 0.5) * 2.0 * half / SIGHT_SLICES for k in range(SIGHT_SLICES)]
    ray_block, layer_block = [], {L: [] for L in LAYERS}
    spans = {L: [None, None] for L in LAYERS}
    for delta in (-RAY_SPREAD_DEG, 0, RAY_SPREAD_DEG):
        bearing = math.radians(az + delta)
        open_all = [1.0] * SIGHT_SLICES
        open_layer = {L: [1.0] * SIGHT_SLICES for L in LAYERS}
        d = RAY_STEP_KM
        while d <= SIGHT_MAX_KM:
            row = OBS[0] - d * math.cos(bearing) / SPACING_KM
            col = OBS[1] + d * math.sin(bearing) / SPACING_KM
            for L in LAYERS:
                cover = bilinear(sky_h[L], row, col)
                if cover is None or cover < 0.02:
                    continue
                hide = cover * SIGHT_OPACITY[L]          # thin high cloud dims the sun, it does not hide it
                r = min(SIZE - 1, max(0, round(row)))
                c = min(SIZE - 1, max(0, round(col)))
                bottom, top = cell_interval(sky_h, L, r, c, typical[L], elev_m)
                e_b, e_t = apparent_elevation_deg(bottom, d), apparent_elevation_deg(top, d)
                hit = False
                for k, s in enumerate(slices):
                    if e_b <= s <= e_t:
                        f = 0.0 if hide >= 0.999 else (1.0 - hide) ** (RAY_STEP_KM / CORR_KM)
                        open_all[k] *= f
                        open_layer[L][k] *= f
                        hit = True
                if hit and cover >= 0.05:
                    lo, hi = spans[L]
                    spans[L] = [d if lo is None else min(lo, d), d if hi is None else max(hi, d)]
            d += RAY_STEP_KM
        ray_block.append(1.0 - sum(open_all) / SIGHT_SLICES)
        for L in LAYERS:
            layer_block[L].append(1.0 - sum(open_layer[L]) / SIGHT_SLICES)
    return {"block": sum(ray_block) / len(ray_block),
            "layers": {L: {"block": sum(layer_block[L]) / len(layer_block[L]),
                           "span_km": tuple(spans[L]) if spans[L][0] is not None else None,
                           "bottom_m": typical[L][0], "top_m": typical[L][1]} for L in LAYERS}}


def _layer_view(sky_h, L, bearing, radius_km, elev_m, typical, sun_deg=None):
    """(grid, cells) of layer L toward `bearing` for the decoration sum: the cells
    whose cloud top clears the visible horizon, each cell's cover scaled by the
    share of its cloud that stands above the sun (sun_deg given: toward the sun;
    cloud at or below the sun's height is a silhouette and earns nothing)."""
    dip = horizon_dip_deg(elev_m)
    hi = None if sun_deg is None else sun_deg + SUN_HALF_DEG
    eff = [[0.0] * SIZE for _ in range(SIZE)]
    cells = set()
    for r, c in wedge_cells(bearing, radius_km):
        d = _bearing_dist(r - OBS[0], c - OBS[1])[1]
        bottom, top = cell_interval(sky_h, L, r, c, typical, elev_m)
        e_b, e_t = apparent_elevation_deg(bottom, d), apparent_elevation_deg(top, d)
        if e_t <= -dip:
            continue                                   # below the horizon: not there to see
        w = 1.0
        if hi is not None:
            if e_t <= hi:
                w = 0.0
            elif e_b < hi:
                w = (e_t - hi) / (e_t - e_b)
        cells.add((r, c))
        eff[r][c] = sky_h[L][r][c] * w
    return eff, cells


# ----------------------------------------------- v1.1: where the points came from
def score_points(detail, region_val, plain, gate, cloud_gate, decoration):
    """The score as additive points.  What a perfect sky could earn adds to 100:
    a floor for a visible sun (100 * BASE) plus the decoration points, split by
    region weight and then by layer weight.  Each entry has what the sky earned
    ("earned") and what was possible ("max").  The sun being hidden by cloud or
    rain takes points off the total ("cloud_loss", "rain_loss"), so
        floor + regions - cloud_loss - rain_loss  ==  100 * gate * (BASE + (1 - BASE) * decoration)."""
    pool = 100.0 * (1.0 - BASE)
    regions = {}
    for name in detail:
        rmax = pool * R_WEIGHT[name]
        layers = {L: {"max": rmax * LAYER_WEIGHTS[name][L],
                      "earned": rmax * LAYER_WEIGHTS[name][L] * detail[name][L][2]} for L in LAYERS}
        regions[name] = {"max": rmax, "earned": rmax * region_val[name], "layers": layers,
                         "ir": rmax * (region_val[name] - plain[name])}
    floor = 100.0 * BASE
    potential = floor + sum(r["earned"] for r in regions.values())
    cloud_loss = potential * (1.0 - cloud_gate)
    rain_loss = potential * cloud_gate * (1.0 - gate / cloud_gate) if cloud_gate > 0 else 0.0
    return {"floor": {"max": floor, "earned": floor}, "regions": regions,
            "cloud_loss": cloud_loss, "rain_loss": rain_loss,
            "total": potential - cloud_loss - rain_loss}


def average_points(tables):
    """Mean of several points tables (one per hour), leaf by leaf."""
    first = tables[0]
    if isinstance(first, dict):
        return {k: average_points([t[k] for t in tables]) for k in first}
    return sum(tables) / len(tables)


# ------------------------------------------------------ Step 8: one hour
def score_hour(sky_h, az, elev_m=0.0, sat_dapple=None, sun_deg=SUN_REF_DEG, ir=None,
               sat_weight=1.0, sat_gate=None, sat_gate_w=0.0):
    """Score one hour of sky.  Returns a dict with the score and its working.

    sat_dapple: optional {region: {layer: value or None}} of dapple measured
    from satellite pixels; a number replaces the forecast-grid dapple for that
    region and layer (weighted: sat_weight * satellite + (1 - sat_weight) *
    forecast, sat_weight 1 = replaces), None keeps the forecast's.
    sat_gate / sat_gate_w: the satellite's own gate and its weight; the gate
    used is (1 - w) * forecast gate + w * satellite gate (rain still applies).
    ir: optional {region: {"texture": 0..1, "valid": 0..1}} infrared roughness
    of the cloud tops and the share of the region it was measured over.

    If sky_h carries a "cube" (cloud base / top heights, v1.1) the gate is the
    sight-line blocking of the sun's disc and the forward cloud is credited only
    for what stands above the sun; otherwise it is the v1 low-cloud average.
    sun_deg is the sun centre's apparent elevation: by default its position at
    the instant of sunset, which is what the score is about."""
    anti = (az + 180.0) % 360.0
    sight = typical = None
    if "cube" in sky_h:
        typical = {L: layer_typical(sky_h, L) for L in LAYERS}
        sight = sight_line(sky_h, az, elev_m, sun_deg, typical)
        rad = {L: visibility_radius(typical[L][1] - elev_m, elev_m) for L in LAYERS}
        offs = ray_offsets(az, rad["low"])
        low_mean, _ = ray_mean(sky_h["low"], offs)
        rain_mean, _ = ray_mean(sky_h["precip"], offs)
        gate = gate_value(sight["block"], rain_mean)
        cloud_gate = gate_value(sight["block"], 0.0)
        sky_height = {L: 0.5 * (typical[L][0] + typical[L][1]) for L in LAYERS}
        views = {"fwd": {L: _layer_view(sky_h, L, az, GRID_REACH_KM, elev_m, typical[L], sun_deg)
                         for L in LAYERS},
                 "over": {L: (sky_h[L], disc_cells()) for L in LAYERS},
                 "anti": {L: _layer_view(sky_h, L, anti, rad[L], elev_m, typical[L])
                          for L in LAYERS}}
    else:
        rad = {L: visibility_radius(LAYER_HEIGHT_M[L], elev_m) for L in LAYERS}
        offs = ray_offsets(az, rad["low"])
        low_mean, _ = ray_mean(sky_h["low"], offs)
        rain_mean, _ = ray_mean(sky_h["precip"], offs)
        gate = cover_gate(low_mean, rain_mean)
        cloud_gate = cover_gate(low_mean, 0.0)
        sky_height = {L: LAYER_HEIGHT_M[L] + elev_m for L in LAYERS}
        views = {"fwd": {L: (sky_h[L], wedge_cells(az, rad[L])) for L in LAYERS},
                 "over": {L: (sky_h[L], disc_cells()) for L in LAYERS},
                 "anti": {L: (sky_h[L], wedge_cells(anti, rad[L])) for L in LAYERS}}
    detail = {}                       # region -> layer -> (cover, dapple, decor)
    region_val = {}
    plain = {}                        # region value before the infrared bonus
    for name, per_layer in views.items():
        total = 0.0
        detail[name] = {}
        for L in LAYERS:
            grid, cells = per_layer[L]
            measured = sat_dapple.get(name, {}).get(L) if sat_dapple else None
            if measured is None:
                dap = dapple(grid, cells) if cells else 0.5
            elif sat_weight >= 1.0 or not cells:
                dap = measured
            else:
                dap = sat_weight * measured + (1.0 - sat_weight) * dapple(grid, cells)
            wts = sky_weights(cells, sky_height[L] - elev_m) if (SKY_WEIGHTING and cells) else None
            dec = layer_decoration(grid, cells, dap if cells else None, wts)
            detail[name][L] = (mean_coverage(grid, cells, wts), dap, dec)
            total += LAYER_WEIGHTS[name][L] * dec
        plain[name] = total
        if ir and ir.get(name):
            total = min(1.0, total * (1.0 + IR_MAX * ir[name]["valid"] * ir[name]["texture"]))
        region_val[name] = total
    decoration = sum(R_WEIGHT[k] * region_val[k] for k in region_val)
    gate_forecast = gate
    if sat_gate is not None and sat_gate_w > 0:
        rain_factor = RAIN_FACTOR if rain_mean > RAIN_LIMIT else 1.0
        cloud_gate = (1.0 - sat_gate_w) * cloud_gate + sat_gate_w * sat_gate
        gate = cloud_gate * rain_factor
    score = round(100.0 * gate * (BASE + (1.0 - BASE) * decoration))
    points = score_points(detail, region_val, plain, gate, cloud_gate, decoration)
    return {"score": score, "gate": gate, "gate_forecast": gate_forecast, "decoration": decoration,
            "low_mean": low_mean, "rain_mean": rain_mean,
            "regions": region_val, "detail": detail, "sight": sight, "typical": typical,
            "points": points}


# ---------------------------------------- Step 9: range and confidence
def score_range(sky, hours, az, elev_m=0.0, sat_dapple=None, ir=None,
                sat_weight=1.0, sat_gate=None, sat_gate_w=0.0):
    per_hour = {h: score_hour(sky[h], az, elev_m, sat_dapple, ir=ir, sat_weight=sat_weight,
                              sat_gate=sat_gate, sat_gate_w=sat_gate_w) for h in hours}
    scores = [per_hour[h]["score"] for h in hours]
    return round(sum(scores) / len(scores)), min(scores), max(scores), per_hour


def confidence(lead_h, gate_gap=0.0):
    conf = max(1.0 - max(lead_h, 0.0) / FORECAST_HORIZON_H, 0.2)
    if gate_gap > 0.5:
        conf -= 0.2
    return max(conf, 0.1)


# ------------------------------------------- Step 10: live satellite check
def latlon_to_scan(lat, lon, geom):
    """Ground (lat, lon) in degrees -> GOES scan angles (x, y) in radians."""
    req, rpol = geom["req"], geom["rpol"]
    H = geom["h"] + req
    e2 = 1.0 - (rpol * rpol) / (req * req)
    phi, lam, lam0 = math.radians(lat), math.radians(lon), math.radians(geom["lon0"])
    phi_c = math.atan((rpol * rpol) / (req * req) * math.tan(phi))
    r_c = rpol / math.sqrt(1.0 - e2 * math.cos(phi_c) ** 2)
    sx = H - r_c * math.cos(phi_c) * math.cos(lam - lam0)
    sy = -r_c * math.cos(phi_c) * math.sin(lam - lam0)
    sz = r_c * math.sin(phi_c)
    y = math.atan(sz / sx)
    x = math.asin(-sy / math.sqrt(sx * sx + sy * sy + sz * sz))
    return x, y


def _http_get_file(url, dest):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    tmp = dest + ".part"
    with urllib.request.urlopen(req, timeout=120) as resp, open(tmp, "wb") as out:
        while True:
            block = resp.read(1 << 20)
            if not block:
                break
            out.write(block)
    os.replace(tmp, dest)


def _parse_scan_start(key):
    m = re.search(r"_s(\d{4})(\d{3})(\d{2})(\d{2})(\d{2})", key)
    if not m:
        return None
    y, doy, hh, mm, ss = (int(g) for g in m.groups())
    return (datetime.datetime(y, 1, 1, tzinfo=datetime.timezone.utc)
            + datetime.timedelta(days=doy - 1, hours=hh, minutes=mm, seconds=ss))


def goes_scan_key(product, when_utc, get_text=None, must_contain=None):
    """Key of the newest scan of `product` that started at or before when_utc
    (optionally only files whose name contains `must_contain`, e.g. a band)."""
    get_text = get_text or _http_get
    for back in (0, 1):                          # this UTC hour, then the one before
        t = when_utc - datetime.timedelta(hours=back)
        prefix = "%s/%04d/%03d/%02d/" % (product, t.year, t.timetuple().tm_yday, t.hour)
        text = get_text("%s?list-type=2&prefix=%s" % (GOES_URL, prefix))
        keys = [piece.split("</Key>")[0] for piece in text.split("<Key>")[1:]]
        best, best_t = None, None
        for k in keys:
            st = _parse_scan_start(k)
            if (k.endswith(".nc") and st and st <= when_utc and (best_t is None or st > best_t)
                    and (must_contain is None or must_contain in os.path.basename(k))):
                best, best_t = k, st
        if best:
            return best
    raise SatelliteUnavailable("no %s scan found near %s UTC" % (product, when_utc))


def _open_dataset(path):
    try:
        from netCDF4 import Dataset
        import numpy as np
    except ImportError:
        raise SatelliteUnavailable("netCDF4 is not installed (pip install netCDF4)")
    ds = Dataset(path)
    proj = ds.variables["goes_imager_projection"]
    xs = np.ma.filled(ds.variables["x"][:], np.nan).astype(float)
    ys = np.ma.filled(ds.variables["y"][:], np.nan).astype(float)
    geom = {"h": float(proj.perspective_point_height),
            "req": float(proj.semi_major_axis),
            "rpol": float(proj.semi_minor_axis),
            "lon0": float(proj.longitude_of_projection_origin),
            "x0": float(xs[0]), "dx": float(xs[1] - xs[0]), "nx": len(xs),
            "y0": float(ys[0]), "dy": float(ys[1] - ys[0]), "ny": len(ys)}
    return ds, geom, np


def goes_pixel(ds, geom, np, lat, lon, varname):
    """Value of `varname` at the pixel containing (lat, lon); None if off-scan
    or masked (no valid retrieval)."""
    x, y = latlon_to_scan(lat, lon, geom)
    i = round((x - geom["x0"]) / geom["dx"])
    j = round((y - geom["y0"]) / geom["dy"])
    if not (0 <= i < geom["nx"] and 0 <= j < geom["ny"]):
        return None
    v = ds.variables[varname][j, i]
    if np.ma.is_masked(v):
        return None
    f = float(v)
    return None if math.isnan(f) else f


def _mask_is_cloudy(varname, v):
    # ACM: 0 clear, 1 probably clear, 2 probably cloudy, 3 cloudy.  BCM: 1 = cloudy.
    return v >= 2 if varname == "ACM" else v >= 1


def satellite_time(now_utc, sunset_utc):
    """When to look: sunset itself for past sunsets, 'now' if sunset is within
    3 hours, otherwise never (too early to be a meaningful check)."""
    if now_utc >= sunset_utc:
        return sunset_utc
    if sunset_utc - now_utc <= datetime.timedelta(hours=SAT_WINDOW_H):
        return now_utc
    return None


def sat_weights(age_h, have_winds=True):
    """How much to trust a satellite scan `age_h` hours old at sunset.
    Returns {"total", "unshifted", "shifted"}: total potency falls as the scan
    ages (quadratically, so a fresh scan keeps nearly all of it); of that, the
    share that stays with the unshifted picture grows with age, because drift
    error grows and clouds form and fade, so 'the same area is cloudy' becomes
    the better bet.  Without winds all of it is unshifted."""
    a = max(0.0, age_h)
    total = SAT_FLOOR + (1.0 - SAT_FLOOR) * max(0.0, 1.0 - (a / SAT_FADE_H) ** SAT_FADE_POWER)
    persist = SHIFT_PERSIST_MAX * min(1.0, a / SAT_FADE_H) if have_winds else 1.0
    return {"total": total, "unshifted": total * persist, "shifted": total * (1.0 - persist)}


def shift_vectors(winds, age_h):
    """{layer: (east_km, north_km)} that cloud in each layer moves in `age_h`
    hours on {layer: (u, v)} winds in m/s (u east, v north)."""
    return {L: (winds[L][0] * 3.6 * age_h, winds[L][1] * 3.6 * age_h) for L in LAYERS}


def shifted_layers(sample, east, north, shift):
    """What will be at (east, north) km from the observer once the clouds seen
    in the scan have moved by `shift` (None = not moved).

    `sample(e, n)` reads the scan and returns [(layer, top_m), ...] for the
    cloud there ([] if clear, None if unknown).  A cloud layer is traced back
    along its own layer's wind to where it was; only cloud of that layer counts
    (a mid-level cloud is not carried by the low-level wind).  Same return shape."""
    if not shift:
        return sample(east, north)
    found, known = [], False
    for L in LAYERS:
        de, dn = shift[L]
        got = sample(east - de, north - dn)
        if got is None:
            continue
        known = True
        found += [(lay, top) for lay, top in got if lay == L]
    if found:
        return found
    return [] if known else None


def blend_dapple(d0, d1, w0, w1):
    """Combine satellite dapple dicts {region: {layer: value|None}} measured on the
    observed scan (weight w0) and on the wind-shifted scan (w1).  A layer with no
    cloud in one of them takes the other's value alone."""
    if d0 is None and d1 is None:
        return None
    out = {}
    for region in (d0 or d1):
        out[region] = {}
        for L in LAYERS:
            parts = [(w, d[region][L]) for w, d in ((w0, d0), (w1, d1))
                     if d is not None and d[region][L] is not None and w > 0]
            if not parts and d0 is not None and d0[region][L] is not None:
                parts = [(1.0, d0[region][L])]              # zero weight: keep the observed one
            out[region][L] = (sum(w * v for w, v in parts) / sum(w for w, _ in parts)) if parts else None
    return out


def gfs_wind_url(lat0, lon0, start_utc, end_utc):
    """NCSS request for the u / v winds on every pressure level in the box."""
    return gfs_url(lat0, lon0, start_utc, end_utc, names=list(GFS_WIND_VARS))


def parse_winds(path, scan_utc, sunset_utc):
    """Steering wind of each layer, {layer: (u, v)} in m/s: the box-mean wind on
    the layer's steering level (WIND_LEVEL_HPA), at the time half-way between
    the scan and sunset (linear between the file's times)."""
    try:
        from netCDF4 import Dataset
    except ImportError:
        raise RuntimeError("reading the wind file needs  pip install netCDF4")
    import numpy as np
    ds = Dataset(path)
    try:
        u, v = (ds.variables[n] for n in GFS_WIND_VARS)
        tdim = u.dimensions[0]
        vdim = next(d for d in u.dimensions if d.startswith("isobaric"))
        times = _gfs_times(ds, tdim)
        mid = scan_utc + (sunset_utc - scan_utc) / 2
        if len(times) == 1 or mid <= times[0]:
            i, w = 0, 0.0
        elif mid >= times[-1]:
            i, w = len(times) - 2, 1.0
        else:
            i = max(k for k in range(len(times) - 1) if times[k] <= mid)
            w = (mid - times[i]).total_seconds() / (times[i + 1] - times[i]).total_seconds()
        levels = [float(x) / 100.0 for x in ds.variables[vdim][:]]
        t_axis, z_axis = u.dimensions.index(tdim), u.dimensions.index(vdim)
        out = {}
        for L, hpa in WIND_LEVEL_HPA.items():
            k = min(range(len(levels)), key=lambda n: abs(levels[n] - hpa))
            vals = []
            for var in (u, v):
                a = np.moveaxis(np.ma.filled(var[:].astype(float), np.nan), (t_axis, z_axis), (0, 1))
                b = a[i, k] if len(times) == 1 else a[i, k] * (1 - w) + a[i + 1, k] * w
                vals.append(float(np.nanmean(b)) if np.isfinite(b).any() else float("nan"))
            if any(math.isnan(x) for x in vals):
                raise RuntimeError("wind file has no valid winds at %d hPa" % hpa)
            out[L] = (vals[0], vals[1])
        return out
    finally:
        ds.close()


def fetch_winds(lat0, lon0, date_str, scan_utc, sunset_utc, cache_dir="cache",
                fetch_file=None, log=print, now=None):
    """Download (or reuse) the wind file and return the layer steering winds."""
    fetch_file = fetch_file or _http_get_file
    path = os.path.join(cache_dir, "gfswind_%.4f_%.4f_%s.nc" % (lat0, lon0, date_str))
    now_ts = (now or datetime.datetime.now(datetime.timezone.utc)).timestamp()
    if not (os.path.exists(path) and (now_ts - os.path.getmtime(path)) < GFS_CACHE_HOURS * 3600):
        os.makedirs(cache_dir, exist_ok=True)
        tmp = path + ".dl"
        fetch_file(gfs_wind_url(lat0, lon0, sunset_utc - datetime.timedelta(hours=5),
                                sunset_utc + datetime.timedelta(hours=5)), tmp)
        os.replace(tmp, path)
    else:
        log("Using cached GFS winds: %s" % path)
    return parse_winds(path, scan_utc, sunset_utc)


def _region_samples(kind, az, radius_km, step=SAT_STEP_KM):
    """Offsets (ei, ni) in units of `step` (east, north) inside a wedge around
    bearing `az` (kind 'wedge') or a disc (kind 'disc') of the given radius."""
    k = int(radius_km // step)
    out = []
    for ni in range(-k, k + 1):
        for ei in range(-k, k + 1):
            e, n = ei * step, ni * step
            d = math.hypot(e, n)
            if d > radius_km:
                continue
            if kind == "wedge":
                if d == 0:
                    continue
                b = math.degrees(math.atan2(e, n)) % 360.0
                if abs((b - az + 180.0) % 360.0 - 180.0) > WEDGE_HALF:
                    continue
            out.append((ei, ni, d))
    return out


def satellite_dapple(lat, lon, az, elev_m, mask_arr, mask_geom, ht_arr, ht_geom,
                     mask_var, np, step=SAT_STEP_KM, layer_tops=None, shift=None):
    """Dapple (0 smooth .. 1 broken) from the satellite's own cloud pixels, for
    every region and layer, as {region: {layer: value or None}}.

    Each layer's cloud is pixels that are cloudy with a top in that layer's
    height band.  The same neighbour test as the forecast grid is used
    (texture at 1 and 2 sample steps), only on ~3 km samples instead of 30 km
    cells.  None = no cloud of that layer in the region (keep the forecast's).
    `shift` ({layer: (east_km, north_km)}) carries the scan on the steering wind
    to sunset (see shifted_layers); None reads the scan as observed."""
    anti = (az + 180.0) % 360.0
    tops = layer_tops or LAYER_HEIGHT_M            # height above the eye of each layer's top
    rad = {L: visibility_radius(tops[L], elev_m) for L in LAYERS}
    rmax = max(rad.values())
    specs = {"fwd": ("wedge", az, rmax), "anti": ("wedge", anti, rmax),
             "over": ("disc", 0.0, OVERHEAD_KM)}

    def pix(geom, plat, plon):
        x, y = latlon_to_scan(plat, plon, geom)
        i = round((x - geom["x0"]) / geom["dx"])
        j = round((y - geom["y0"]) / geom["dy"])
        return (j, i) if (0 <= i < geom["nx"] and 0 <= j < geom["ny"]) else None

    def layer_of(east_km, north_km):
        """[] clear / [(layer, top_m)] cloud / None (no usable retrieval)."""
        plat, plon = km_to_latlon(lat, lon, east_km, north_km)
        pm = pix(mask_geom, plat, plon)
        if pm is None or np.ma.is_masked(mask_arr[pm]):
            return None
        if not _mask_is_cloudy(mask_var, float(mask_arr[pm])):
            return []
        ph = pix(ht_geom, plat, plon)
        if ph is None or np.ma.is_masked(ht_arr[ph]):
            return None
        h = float(ht_arr[ph])
        if math.isnan(h):
            return None
        return [(sat_layer(h), h)]

    out = {}
    for region, (kind, bearing, radius) in specs.items():
        samples = _region_samples(kind, bearing, radius, step)
        k = int(radius // step)
        size = 2 * k + 1
        labels = {}
        for ei, ni, d in samples:
            got = shifted_layers(layer_of, ei * step, ni * step, shift)
            labels[(k - ni, k + ei)] = (None if got is None else {lay for lay, _ in got}, d)
        out[region] = {}
        for L in LAYERS:
            limit = rad[L] if region != "over" else OVERHEAD_KM
            grid = [[0.0] * size for _ in range(size)]
            cells = set()
            for (r, c), (lab, d) in labels.items():
                if lab is None or d > limit:
                    continue
                cells.add((r, c))
                if L in lab:
                    grid[r][c] = 1.0
            parts = [texture(grid, cells, 1), texture(grid, cells, 2)]
            if not any(grid[r][c] >= CLOUDY for r, c in cells):
                out[region][L] = None                    # no cloud in this layer here
            else:
                parts = [x for x in parts if x is not None]
                out[region][L] = sum(parts) / len(parts) if parts else None
    return out


def satellite_ir_texture(lat, lon, az, elev_m, ir_arr, ir_geom, np, layer_tops=None):
    """Roughness of the cold cloud tops, from the infrared window band.

    The cloud mask cannot see ripples inside a solid deck, but the temperature
    of the cloud top changes from pixel to pixel where the top is rippled,
    domed or has several levels, and hardly at all across a smooth overcast.
    Per region: the mean |change| in brightness temperature between neighbouring
    pixels that are both cold cloud (< IR_CLOUD_K), mapped to 0 (smooth) .. 1
    (rough) between IR_SMOOTH_K and IR_ROUGH_K, and 'valid' = the share of the
    region's pixels that are cold cloud, i.e. the area this reading speaks for.
    Returns {region: {"texture", "valid", "roughness", "pairs"} or None}."""
    anti = (az + 180.0) % 360.0
    tops = layer_tops or LAYER_HEIGHT_M
    rmax = max(visibility_radius(tops[L], elev_m) for L in LAYERS)
    specs = {"fwd": ("wedge", az, rmax), "anti": ("wedge", anti, rmax),
             "over": ("disc", 0.0, OVERHEAD_KM)}
    out = {}
    for region, (kind, bearing, radius) in specs.items():
        pixels = {}
        for ei, ni, _d in _region_samples(kind, bearing, radius, SAT_STEP_KM):
            plat, plon = km_to_latlon(lat, lon, ei * SAT_STEP_KM, ni * SAT_STEP_KM)
            x, y = latlon_to_scan(plat, plon, ir_geom)
            i, j = round((x - ir_geom["x0"]) / ir_geom["dx"]), round((y - ir_geom["y0"]) / ir_geom["dy"])
            if 0 <= i < ir_geom["nx"] and 0 <= j < ir_geom["ny"] and (j, i) not in pixels:
                v = ir_arr[j, i]
                pixels[(j, i)] = None if (np.ma.is_masked(v) or math.isnan(float(v))) else float(v)
        known = {p: v for p, v in pixels.items() if v is not None}
        if not known:
            out[region] = None
            continue
        cold = {p: v for p, v in known.items() if v < IR_CLOUD_K}
        diffs = [abs(v - cold[(j, i + 1)]) for (j, i), v in cold.items() if (j, i + 1) in cold]
        diffs += [abs(v - cold[(j + 1, i)]) for (j, i), v in cold.items() if (j + 1, i) in cold]
        if len(diffs) < IR_MIN_PAIRS:
            out[region] = None
            continue
        rough = sum(diffs) / len(diffs)
        tex = max(0.0, min(1.0, (rough - IR_SMOOTH_K) / (IR_ROUGH_K - IR_SMOOTH_K)))
        out[region] = {"texture": tex, "valid": len(cold) / len(known), "roughness": rough,
                       "pairs": len(diffs)}
    return out


def sat_layer(top_m):
    """'low' / 'mid' / 'high' for a satellite cloud-top height (m above sea level)."""
    return "low" if top_m < LOW_TOP_M else ("mid" if top_m < MID_TOP_M else "high")


def sat_sight_block(rays, elev_m=0.0, sun_deg=SUN_REF_DEG):
    """Share of the sun's disc hidden, from satellite pixels along the sun rays.

    rays: one list per ray of (distance_km, top_m) per sample; top_m is None
    for a clear pixel.  The satellite sees only cloud TOPS, so each cloudy pixel
    is a slab from (top - SAT_THICKNESS_M[layer]) up to its top, floored at the
    ground, and it hides the sun disc slices that fall between its apparent
    bottom and top at that distance, with the same layer opacity and correlation
    length as the forecast's sight line.  Cloud of any height counts when it
    reaches the sun's height; cloud wholly above or below the sun line does not."""
    half = SUN_HALF_DEG
    slices = [sun_deg - half + (k + 0.5) * 2.0 * half / SIGHT_SLICES for k in range(SIGHT_SLICES)]
    blocks = []
    for ray in rays:
        open_ = [1.0] * SIGHT_SLICES
        for d, top in ray:
            if top is None:
                continue
            L = sat_layer(top)
            hide = SIGHT_OPACITY[L]
            bottom = max(top - SAT_THICKNESS_M[L], 0.0)
            e_b = apparent_elevation_deg(bottom - elev_m, d)
            e_t = apparent_elevation_deg(top - elev_m, d)
            f = 0.0 if hide >= 0.999 else (1.0 - hide) ** (RAY_STEP_KM / CORR_KM)
            for k, sl in enumerate(slices):
                if e_b <= sl <= e_t:
                    open_[k] *= f
        blocks.append(1.0 - sum(open_) / SIGHT_SLICES)
    return sum(blocks) / len(blocks) if blocks else 0.0


# ------------------------------------------- satellite mask pictures (optional output)
_BORDER_CACHE = None
_BORDERS_B64 = (
    "eNq9XNuuJDdy/Bc9VwHM5P1RHi3svVheW9o1FoL+/zdczIhMss/pkVbQwpiZmurq6rqQeY2M5E8/ffP9v31zffPl22+un34q"
    "Lcl1t5LydT9/1f7KOmR/q/19PhbbTvt6XPblsM/4QtK1zuvPv4kDat/Kc+ZzUNdF1+U7vsn5Sus6z89uqVd5/rTn37p49m2x"
    "C4yr2ycc4IOtn+X1dbGrP0c04a7tshPtmXGu2ul2VNbLCPfw3Hr8zZeuE8raK2vPHiU/J69v1o8KDuDMdTjZwXWs2GnP14on"
    "5F06Ptvt7Rb25MLrrKsmu4PGP3vw9Owku6YdsCF9Bve5nd3TbiCKXd8UP1MxrH1NkKwbrDGyd48XtREsmKxqw5bWYwrf2h64"
    "2jM8Nyz6TM7zf32mYr3oet7n9+m5frrWQ80rxaMVO4Jjsl7EH9vf3eZN15vX9YUNsA3Fc3azcZ5rJOxt+jqSsPe8xCMpjzxk"
    "E0vI1lxXXL96LjHWj8q6zDPUmdL7POkwQev2oh1vPiAwzcbnXmfYI2Rc7XmWvi5kz4f5khixzm22gW7rWzxKWZete6wnJ/95"
    "QbtuN+GwA3VdA+K97vkIzs/XT6XPpVWlDEzJeudqkpf47zmc7MQx14lV8CL2Hmu4b5trNYG0QbftukJdPyvtObu1Dq1+XlzW"
    "y1YItY0stEp+/vk5/Zvv/xI2ompao6UZd0m2FW7FNFgo+hDeNf1ikvIcgC42qqtNz91M8AVKtI7Z7jONz52r5vWgxYR4uuZn"
    "PHWCQts91wEYm4y3LxyCZWFUabDEDcC637pddb2yuX6+Eliu6g8nybampibUa+DDLmLIC+6o1Jrpz2jjkKhGsDvNhKhhAjtE"
    "Tdwu8e2W6sOqrOdzKVy3bRBvzskP227XscaxZLGRrs8fngpztWSfr9ehH7fAbEulgcumyR2/SaZozxuFoSiwVOsqplVq112C"
    "rCaGZS4x1ISZURoVxbxow0jRsMAGdRcV6Mi4lBtzEoUKk7e9xzwr5OXulz85VMSnu/kYQzeFE1VpbQasL0w/JvmesednT9iC"
    "hlks9kKJStHC6djZGF06xcIJ5622u4HNkWUhcevpvs1+1c0MmvNaw6PLjKj9z/FZFxYO+fKOyxbalc2k297SXoGGwx3y2Qt9"
    "0mMp+7r8M4bPICSTfNcmUXeBeKhKs6Vu7+a6tGQ863z+ZFObaQZ6/Ya/tpcVvLna7xWDODivmaNo2mKSNNYTPe++VGyJ7BLd"
    "YiKlS6Sadur7Goy5XoBqeTfqwd+2bZK5jO5cNkNipPe0P/tC0adiQjBenH/GZf/r+8PklXUNaSm84bZCFLIMw7DsHjywvaS9"
    "NuYcQYBpguniI96N0cm8MMfTQydGJzf0RtxODJoAMX+/BATOiDcTE3kx5TDZfM6cNnf+4zVPH7f1K8d9K2/PsasJVdkcnfA9"
    "JqdH6LaW2V6PoYr3VnegYgqf1Y51uN0Mh/EcH2EHhXreGRp0+JFkco0wQdwpCnxXt5cfcRuMigUSaiZP7TB1CMJX1siaAY1z"
    "1wkj4kZMsktjx8zCFSw7mWs4B5pyzMSOKBQhb55u02pYExgbQaAC0Wpwa+vSUigADHrNR+kxezZmCKMxM9yHHkPO7AoVP24U"
    "KhM5U1PpVAIPfRk+aASnOcLd5E6BdrDy6XB3e8Is+3PHS1S8PeTS1A7Ko7S9mvm/e3bh5xLf41sM6YB8KxVcPQ6G/yvmmixQ"
    "heHqMB0mDo/EDIunZAnmcmb2O1M9tdHRQ5/U3nBNYmjYcFUuF6QCXpRPDeETDLwdU9PsuX5uIe4tiE4wfsntLfMnOkXTqwGX"
    "8LzeYOCbTewVCYYg1JIIOCo9lDuWmy4X02JOSy4IArbDHiy2mt7vx5HMR1uvAgmzF534b/hBzNFxMtO+csQGc4V3aa5QYFa8"
    "oCK0ZzJ0U7ndu2Fi11YRL5q1sLACJvuvfzgy2bI0NA9mV2vYBkZSKtyYGxGMgk2oID5ab2WOdE2gmWmbwZ3tUTdH/KfhOjtm"
    "L3GSqUGcYZXLXci4ukevEyauIm9hwtg9dxXziZnXGW41xCOcwfTPbcY63mxKlLs2d50pZGSVCGE8S57I2BgIuv2uiNeHZXvd"
    "fE+l/+m8M8I0ofKuRGKGBTkT+EwhfgYEk/XfX/ZkjaSWjTCwLp7vN08kMLyIvxmsWFKlnJMMt8ETMPw21hNvnjz5lcz0qEdA"
    "BxXMHv4Uzw1pkC3qUQzEvHzk1J+vxYTQXpkdslG3MJIWN8x38TfxxJvxZj+ADE607DEMDe8eSol7kO4vFbb4hBeUkU7xpD9v"
    "s1D2W+fIAuTwPwEQVIxYjltNQjtn9qfHVvY80AmdJyl9iLnlZ3QsGkV8oMuam52xlLRAZmHFzXhLtfjTAI2lnn1FyRXnmp2v"
    "puljGXVd39kJZrQb0iExr16WR1gX7uvvxHWrxaIIrexWiE/b+pTNEq3TL7v3so6y7IJYcJztGbI9aTFPYTatLPnNS7Gy4zQr"
    "dWke8C8rKQSaGo16o7gum0SL3U75Fdp42ILhRiGCByn+xYzUFyIrUEGAQcPNR3Ul7rRgejj0akl4Mf3M002WC/7OZT08kAse"
    "ShzKirgNfr0xoc1AjWDfCA7Y5RsjOyYHwDsAGyANzD4w8D1rlronfcqUJrRDNiQAKMyUWIE5JbjhTIjCzJ2aX7CsP6+pzXh/"
    "A1lSC8CBoanvEgHw7JhoVI0A1k+ZDJrVMY5bAC2ZemCTzC+usKepWCYsZrHEsmPE8bgxg0DH7WyKs4mSIF3mw3YPDpZmQ7uz"
    "TVuWbcgK4ig+ZHezKw5+BOZbwx7cABgdQTPxoM07jJu6nUAsWInEmtQ0h9Ek7DrD1BkZPCNYSyQTw+mywboa7znxMs1jKIFE"
    "Le1+Jm9LDVKLDjhynZURvg0/pTsUfROh7kSfLRjNEp5fgWogvG/b4Cv/T4hyYfs1BotwlfQTsC609IHIMR6sMSSZV044S+Eu"
    "iG7OcAGwFRlPV5CoaGUOnLevVpPXDphyGXeLTZdctBA24vnEQoTeECm9dgawfDF1fMZABxNBal1jQteR1gZsp4eXgXu4HHbo"
    "BMcyFNR1ZcBnE0OmObVrZ43bQXJ1Z8CI8n1arwkogPdgJpAuy5wsvcWmYm/durx+c359bmSEGUCa24kIc5ANALOgNdsoI2Up"
    "xLsY0Q8ayHI5ZlXoeAmVdoDpxaLCDkPrGQXlAoWEar4QmIoFvGawiCUjtCzAJBURbjIIfWEvM60oQxWgtj2FWjCoSH9qBnzY"
    "HcZMV+CLd7WUxdy7wnvbA6+414Sx2K+AuSsqANli42qSsfKCB55eyiEpU7OLiaagIpCu0++Jrh/UddWe6+nDiqsesRgbtSUT"
    "BepfIhtuAQHZteqas9yT65zQMgR+YIJEoOjbhY3/7YcVyOZsBYaxhHGZU9OiX91TYtCG5wBCkXARyWTzqOx82gBQ/6Vz+qdz"
    "ljhBbbOrGY+c+1/7Vt+czyMYki8/xpAUXSXFLsPBkXG97O1Nj6pFY0DuLtwdp2cGCpvD6aGL7zAbHkiXHYmXxEuZVLLeMkyg"
    "MqtMJeLfCeyOsf6xk/aRG4HJvJAhcyfxIHRYL4Q3+B/lufebqN7BCmIEv/uyhWqsEk/vKUdNkTa0I12sBAkGUz3WB777w3GJ"
    "ZbN7TVGfjShc9fIj/ueWK336g0CFxZtf2NaQtWFOJTPPFtqYwCUYfM6zDMukrG6YcO6wdTl1dRfthZbKq3HMS0C9HMd///ZQ"
    "zmXURtWoMZqI7a06mnMeyY6Pf/7Vu28TAM3LALhsn20vYSPcQ37k4OkZLyDiEVRRWbHKcFSDBaHu6e4TW6hnvsN81UqN7nkh"
    "gNBEH9cuzwkVwlKixGICJFTbP/7lUNtljMcYFiXXY7NcTY30wSMwhqDDi26V2zvjSX3LKkF6tz1A5Xxg8+2lQF/or8LjBNrc"
    "PTOpEbEQYTz2X4tFR20r6nj5cwqRGH/ozieYW9BmedUnAJ3mmXMPEJ9AZfdn0BRFTH9Giw7Ltn9KL2ZRJqfo+y3Pva+gdCQL"
    "ZgCDJ2ZfnakVYKyACVNUPJnwIxJBLgRwbTBsUEJuUgj79IsAolcbUmCTyjy9AYDPdpcIqVz2P2zk+JhYX6+vJ8nXP3KMdIPd"
    "0Dv/8LVDIUQaNai0uS7CQCpfRxEsguoZBwJcSQAiNSglzQ0shXfQKxVPahoLYTzSWPw8AKf2ktCLG0SWyisDxXxCPBRR2XhP"
    "27ibOMxz1CjhQcpWtAi5w7WWeI0edopARSfGrQ5WnQZG/F6yYSavrSlttO6HaoGIhor7HMmhh5srQyQV6vDnfxzqIKYOwzQM"
    "oK3lQYAUBgNzMCIq0f5kPtQQy3GRYuK4BfxWJniMquMm5kB7mkt9jvdXKhRuSzLDZkTgC7jCziICsOhummdkEyAEkYkqvyum"
    "WF74KmQj3ajGJ3t29fslFMQCH3Uv2wI3YQg0gJ6xpmwfmz0F1H7a/oDryGEDGgMmYYCTWJIQAMTTR5g8KBcPZ08lSEHhaMJe"
    "MOlJNh6DHs8S2LFzjO7uNsovDU/XwEbAB1MgcwvSjKNweb2xMEiaLJ07f6ueInnvOleOWITJKbMwy2+BWsgI/18sELVoFTot"
    "zXVhBNSRXNtZRpibSxJIjauf7GjMtfzdMdQfxeCdvV/fHE+xzadxLP6h8M3nJryI+9l5RIPtQNrP7YBi/ue37zIAVneRURG8"
    "+rUtrewdVZ+Bx9u5g5wf5+VkkmwCPhnrL+c7rnzsFyemuVNLrxsG9kL3dAslpgS/Drv1/LwublUwNQ6jkZkq818vmpJOB1my"
    "lJSWxsuvmNXgNOkRtvQX9kkmWWDgbQ3o0KPiIqHs5EO5pFoa3C4iNZe4l9Erb99BmwZaYwpqmJBAVHfolaPKEISAHCB09Vqg"
    "ICQ5YjyDK4j+CV83AnF7rLodAMaLpY2MLC5hcGEmCBN7KtmOXAfFoL6Se1nkkJ4qJ2S464YjsDtWeATDAsRoOXMOzkMxSTfi"
    "jUPdmVUkoIiU/+/e5W8mrMNK0TdBEgSEmbG4CME3xmdCb3U7quvR4SEyclBQd5m+ujzR+aSIRZytMYIOgA9588+w4wOpl1fZ"
    "m8PW6XBr/FsCxJUWNJ/MqoIQlbnBhQAkZN5EnSyakMscm/Lm2D+7KWGiAAW3X9wiWn2X9spLAmxPqReZWQAg0lFngGs7OMRU"
    "Qi/m8Xg/SdXt4CDNk81YkA8kSgU8XOUksMIKrp/uwObMnRil7JAq7/zFM8AJV1lZzcg7Okn4zF+DnCRBTurHU2cAa8kCBNa1"
    "1b+fjJPUtuanJ3MQwNaRSa/DY8MsHlY2e0W5wGSjShMh2zF6fkkV9RDl4XOSN0HUI4QYl3SEnzUKN7R3lfozA5v1+1QADp7L"
    "O0/cY3cHuqqThDx2qHHqDqmL17BGgMEavCoQuDTHiSwMHB8C9n9O9OrdvnvjeQCnj4BkYDYHTIpFOtOiQjNy68zHnOWVZD74"
    "ESEjJJWg1JRduNmhE23gBqBKNzLfTDVyZWe2CpmtRlEtREZJpGM0eA84WECZZPEW6u8ORpT78koEmCdJxm3hrsLpkXbkXamj"
    "SVW3sjmUqaFoIPGJuviiZCWSMzlc6QvJ0pVHifWjZmOTkPn6zBh8U7dTz56q1V2gVyYLngNKDai0R0Cpkc96IiibdytRbmKp"
    "ZtssJ4a2mDv5kCcHf9kvvBsoKBd9S1yJKSle4CDOiwRpXJvJnZwJ1K4DAzpoF+PyumA6YKDOgILBRdnFy1siGcTLzT0bPbhH"
    "jvK8kBBZ+HWc2t9Eg0RxHy0fYNQEq6Pt+t2MLJ41CHG2CUujErShQuNLSuQkvFS8eCVehT63ypDz05e/5XAin5Vq6hOVmXei"
    "JEOqRuSlyrc2STbwPKH0lJEZWpxVCAwXWGJBl0ey6NlSXrDUMiJqyeSJOPfDKmfC+LBdLRJq+GTHacRYxCvPaUMOoKKdRUiX"
    "dWBm3Z2sAlA3QQfB3epVo+nJ+K/Me3eC/8gzjd8ft/EbVgEd05IJI03DkisMfKfc9YsyTEokyZQ64+BxsjFQli7NvT2PfPzW"
    "WnZ8mxjx28w3FgnhpzNzHeb23p+04xdyuCUASy8iizfKiJfoGqFCJxZJ91YwkoeUpdrmWMg6hgho15ngYzzyjn31JrPCkueq"
    "UG5GqtNHZUZuIcFHBWzgmVSP0jnhN7KzevC7xetJEWvLNjhM8XcKff5XTEU+wt3yK0fsDQGiDGyKiUExKcgGgNbLyNnLvmlG"
    "axR49PZ5DSR0ZJLf5AVMUrGzcTWOvJ0vcr6cePfchPIXh70sII3a5JaMRGXajUqAhb3YzOAyw6myewMl67YtR712ja+QC6UH"
    "p9yFsFPTftipVk1WtQCzYm7nHvEd7QBbFNhR9M9+WpEQ7zCNLND3hr0IXz4+S4Zfy/Ku9KFoQYI9ZR9HB0UZtGXUJ5d1VATF"
    "GfYv40twABptUCJ47ySOdGBvRwFAiGhOBPjjcnhrgPo0YXXRaAFAMBmyVu1TCTJGtltwsz7343Mc3J/7px+9/FLL7qcSj2iB"
    "AKD+AOikUxYCmPfSj5f9K4JkdUfQPNopG25vTjYuiHwDa0vE64UoRHRYkNOmcA6g50QPLMunLHyMiz2SKcLzFu2fZOpKYZtq"
    "PswNdC964DyMKFEB1B1njaM9F2hMd8oSmTP97C6sL2WHKHkMT5DHFc0GytJOJ8xaL3U41fslo6TFiHK6CQjuc9q59wiemEeF"
    "LaKsg57hHnQE+UnykczWg2S8C/9wwYOA3Vbs4fWDFJx6grzks+kGcLMjZKJvPm3mMIAEN0jn/nlkeEaDSKQePULKcFAjjEwH"
    "ApEOTCJ9QinSdj/bNbHqOiMbBd0hfrDsVatLJuqYtLmY3ez8m4wn1BxEymHTPczWDWMNNJ9bcdJ5j7gg2Xlq2WGNCWWTlVR4"
    "pQliPS0/G04axR0uyFuq7HLrvXrtw9tnEqPJNYT2YGU9Um81Of6QweA14Izl34iqC35R7Rc1krJyuTgKc6vnvWjF/2PHbhXg"
    "dVXyfCewQZOMfnk4laJv9XX7247r++OdeiU0JhPpgDrdIzqJ8kEN3ZGLhr56JvJRdutXpTkFzgsEIXun+2COWsFjcvAo0flk"
    "81ogYk+TgOaBA2cpA0RAOcisT2Za0KIohJpNvYi4C0keuwP2T9vbGkL7MFy6OcUGmpuwEMhuT1A5S/RiT+LHyFus/8vuPZFh"
    "U3QtnbLL5fgTBjGYyOnjkfn65XCCpBdXo/iqL62gJCnk6H81Ckxlzu/AbSC2bgtxHYmyPtXryMdVIgMdrOkKjbkeNAlPOuXg"
    "lOcz57mPprTm5OBMvne6yMHxcJAtgWREesCenMRYLbwoljkoUKBqlOs8V4N6L6w0IBdIDE6spYwi8I+TsrK+mh08f8RLUd1E"
    "vdcuolE9940vveCAgKAiG47e+gws/yyArY3JaRRQq5+B55DRN21fwONAaNFdv4yhmHgj4cJTQVgzuhCzoaGqkNzd3AsprQ5u"
    "F6v+yuU5YUiXE8TZRNMCUD46XOo2FlHokb1mQaBkspfZ2JB/2atQeHMRjNl44ehFAMCy3KZNsDJAMCa7FI+jZTn2QxH0yhGg"
    "nS80z8jtw4dEsIKg2n3CUG0zgZxSof5ITBUDRApFLWbPmOEycgi1LBGpFmdt1oOcVHdXbD2255EcJJLqCW4JvDY7vu9p0sGJ"
    "ViKwjsuNFyuePsQw5f/l2993TUh9PhYRMQAmrRUGulYJlifTHNRAsHaIeGZZPVzn6id3OfsXJO/FAbwmdZccgSj57jXKMUro"
    "RGL5DT3YZnUvhKMkaRTDMAsYy5ybwtQLxRJmWxsum+Z5QEQZMCXWiVQAomHlhrSbzCqitJKqmqWcF/1OvbAiyrV5M3f0ky/7"
    "zgb3I8qxvvknV0WCMr1JnYjUhTZPtQFW82pomY3jBkzU1UihjuOk19rrv3a/RtVBQ42Ves+2CuW08qNbqLnxjX40dR+d/Xo0"
    "Zpco42zXXF5KX94Ls4kKunlmeVMNScypHxhmu8dk7vRMaIljCaa4fT+6/jSWKCEJZHpH97jGsfhJPxdEij6hyJNyrEvUvPbk"
    "uFs/ssERodMRgaSoem3eTCXjlQRYef8R/sRYKTnHBhgVcCsSSf56EkkWoW8seTekqzsoMj7Ylm1hDhvyafObvvjXXOXTF97i"
    "nZ3MpIG5st8jIq92LB5VIqsH9aNEMLML+TmS5L4XN6n0sp6b6jFx+lIVcu9NVLs7YIK4qDH0uLk+gshBcTxi0uyyols99bVm"
    "O5xlUA5S+u/ZfuU68lu2XkB5oerLm70UH3/3XnLO+v8cpQNZsPLDnSr0FZn9kYigx/GvHv9HfM0qTrv2yjO7N71GeS3HYmZE"
    "mw4ZY+lTPN3I4X+9/9sJzbi8kWZWv2QX9RyHmavT/PKxgkEDTuE/AWrFwjvbJ3QzPxn1//DlZPWvJ5B6gHoDyF6LJP+s2y4L"
    "BvBtMk2bpkUKe5ErBSYB5chhkDMxZSHtF2iyxXHIbTrJSIiUhSXtG61aE9Aqgbx8tu4czTkfdmvsbiSXHqYwN67kQ3hLjXyd"
    "qPaOs0Yul7z7hI5b0Y+fgjchXNuJyztVli69Kcx5Gym4RkSbnFTN9kJG/JjaH7//iKDXpkeR/wTE+svxz1v5xW8/bn1ZBLBo"
    "tJ9bIGlA/sU7/byF1Ddtr3VHxRK2LSegATncX3n1iyB1Y1uO/XfH08FVkqMIkzbbGFniwJWZndojqrDOF6D2DmjEg4rK0RjH"
    "sgNOfy+bsTJiEbQcGK8cOWM+WBS7ZpAOV5N3/BxpohwgRD6We/MlDliy0xyYRpTv267hiW7KQYqsMJg5Go/nbQKbCEsL8/ej"
    "b2jMZYO7RORfjyqgHmliD5itH3DM5nkSd77QlwYgQ/tZ33eMau7VzLJfLZZrQCGsXuyIjvWNuNxSsJlADHWMkKu+OCbDxmAy"
    "Q7wh/+5R/8gb4tnRBfFHRePYOce4QXemtFcQdoNpRDPtIC31YFUF2T2jmF6CMY9mh8RHdptKCmxxChmpiZNttc6FESdaTdZV"
    "Kismzt0be5krq0Ldub1sJfb7pyOfz+xvfhu9nOXaHfGw4+cyGWNTs4uZcSxbkVCRH5f1sQth9W4cfUnIMY1VYUsOoA0s972S"
    "h8Qc5OBvVNKFmSZ29gX1C40GnSx7EPrQw7t5+t7VINehDwk/lyANoMDo6Fb1FR64+GVBp4VhXVycaRq+2hwTO/gh3pvpS8al"
    "c8W7wny3EozPbJFg3l2PFNvoDuz+TWSFd198YlA/etDMOvDminJsLO5Qoof0Pvhc2dcKs5usd1weo9tqdLWxk8q5EVgoQYN4"
    "EuVzJnYl1kEovsCQd65yCTNbUQrv0cCuaSdLr7L4njbgDKbXOpX27cePJY4M39JjHQqNTTBA9qIAshPM6oWHA0I+lm2MtRKi"
    "RriTkxE5St0LZDRHaYb7lXI4DY2FD3xRoHFa9iOr3S1DjXNHX+AA4QtIkS55PTIdthEylDxOL+SoDg/fvcPyaF1y1ho5weLl"
    "eva1oEyXN4aVWbg/O419/bloaTGKEqbvf48UoaVJRoLT17oX6zQemaaw0JD6nLlF1hTdATm+OgCWFzTUGRUEOjLpAT08ffSl"
    "+K82GoukdbIV3xbkxTJuO6ayPvLJhYEjTvToY5JR3o5V4xK7CCS6KveiGHIuToksBdQXAH2wty9bjvDfj86yVVh4KGS+ApIA"
    "ZqcitOBvFl/hR8QXb0hE970z2tFoo7GIcGGtzFU6sc7XCKCoI8yfMMoaLNG6u7w0FvhM/KwQSWU2kknLBn86EZtsXBfizqTf"
    "ZnsQVLpkmEHmfPQVQGKlpG5q0A5iAeuyu3aZ3u5/PPIC8P7CZi/5lWKtXEH90UqHRojTQH1tRSbQiC+NOsXugGDZPRjuyiJu"
    "rJFKvotw2bO7ukKx0183U3gvz6sfGkhzwHtsDxXdXZ19r8THVowRtj5CvfGyLDcXiBw+gic7tW6MMlYhpS3sx8d5nOzU9KhA"
    "7Nxfd8jgJrocaGj30sx0kjACcfW+pM5f5p2xxzK6xT/O+Fp9ccgUdOH0SsiW3Qxdz8PqK3MkH1M9YFH3pG7/+1XPdWBJSm6B"
    "nLEhelWVf/4/umfayQ=="
)
MASK_FILE = "masked_result.png"
MASK_DIR = "Masks"
MASK_SCALE = 2                     # screen pixels per 3 km map pixel
MASK_COLORS = {0: (0, 0, 0), 1: (30, 45, 70), 2: (90, 170, 255), 3: (255, 200, 60),
               4: (230, 90, 200), 5: (150, 150, 150)}
MASK_LABELS = ((1, "CLEAR"), (2, "LOW TOP"), (3, "MID TOP"), (4, "HIGH TOP"), (5, "NO HEIGHT"), (0, "NO DATA"))
_FONT = {
    "A": "01110 10001 10001 11111 10001 10001 10001", "B": "11110 10001 10001 11110 10001 10001 11110",
    "C": "01110 10001 10000 10000 10000 10001 01110", "D": "11110 10001 10001 10001 10001 10001 11110",
    "E": "11111 10000 10000 11110 10000 10000 11111", "F": "11111 10000 10000 11110 10000 10000 10000",
    "G": "01110 10001 10000 10111 10001 10001 01111", "H": "10001 10001 10001 11111 10001 10001 10001",
    "I": "01110 00100 00100 00100 00100 00100 01110", "J": "00111 00010 00010 00010 00010 10010 01100",
    "K": "10001 10010 10100 11000 10100 10010 10001", "L": "10000 10000 10000 10000 10000 10000 11111",
    "M": "10001 11011 10101 10101 10001 10001 10001", "N": "10001 11001 10101 10011 10001 10001 10001",
    "O": "01110 10001 10001 10001 10001 10001 01110", "P": "11110 10001 10001 11110 10000 10000 10000",
    "Q": "01110 10001 10001 10001 10101 10010 01101", "R": "11110 10001 10001 11110 10100 10010 10001",
    "S": "01111 10000 10000 01110 00001 00001 11110", "T": "11111 00100 00100 00100 00100 00100 00100",
    "U": "10001 10001 10001 10001 10001 10001 01110", "V": "10001 10001 10001 10001 10001 01010 00100",
    "W": "10001 10001 10001 10101 10101 10101 01010", "X": "10001 10001 01010 00100 01010 10001 10001",
    "Y": "10001 10001 01010 00100 00100 00100 00100", "Z": "11111 00001 00010 00100 01000 10000 11111",
    "0": "01110 10001 10011 10101 11001 10001 01110", "1": "00100 01100 00100 00100 00100 00100 01110",
    "2": "01110 10001 00001 00010 00100 01000 11111", "3": "11110 00001 00001 01110 00001 00001 11110",
    "4": "00010 00110 01010 10010 11111 00010 00010", "5": "11111 10000 11110 00001 00001 10001 01110",
    "6": "00110 01000 10000 11110 10001 10001 01110", "7": "11111 00001 00010 00100 01000 01000 01000",
    "8": "01110 10001 10001 01110 10001 10001 01110", "9": "01110 10001 10001 01111 00001 00010 01100",
    ":": "00000 00100 00000 00000 00000 00100 00000", "-": "00000 00000 00000 11111 00000 00000 00000",
    ".": "00000 00000 00000 00000 00000 01100 01100", "/": "00001 00001 00010 00100 01000 10000 10000",
    "%": "11001 11010 00010 00100 01000 01011 10011", "(": "00010 00100 01000 01000 01000 00100 00010",
    ")": "01000 00100 00010 00010 00010 00100 01000", ",": "00000 00000 00000 00000 01100 00100 01000",
    "+": "00000 00100 00100 11111 00100 00100 00000", "<": "00010 00100 01000 10000 01000 00100 00010",
    " ": "00000 00000 00000 00000 00000 00000 00000",
}


def _png_bytes(rgb, np):
    """Encode an (H, W, 3) uint8 array as PNG bytes using only the standard library."""
    import struct
    import zlib
    h, w, _ = rgb.shape
    raw = b"".join(b"\x00" + rgb[r].tobytes() for r in range(h))

    def chunk(tag, data):
        body = tag + data
        return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))


def _write_png(path, rgb, np):
    """Save an (H, W, 3) uint8 array as a PNG using only the standard library."""
    png = _png_bytes(rgb, np)
    tmp = path + ".tmp"
    with open(tmp, "wb") as fh:
        fh.write(png)
    os.replace(tmp, path)


def _draw_text(img, row, col, text, color=(255, 255, 255), scale=2):
    """Stamp upper-case text (5x7 font) onto an (H, W, 3) image; unknown characters are blanks."""
    for ch in text.upper():
        glyph = _FONT.get(ch, _FONT[" "]).split()
        for gr, bits in enumerate(glyph):
            for gc, bit in enumerate(bits):
                if bit == "1":
                    r0, c0 = row + gr * scale, col + gc * scale
                    if 0 <= r0 < img.shape[0] - scale and 0 <= c0 < img.shape[1] - scale:
                        img[r0:r0 + scale, c0:c0 + scale] = color
        col += 6 * scale


def latlon_to_scan_np(lat, lon, geom, np):
    """latlon_to_scan for whole arrays."""
    req, rpol = geom["req"], geom["rpol"]
    H = geom["h"] + req
    e2 = 1.0 - (rpol * rpol) / (req * req)
    phi, lam, lam0 = np.radians(lat), np.radians(lon), math.radians(geom["lon0"])
    phi_c = np.arctan((rpol * rpol) / (req * req) * np.tan(phi))
    r_c = rpol / np.sqrt(1.0 - e2 * np.cos(phi_c) ** 2)
    sx = H - r_c * np.cos(phi_c) * np.cos(lam - lam0)
    sy = -r_c * np.cos(phi_c) * np.sin(lam - lam0)
    sz = r_c * np.sin(phi_c)
    return np.arcsin(-sy / np.sqrt(sx * sx + sy * sy + sz * sz)), np.arctan(sz / sx)


def _sat_scan_grid(lat, lon, east, north, mask_arr, mask_geom, ht_arr, ht_geom, mask_var, np):
    """(codes, heights) of the scan at each (east, north) km offset (arrays).
    codes: 0 no data, 1 clear, 2 / 3 / 4 cloud with a low / mid / high top, 5 cloud, height unknown.
    heights: the cloud top in metres above sea level, nan where there is none to read."""
    plat = lat + north / KM_PER_DEG
    plon = lon + east / (KM_PER_DEG * math.cos(math.radians(lat)))

    def look(arr, geom):
        x, y = latlon_to_scan_np(plat, plon, geom, np)
        i = np.rint((x - geom["x0"]) / geom["dx"]).astype(int)
        j = np.rint((y - geom["y0"]) / geom["dy"]).astype(int)
        ok = (i >= 0) & (i < geom["nx"]) & (j >= 0) & (j < geom["ny"])
        ic, jc = np.clip(i, 0, geom["nx"] - 1), np.clip(j, 0, geom["ny"] - 1)
        data = np.ma.getdata(arr)[jc, ic].astype(float)
        bad = np.ma.getmaskarray(arr)[jc, ic] | ~ok | np.isnan(data)
        return data, bad

    m, m_bad = look(mask_arr, mask_geom)
    h, h_bad = look(ht_arr, ht_geom)
    cloudy = (m >= 2) if mask_var == "ACM" else (m >= 1)
    code = np.zeros(m.shape, dtype=int)
    code[~m_bad & ~cloudy] = 1
    layered = np.where(h < LOW_TOP_M, 2, np.where(h < MID_TOP_M, 3, 4))
    code[~m_bad & cloudy] = np.where(h_bad[~m_bad & cloudy], 5, layered[~m_bad & cloudy])
    heights = np.where((code >= 2) & (code <= 4), h, np.nan)
    return code, heights


def _sat_class_grid(lat, lon, east, north, mask_arr, mask_geom, ht_arr, ht_geom, mask_var, np):
    """Just the class codes of _sat_scan_grid."""
    return _sat_scan_grid(lat, lon, east, north, mask_arr, mask_geom, ht_arr, ht_geom, mask_var, np)[0]


def _shift_scan_grid(lat, lon, east, north, shift, grids, np):
    """(codes, heights) after carrying the scan on `shift` (see shifted_layers): each layer's
    clouds are looked up where its own steering wind brought them from."""
    cloud, top = {}, {}
    known = np.zeros(east.shape, dtype=bool)
    for L, want in (("low", 2), ("mid", 3), ("high", 4)):
        de, dn = shift[L]
        code, height = _sat_scan_grid(lat, lon, east - de, north - dn, *grids, np)
        cloud[L], top[L] = code == want, height
        known |= code != 0
    out = np.where(known, 1, 0)
    heights = np.full(east.shape, np.nan)
    for L, want in (("high", 4), ("mid", 3), ("low", 2)):         # low on top, as before
        out = np.where(cloud[L], want, out)
        heights = np.where(cloud[L], top[L], heights)
    return out, heights


def _shift_class_grid(lat, lon, east, north, shift, grids, np):
    """Just the class codes of _shift_scan_grid."""
    return _shift_scan_grid(lat, lon, east, north, shift, grids, np)[0]


def us_borders():
    """Regional state / province outlines (Natural Earth 1:50m, public domain), as
    [(postal code, country, [[(lat, lon), ...], ...]), ...] for 33 N / 89 W .. 52.5 N / 62 W."""
    global _BORDER_CACHE
    if _BORDER_CACHE is None:
        import base64
        import zlib
        raw = json.loads(zlib.decompress(base64.b64decode("".join(_BORDERS_B64))).decode())
        out = []
        for ab, country, runs in raw:
            lines = []
            for d in runs:
                la, lo = d[0], d[1]
                pts = [(la / 100.0, lo / 100.0)]
                for k in range(2, len(d), 2):
                    la, lo = la + d[k], lo + d[k + 1]
                    pts.append((la / 100.0, lo / 100.0))
                lines.append(pts)
            out.append((ab, country, lines))
        _BORDER_CACHE = out
    return _BORDER_CACHE


def _blend_lines(img, polylines, color, alpha, np):
    """Draw anti-aliased 1-pixel lines (each polyline = [(row, col), ...] in float pixels)."""
    h, w, _ = img.shape
    cov = np.zeros((h, w))
    for line in polylines:
        for (r0, c0), (r1, c1) in zip(line[:-1], line[1:]):
            n = int(max(abs(r1 - r0), abs(c1 - c0)) * 2) + 1
            t = np.linspace(0.0, 1.0, n + 1)
            rr, cc = r0 + (r1 - r0) * t, c0 + (c1 - c0) * t
            ri, ci = np.floor(rr).astype(int), np.floor(cc).astype(int)
            fr, fc = rr - ri, cc - ci
            for dr, dc, wt in ((0, 0, (1 - fr) * (1 - fc)), (1, 0, fr * (1 - fc)),
                               (0, 1, (1 - fr) * fc), (1, 1, fr * fc)):
                r2, c2 = ri + dr, ci + dc
                ok = (r2 >= 0) & (r2 < h) & (c2 >= 0) & (c2 < w)
                np.add.at(cov, (r2[ok], c2[ok]), wt[ok] * 0.5)
    cov = np.clip(cov, 0.0, 1.0)[..., None] * alpha
    img[:] = (img * (1.0 - cov) + np.array(color, dtype=float) * cov).astype(np.uint8)


def _draw_context(img, geometry, np):
    """State and province outlines, faint distance rings and state codes on a map picture."""
    lat0, lon0 = geometry["origin"]
    step, reach, s = geometry["step"], geometry["reach"], MASK_SCALE
    kx = KM_PER_DEG * math.cos(math.radians(lat0))
    to_px = lambda e, n: ((reach - n) / step * s + s / 2, (e + reach) / step * s + s / 2)
    # distance rings
    ring_lines = []
    for radius in (100, 200, 300, 400):
        pts = [to_px(radius * math.sin(a / 40.0), radius * math.cos(a / 40.0))
               for a in range(0, int(2 * math.pi * 40) + 2)]
        ring_lines.append(pts)
    _blend_lines(img, ring_lines, (150, 170, 200), 0.18, np)
    for radius in (100, 200, 300, 400):
        r, c = to_px(radius * math.sin(math.radians(112)), radius * math.cos(math.radians(112)))
        _draw_text(img, int(r) - 3, int(c) - 8, "%d" % radius, color=(120, 140, 170), scale=1)
    us, ca, labels = [], [], []
    lo_e, hi_e = -reach, reach
    for ab, country, lines in us_borders():
        inside = []
        for line in lines:
            px = []
            for la, lo in line:
                e, n = (lo - lon0) * kx, (la - lat0) * KM_PER_DEG
                px.append(to_px(e, n))
                if abs(e) < reach * 0.92 and abs(n) < reach * 0.92:
                    inside.append((e, n))
            (us if country == "US" else ca).append(px)
        if len(inside) >= 8:
            labels.append((ab, sum(p[0] for p in inside) / len(inside), sum(p[1] for p in inside) / len(inside)))
    _blend_lines(img, ca, (235, 235, 235), 0.30, np)
    _blend_lines(img, us, (255, 255, 255), 0.55, np)
    for ab, e, n in labels:
        r, c = to_px(e, n)
        _draw_text(img, int(r) - 4, int(c) - 6 * len(ab) // 2 * 1, ab, color=(205, 215, 230), scale=1)


def _render(codes, title, subtitle, geometry, region_mask=None, outlines=True, np=None, extra_rgb=None,
            legend=None, context=True):
    """Map picture: north up, east right, observer in the middle, state outlines and distance
    rings (context), plus title and legend.  `legend` = rows of (rgb, label)."""
    n = codes.shape[0]
    if extra_rgb is not None:
        base = extra_rgb.astype(float)
    else:
        base = np.zeros(codes.shape + (3,))
        for c, rgb in MASK_COLORS.items():
            base[codes == c] = rgb
    if region_mask is not None:
        base = np.where(region_mask[..., None], base, base * 0.22)
    s = MASK_SCALE
    img = np.repeat(np.repeat(base, s, axis=0), s, axis=1).astype(np.uint8)
    step, reach, rings = geometry["step"], geometry["reach"], geometry["shapes"]
    if context and "origin" in geometry:
        _draw_context(img, geometry, np)

    def px(east, north):
        return int(round((reach - north) / step * s + s / 2)), int(round((east + reach) / step * s + s / 2))

    def plot(east, north, color, thick=1):
        r, c = px(east, north)
        if 0 <= r < img.shape[0] - thick and 0 <= c < img.shape[1] - thick:
            img[r:r + thick, c:c + thick] = color

    if outlines:
        for kind, color, spec in rings:
            if kind == "ray":
                bearing, radius = spec
                b = math.radians(bearing)
                for k in range(int(radius * 2)):
                    d = k / 2.0
                    plot(d * math.sin(b), d * math.cos(b), color)
            elif kind == "wedge":
                bearing, radius, half = spec
                for edge in (-half, half):
                    b = math.radians(bearing + edge)
                    for k in range(int(radius * 2)):
                        d = k / 2.0
                        plot(d * math.sin(b), d * math.cos(b), color)
                for k in range(int(half * 2 * 6)):
                    b = math.radians(bearing - half + k / 6.0)
                    plot(radius * math.sin(b), radius * math.cos(b), color)
            elif kind == "disc":
                radius = spec
                for k in range(int(2 * math.pi * radius / 0.5)):
                    a = k * 0.5 / radius
                    plot(radius * math.sin(a), radius * math.cos(a), color)
    for d in range(-6, 7):                                          # observer cross
        plot(d, 0, (255, 255, 255), 2)
        plot(0, d, (255, 255, 255), 2)
    rows = legend if legend is not None else [[(MASK_COLORS[c], t) for c, t in MASK_LABELS[:3]],
                                              [(MASK_COLORS[c], t) for c, t in MASK_LABELS[3:]]]
    head, foot = 46, 10 + 15 * len(rows)
    out = np.zeros((head + img.shape[0] + foot, img.shape[1], 3), dtype=np.uint8)
    out[head:head + img.shape[0]] = img
    _draw_text(out, 6, 8, title)
    _draw_text(out, 26, 8, subtitle, color=(190, 200, 215))
    for r_i, row in enumerate(rows):
        col = 8
        top = head + img.shape[0] + 6 + r_i * 15
        for rgb, label in row:
            out[top:top + 10, col:col + 12] = rgb
            _draw_text(out, top, col + 16, label, scale=1)
            col += 16 + 6 * len(label) + 18
    _draw_text(out, head + 4, img.shape[1] - 20, "N", scale=2)
    return out


def clear_masks(out_dir, log=print):
    """Remove the pictures a previous query left, so they cannot be mistaken for this one."""
    gone = 0
    for path in [os.path.join(out_dir, MASK_FILE)] + sorted(
            p for p in glob.glob(os.path.join(out_dir, MASK_DIR, "*.png"))
            if not os.path.basename(p).startswith(("Forecast_", "Ground_"))):
        try:
            os.remove(path)
            gone += 1
        except OSError:
            pass
    if gone:
        log("Satellite mask pictures from the last query removed (no scan for this one)")


def write_sat_masks(out_dir, lat, lon, az, elev_m, layer_tops, scan_utc, age_h, mask_arr, mask_geom,
                    ht_arr, ht_geom, mask_var, ir, shift, np, step=SAT_STEP_KM, scene=None):
    """Save what the satellite check actually read, as PNG pictures (north up, 3 km per
    picture pixel, SIGHT_MAX_KM around the observer):
        masked_result.png                the sunset-view picture: cloud by top layer, with the
                                         regions and sun rays that are scored drawn on it
        Masks/CloudMask_ACM.png          the raw clear / cloudy mask
        Masks/CloudTopLayers_ACHA.png    cloud coloured by the height of its top
        Masks/IR_Band13.png              the infrared window band (cold = bright), cold cloud tinted
        Masks/Region_SunsetDirection.png, Region_Overhead.png, Region_OppositeSky.png
                                         only the pixels each scored region reads
        Masks/Region_SunsetDirection_WindShifted.png, Composite_WindShifted.png
                                         the same after carrying the scan to sunset (when winds are used)
    Returns the paths written."""
    os.makedirs(os.path.join(out_dir, MASK_DIR), exist_ok=True)
    reach = float(SIGHT_MAX_KM)
    k = int(reach // step)
    axis = np.arange(-k, k + 1) * step
    east, north = np.meshgrid(axis, axis[::-1])                    # row 0 = north edge
    grids = (mask_arr, mask_geom, ht_arr, ht_geom, mask_var)
    if scene is not None and scene["step"] == step and scene["observed"][0].shape == east.shape:
        codes = scene["observed"][0]                                   # already read once
    else:
        scene = None
        codes = _sat_class_grid(lat, lon, east, north, *grids, np)
    tops = layer_tops or LAYER_HEIGHT_M
    rmax = max(visibility_radius(tops[L], elev_m) for L in LAYERS)
    anti = (az + 180.0) % 360.0
    dist = np.hypot(east, north)
    bearing = np.degrees(np.arctan2(east, north)) % 360.0

    def in_wedge(b0, radius):
        return (dist > 0) & (dist <= radius) & (np.abs((bearing - b0 + 180.0) % 360.0 - 180.0) <= WEDGE_HALF)

    regions = {"SunsetDirection": in_wedge(az, rmax), "OppositeSky": in_wedge(anti, rmax),
               "Overhead": dist <= OVERHEAD_KM}
    shapes = [("wedge", (255, 140, 0), (az, rmax, WEDGE_HALF)), ("wedge", (0, 220, 220), (anti, rmax, WEDGE_HALF)),
              ("disc", (80, 230, 80), OVERHEAD_KM)]
    for delta in (-RAY_SPREAD_DEG, 0, RAY_SPREAD_DEG):
        shapes.append(("ray", (255, 60, 60), (az + delta, reach)))
    geometry = {"step": step, "reach": reach, "shapes": shapes, "origin": (lat, lon)}
    stamp = "SCAN %s Z  AGE AT SUNSET %d MIN" % (scan_utc.strftime("%Y-%m-%d %H:%M"), round(60 * age_h))
    where = "%.3f,%.3f  SUN AZ %d" % (lat, lon, round(az))
    written = []

    def save(rel, img):
        path = os.path.join(out_dir, rel)
        _write_png(path, img, np)
        written.append(path)

    save(MASK_FILE, _render(codes, "SUNSET VIEW MASK  " + where, stamp, geometry, np=np))
    save(os.path.join(MASK_DIR, "CloudMask_ACM.png"),
         _render(np.where(codes == 0, 0, np.where(codes == 1, 1, 5)),
                 "RAW CLOUD MASK (ACM)  CLEAR / CLOUDY", stamp, geometry, outlines=False, np=np))
    save(os.path.join(MASK_DIR, "CloudTopLayers_ACHA.png"),
         _render(codes, "CLOUD TOP HEIGHT BY LAYER (ACHA)", stamp, geometry, outlines=False, np=np))
    for name, region in regions.items():
        title = {"SunsetDirection": "SUNSET DIRECTION REGION", "OppositeSky": "OPPOSITE SKY REGION",
                 "Overhead": "OVERHEAD DISC REGION"}[name]
        save(os.path.join(MASK_DIR, "Region_%s.png" % name),
             _render(codes, title, stamp, geometry, region_mask=region, outlines=False, np=np))
    if ir is not None:
        ir_arr, ir_geom = ir
        x, y = latlon_to_scan_np(lat + north / KM_PER_DEG, lon + east / (KM_PER_DEG * math.cos(math.radians(lat))),
                                 ir_geom, np)
        i = np.rint((x - ir_geom["x0"]) / ir_geom["dx"]).astype(int)
        j = np.rint((y - ir_geom["y0"]) / ir_geom["dy"]).astype(int)
        ok = (i >= 0) & (i < ir_geom["nx"]) & (j >= 0) & (j < ir_geom["ny"])
        bt = np.ma.getdata(ir_arr)[np.clip(j, 0, ir_geom["ny"] - 1), np.clip(i, 0, ir_geom["nx"] - 1)].astype(float)
        bad = ~ok | np.isnan(bt) | np.ma.getmaskarray(ir_arr)[np.clip(j, 0, ir_geom["ny"] - 1),
                                                              np.clip(i, 0, ir_geom["nx"] - 1)]
        grey = np.clip((300.0 - np.where(bad, 300.0, bt)) / 100.0, 0.0, 1.0) * 255.0
        rgb = np.stack([grey, grey, grey], axis=-1)
        cold = ~bad & (bt < IR_CLOUD_K)
        rgb[cold] = rgb[cold] * 0.55 + np.array([0.0, 110.0, 150.0]) * 0.45         # cold cloud tinted
        rgb[bad] = 0
        save(os.path.join(MASK_DIR, "IR_Band13.png"),
             _render(codes, "IR BAND 13 (COLD CLOUD BRIGHT, TINTED)", stamp, geometry, outlines=False,
                     np=np, extra_rgb=rgb))
    if shift:
        moved = scene["shifted"][0] if scene is not None and scene["shifted"] is not None \
            else _shift_class_grid(lat, lon, east, north, shift, grids, np)
        sp = " ".join("%s %d" % (L.upper(), round(math.hypot(*shift[L]))) for L in LAYERS)
        save(os.path.join(MASK_DIR, "Composite_WindShifted.png"),
             _render(moved, "SHIFTED KM: " + sp, stamp, geometry, np=np))
        save(os.path.join(MASK_DIR, "Region_SunsetDirection_WindShifted.png"),
             _render(moved, "SUNSET DIRECTION REGION  WIND-SHIFTED", stamp, geometry,
                     region_mask=regions["SunsetDirection"], outlines=False, np=np))
    return written


GFS_DETAIL_VARS = ("Cloud_mixing_ratio_isobaric", "Ice_water_mixing_ratio_isobaric", "Visibility_surface")
K_MASS_LIQUID = 1.5 / (1000.0 * 10e-6)         # m2/kg, droplets of 10 micron effective radius
K_MASS_ICE = 1.5 / (917.0 * 30e-6)             # m2/kg, ice crystals of 30 micron effective radius
FORECAST_FILE = "forecast_result.png"
FORECAST_PREFIX = "Forecast_"


def _cell_positions(lats, lons, lat0, lon0):
    """Fractional (row, col) of each of the 31 x 31 cell centres in a lat / lon file."""
    rows = [[0.0] * SIZE for _ in range(SIZE)]
    cols = [[0.0] * SIZE for _ in range(SIZE)]
    for r in range(SIZE):
        for c in range(SIZE):
            la, lo = cell_latlon(lat0, lon0, r, c)
            rows[r][c] = _axis_position(lats, la)
            cols[r][c] = _axis_position(lons, lo % 360.0 if max(lons) > 180 else lo)
    return rows, cols


def parse_detail(path, lat0, lon0, sunset_utc):
    """Extra forecast fields for the pictures only (they never touch the score), at the file's
    time nearest sunset, on the 31 x 31 cells: ice and liquid cloud optical depth (column
    sum of mixing ratio x mass-extinction x layer mass) and surface visibility in metres."""
    try:
        from netCDF4 import Dataset
    except ImportError:
        raise RuntimeError("reading the detail file needs  pip install netCDF4")
    import numpy as np
    ds = Dataset(path)
    try:
        rows, cols = _cell_positions([float(v) for v in ds.variables["latitude"][:]],
                                     [float(v) for v in ds.variables["longitude"][:]], lat0, lon0)
        out = {}

        def nearest(var):
            tdim = var.dimensions[0]
            times = _gfs_times(ds, tdim)
            return tdim, min(range(len(times)), key=lambda k: abs((times[k] - sunset_utc).total_seconds()))

        for key, name, k_mass in (("liquid_tau", "Cloud_mixing_ratio_isobaric", K_MASS_LIQUID),
                                  ("ice_tau", "Ice_water_mixing_ratio_isobaric", K_MASS_ICE)):
            if name not in ds.variables:
                continue
            var = ds.variables[name]
            _, t = nearest(var)
            vdim = next(d for d in var.dimensions if d.startswith("isobaric"))
            p = np.array(ds.variables[vdim][:], dtype=float)
            order = np.argsort(p)
            dp = np.abs(np.gradient(p[order]))
            q = np.ma.filled(var[t].astype(float), 0.0)
            q = np.nan_to_num(q, nan=0.0)
            z_axis = var.dimensions[1:].index(vdim)
            q = np.moveaxis(q, z_axis, 0)[order]
            tau = k_mass * np.tensordot(dp / 9.80665, q, axes=(0, 0))
            out[key] = _gfs_layer(tau, rows, cols)
        if "Visibility_surface" in ds.variables:
            var = ds.variables["Visibility_surface"]
            _, t = nearest(var)
            out["visibility"] = _gfs_layer(np.nan_to_num(np.ma.filled(var[t].astype(float), 24000.0), nan=24000.0),
                                           rows, cols)
        return out
    finally:
        ds.close()


def fetch_detail(lat0, lon0, date_str, sunset_utc, cache_dir="cache", fetch_file=None, log=print, now=None):
    """Download (or reuse) the detail file and return parse_detail's grids."""
    fetch_file = fetch_file or _http_get_file
    path = os.path.join(cache_dir, "gfsdetail_%.4f_%.4f_%s.nc" % (lat0, lon0, date_str))
    now_ts = (now or datetime.datetime.now(datetime.timezone.utc)).timestamp()
    if not (os.path.exists(path) and (now_ts - os.path.getmtime(path)) < GFS_CACHE_HOURS * 3600):
        os.makedirs(cache_dir, exist_ok=True)
        tmp = path + ".dl"
        fetch_file(gfs_url(lat0, lon0, sunset_utc - datetime.timedelta(hours=3),
                           sunset_utc + datetime.timedelta(hours=3), names=list(GFS_DETAIL_VARS)), tmp)
        os.replace(tmp, path)
    return parse_detail(path, lat0, lon0, sunset_utc)


def _ramp(values, stops, np):
    """Colour each value by interpolating between (value, rgb) stops."""
    xs = [v for v, _ in stops]
    return np.stack([np.interp(values, xs, [c[i] for _, c in stops]) for i in range(3)], axis=-1)


def clear_forecast_masks(out_dir):
    for path in [os.path.join(out_dir, FORECAST_FILE)] + glob.glob(os.path.join(out_dir, MASK_DIR, FORECAST_PREFIX + "*.png")):
        try:
            os.remove(path)
        except OSError:
            pass


def write_forecast_masks(out_dir, lat, lon, az, elev_m, sky_h, elev_grid, hour_label, source, lead_h,
                         detail=None, layer_tops=None, step=SAT_STEP_KM):
    """Pictures of the forecast the score was built from, one hour (the sunset hour), on the same
    map as the satellite pictures.  Forecast cells are 30 km, so they show as blocks.
        forecast_result.png                       the three layers together (brighter = more cover)
        Masks/Forecast_Cover_Low / Mid / High     cover of each layer, 0 to 100 %
        Masks/Forecast_CloudTop_Highest, _CloudBase_Lowest   heights above sea level (cube files)
        Masks/Forecast_SunLine_Cells              the cells the sun rays cross, and which clouds sit at the sun's height
        Masks/Forecast_Precipitation, _Terrain    rain rate and ground height
        Masks/Forecast_IceThickness, _LiquidThickness, _Visibility   (when the detail file came)
    Returns the paths written."""
    try:
        import numpy as np
    except ImportError:
        return []
    clear_forecast_masks(out_dir)
    os.makedirs(os.path.join(out_dir, MASK_DIR), exist_ok=True)
    reach = float(SIGHT_MAX_KM)
    k = int(reach // step)
    axis = np.arange(-k, k + 1) * step
    east, north = np.meshgrid(axis, axis[::-1])
    rr = np.clip(N - np.rint(north / SPACING_KM).astype(int), 0, SIZE - 1)
    cc = np.clip(N + np.rint(east / SPACING_KM).astype(int), 0, SIZE - 1)
    onto = lambda grid: np.asarray(grid, dtype=float)[rr, cc]
    navy = np.array(MASK_COLORS[1], dtype=float)
    layer_rgb = {L: np.array(MASK_COLORS[c], dtype=float) for L, c in (("low", 2), ("mid", 3), ("high", 4))}
    cube = sky_h.get("cube")
    tops = layer_tops or LAYER_HEIGHT_M
    rmax = max(visibility_radius(tops[L], elev_m) for L in LAYERS)
    anti = (az + 180.0) % 360.0
    shapes = [("wedge", (255, 140, 0), (az, rmax, WEDGE_HALF)), ("wedge", (0, 220, 220), (anti, rmax, WEDGE_HALF)),
              ("disc", (80, 230, 80), OVERHEAD_KM)]
    for delta in (-RAY_SPREAD_DEG, 0, RAY_SPREAD_DEG):
        shapes.append(("ray", (255, 60, 60), (az + delta, reach)))
    geometry = {"step": step, "reach": reach, "shapes": shapes, "origin": (lat, lon)}
    stamp = "%s  CELLS 30 KM  LEAD %d H" % (source.upper(), round(lead_h))
    head = "%s  %.3f,%.3f" % (hour_label, lat, lon)
    written = []
    zero = np.zeros(onto(sky_h["low"]).shape, dtype=int)

    def save(rel, title, rgb, legend, subtitle=stamp, outlines=True):
        path = os.path.join(out_dir, rel)
        _write_png(path, _render(zero, title, subtitle, geometry, np=np, extra_rgb=rgb, legend=legend,
                                 outlines=outlines), np)
        written.append(path)

    def swatches(stops, fmt):
        return [(tuple(int(x) for x in _ramp(np.array([v]), stops, np)[0]), fmt % v) for v, _ in stops]

    covers = {L: np.clip(onto(sky_h[L]), 0.0, 1.0) for L in LAYERS}
    total = 1.0 - np.prod([1.0 - covers[L] for L in LAYERS], axis=0)
    wsum = sum(covers[L] for L in LAYERS)
    mix = sum(covers[L][..., None] * layer_rgb[L] for L in LAYERS) / np.maximum(wsum, 1e-9)[..., None]
    comp = navy * (1.0 - total[..., None]) + mix * total[..., None]
    comp = np.where((total > 0.02)[..., None], comp, navy)
    save(FORECAST_FILE, "FORECAST SKY  " + head, comp,
         [[(MASK_COLORS[2], "LOW"), (MASK_COLORS[3], "MID"), (MASK_COLORS[4], "HIGH"),
           (MASK_COLORS[1], "BRIGHTER = MORE COVER")]])
    pct = [(0.0, None), (0.25, None), (0.5, None), (0.75, None), (1.0, None)]
    for L in LAYERS:
        stops = [(0.0, tuple(navy)), (1.0, tuple(layer_rgb[L]))]
        rgb = _ramp(covers[L], stops, np)
        save(os.path.join(MASK_DIR, FORECAST_PREFIX + "Cover_%s.png" % L.capitalize()),
             "FORECAST %s CLOUD COVER  %s" % (L.upper(), hour_label), rgb,
             [[(tuple(int(x) for x in _ramp(np.array([v]), stops, np)[0]), "%d%%" % round(100 * v))
               for v, _ in pct]])
    if cube:
        def pick(edge, func):
            best = np.full((SIZE, SIZE), np.nan)
            for L in LAYERS:
                vals = np.array([[np.nan if v is None else v for v in row] for row in cube[L][edge]], dtype=float)
                vals = np.where(np.asarray(sky_h[L], dtype=float) >= 0.1, vals, np.nan)
                best = np.where(np.isnan(best), vals, np.where(np.isnan(vals), best, func(best, vals)))
            return best[rr, cc]
        ramp_h = [(0.0, (60, 100, 200)), (2.0, (60, 200, 200)), (5.0, (240, 220, 80)),
                  (8.0, (255, 140, 60)), (12.0, (255, 90, 200))]
        for rel, title, edge, func in (("CloudTop_Highest", "HIGHEST FORECAST CLOUD TOP (KM ASL)", "top", np.fmax),
                                       ("CloudBase_Lowest", "LOWEST FORECAST CLOUD BASE (KM ASL)", "bottom", np.fmin)):
            h = pick(edge, func) / 1000.0
            rgb = np.where(np.isnan(h)[..., None], navy, _ramp(np.nan_to_num(h), ramp_h, np))
            save(os.path.join(MASK_DIR, FORECAST_PREFIX + rel + ".png"), title, rgb,
                 [[(MASK_COLORS[1], "NO CLOUD")] + swatches([(v, c) for v, c in ramp_h], "%d KM")])
        # the sun line: cells the three rays cross, and whether their cloud sits at the sun's height
        typical = {L: layer_typical(sky_h, L) for L in LAYERS}
        visited = set()
        for delta in (-RAY_SPREAD_DEG, 0, RAY_SPREAD_DEG):
            b = math.radians(az + delta)
            for d in range(RAY_STEP_KM, SIGHT_MAX_KM + 1, RAY_STEP_KM):
                visited.add((min(SIZE - 1, max(0, round(OBS[0] - d * math.cos(b) / SPACING_KM))),
                             min(SIZE - 1, max(0, round(OBS[1] + d * math.sin(b) / SPACING_KM)))))
        cellrgb = np.zeros((SIZE, SIZE, 3)) + np.array((14, 20, 32), dtype=float)
        lo_sun, hi_sun = SUN_REF_DEG - SUN_HALF_DEG, SUN_REF_DEG + SUN_HALF_DEG
        for r, c in visited:
            dist = _bearing_dist(r - OBS[0], c - OBS[1])[1]
            colour = np.array((50, 70, 100), dtype=float)             # on a ray, no cloud
            best = 0.0
            for L in LAYERS:
                cover = sky_h[L][r][c]
                if cover < 0.05 or dist <= 0:
                    continue
                bottom, top = cell_interval(sky_h, L, r, c, typical[L], elev_m)
                e_b, e_t = apparent_elevation_deg(bottom, dist), apparent_elevation_deg(top, dist)
                if e_b <= hi_sun and e_t >= lo_sun:
                    hide = cover * SIGHT_OPACITY[L]
                    if hide > best:
                        best = hide
                        colour = navy + (layer_rgb[L] - navy) * (0.35 + 0.65 * min(1.0, hide))
                elif best == 0.0:
                    colour = np.array((95, 95, 108), dtype=float)       # cloud, but above or below the sun
            cellrgb[r, c] = colour
        save(os.path.join(MASK_DIR, FORECAST_PREFIX + "SunLine_Cells.png"), "CELLS THE SUN RAYS CROSS  " + hour_label,
             cellrgb[rr, cc],
             [[(MASK_COLORS[2], "LOW AT SUN"), (MASK_COLORS[3], "MID AT SUN"), (MASK_COLORS[4], "HIGH AT SUN")],
              [((95, 95, 108), "CLOUD NOT AT SUN HEIGHT"), ((50, 70, 100), "RAY, CLEAR"), ((14, 20, 32), "NOT CROSSED")]])
    ramp_p = [(0.0, tuple(navy)), (0.1, (70, 120, 200)), (0.5, (60, 200, 200)), (1.0, (240, 220, 80)),
              (3.0, (255, 140, 60)), (8.0, (255, 60, 60))]
    if "precip" in sky_h:
        save(os.path.join(MASK_DIR, FORECAST_PREFIX + "Precipitation.png"), "FORECAST RAIN RATE  " + hour_label,
             _ramp(onto(sky_h["precip"]), ramp_p, np), [swatches(ramp_p[1:], "%.1f MM/H")])
    ramp_t = [(0.0, (20, 40, 60)), (200.0, (60, 110, 90)), (600.0, (150, 150, 90)), (1200.0, (200, 170, 140)),
              (1800.0, (245, 245, 245))]
    save(os.path.join(MASK_DIR, FORECAST_PREFIX + "Terrain.png"), "MODEL TERRAIN HEIGHT", _ramp(onto(elev_grid), ramp_t, np),
         [swatches(ramp_t, "%d M")])
    if detail:
        ramp_i = [(0.0, tuple(navy)), (0.05, (80, 100, 200)), (0.3, (80, 200, 220)), (1.0, (240, 230, 100)),
                  (3.0, (255, 150, 60)), (10.0, (255, 60, 150))]
        ramp_l = [(0.0, tuple(navy)), (1.0, (70, 110, 200)), (5.0, (60, 200, 200)), (15.0, (240, 220, 80)),
                  (40.0, (255, 140, 60)), (100.0, (255, 255, 255))]
        if "ice_tau" in detail:
            save(os.path.join(MASK_DIR, FORECAST_PREFIX + "IceThickness.png"), "ICE CLOUD OPTICAL DEPTH (COLUMN)",
                 _ramp(onto(detail["ice_tau"]), ramp_i, np), [swatches(ramp_i[1:], "%.2f")])
        if "liquid_tau" in detail:
            save(os.path.join(MASK_DIR, FORECAST_PREFIX + "LiquidThickness.png"), "WATER CLOUD OPTICAL DEPTH",
                 _ramp(onto(detail["liquid_tau"]), ramp_l, np), [swatches(ramp_l[1:], "%d")])
        if "visibility" in detail:
            ramp_v = [(0.0, (255, 60, 60)), (1000.0, (255, 140, 60)), (5000.0, (240, 220, 80)),
                      (10000.0, (80, 200, 200)), (24000.0, tuple(navy))]
            save(os.path.join(MASK_DIR, FORECAST_PREFIX + "Visibility.png"), "FORECAST SURFACE VISIBILITY",
                 _ramp(onto(detail["visibility"]), ramp_v, np), [swatches(ramp_v, "%d M")])
    return written


# ------------------------------------------------ v1.1: the view from the ground
GROUND_FILE = "ground_view.png"
GROUND_SUNSET_FILE = "ground_sunset_view.png"
GROUND_PREFIX = "Ground_"
GROUND_PPD = 14                    # picture pixels per degree of view
GROUND_HFOV = 100.0                # degrees of sky across the picture, centred on the view direction
GROUND_EL_MIN = -5.0               # lowest and highest elevation angle shown
GROUND_EL_MAX = 32.0
GROUND_SUN_DEG = 1.0               # where the sun is drawn (the score itself uses SUN_REF_DEG)
GROUND_SUN_DRAW_DEG = 1.4          # drawn sun radius; the real one (SUN_HALF_DEG) would be 3 pixels
GROUND_MIN_COVER = 0.05            # boxes with less cover than this are not drawn
GROUND_NEAR_KM = 0.5               # nearer than this a point is treated as this far (keeps the angles finite)
GROUND_STEP_KM = SAT_STEP_KM       # THE horizontal grid: every box edge and every line sits on multiples of this
GROUND_REACH_KM = float(SIGHT_MAX_KM)
GROUND_CELLS = int(round(2 * GROUND_REACH_KM / GROUND_STEP_KM))   # lattice squares per side (the observer is at a corner)
GROUND_BOX_COLS = 7                # east km, north km, half-size km, bottom m, top m (above the eye), layer, cover
GROUND_ALPHA_LEVELS = 6            # cover is drawn in this many opacity steps
GROUND_LIT_LEVELS = 5              # ... and the sunset view in this many steps from grey to full hue
GROUND_LINE_MIN_PX = 1.2           # lattice-line pieces shorter than this on the picture carry nothing
GROUND_LINE_SPACING_PX = 3.5       # ... and so do lines whose neighbour is closer than this
GROUND_LIT_FLOOR = 0.12            # decoration below this is not coloured: the cloud stays grey
# The 3 km grid and the outline round a cloud say "there is a cloud here", so they are only drawn where the cloud has
# substance.  In opacity steps (cover is drawn in GROUND_ALPHA_LEVELS of them, each 1/6 of the cover): below the first
# number a square has no border, at the second and above it has the full border, between them a half border.  Thin cover
# is common in the forecast (a few per cent of cirrus over a whole region), so high cloud has to be thicker to earn one.
GROUND_BORDER_STEPS = {"low": (1, 3), "mid": (1, 3), "high": (2, 4)}


def border_weight(cover, L, np):
    """How much border (0..1) a square of this cloud layer gets for its cover: none for wisps, full for cloud with substance."""
    if L is None:
        return (np.asarray(cover) >= GROUND_MIN_COVER).astype(np.float32)
    none_upto, full_from = GROUND_BORDER_STEPS[L]
    q = np.clip(np.ceil(np.asarray(cover, dtype=float) * GROUND_ALPHA_LEVELS), 1, GROUND_ALPHA_LEVELS)
    return np.clip((q - none_upto) / float(full_from - none_upto), 0.0, 1.0).astype(np.float32)

_GREY = {"low": (92, 96, 106), "mid": (128, 132, 142), "high": (168, 172, 182)}
GROUND_STYLES = {
    # the analysis picture: a dusk sky, every layer in its own colour
    "data": {
        "sky_zenith": (12, 22, 50), "sky_horizon": (150, 98, 84), "sky_pow": 0.55,
        "glow_rgb": (255, 150, 60), "glow_k": 0.8,
        "sun_dull": (120, 45, 40), "sun_bright": (255, 238, 160), "sun_ring": (255, 240, 200),
        "alpha_max": {"low": 0.70, "mid": 0.55, "high": 0.35}, "alpha_floor": 0.25,
        "cloud": {L: (MASK_COLORS[2 + i],) * 2 for i, L in enumerate(LAYERS)},
        "line_alpha": 0.40,
        "ground_near": (36, 54, 46), "ground_haze": None, "ground_line": (130, 160, 140),
        "ground_glow": 0.22,
    },
    # the sunset picture: blue sky, cloud grey until the score expects it to be lit, then a sunset hue
    "sunset": {
        "sky_zenith": (30, 72, 160), "sky_horizon": (176, 210, 240), "sky_pow": 0.6,
        "glow_rgb": (255, 175, 115), "glow_k": 0.30,
        "sun_dull": (105, 28, 20), "sun_bright": (240, 66, 16), "sun_ring": (255, 190, 120),
        "alpha_max": {"low": 0.78, "mid": 0.68, "high": 0.55}, "alpha_floor": 0.30,
        "cloud": {"low": (_GREY["low"], (255, 140, 40)),          # golden orange
                  "mid": (_GREY["mid"], (255, 86, 52)),           # red orange
                  "high": (_GREY["high"], (240, 96, 170))},       # rose pink
        "line_alpha": 0.30,
        "ground_near": (58, 76, 46), "ground_haze": None, "ground_line": (170, 192, 128),
        "ground_glow": 0.30,
    },
}


def _lit_shade(grey, hue, s, np):
    """Cloud colour at lit share s (0 grey .. 1 full hue).  Straight grey-to-hue mixes go muddy brown, and real
    cloud only just catching the light is pale, not dark: so the ramp goes grey -> a pale tint of the hue
    (lighter than both ends) -> the full hue."""
    grey, hue = np.asarray(grey, dtype=float), np.asarray(hue, dtype=float)
    pale = 0.45 * hue + 0.55 * np.array([252.0, 228.0, 210.0])
    return grey + (pale - grey) * (s / 0.5) if s < 0.5 else pale + (hue - pale) * ((s - 0.5) / 0.5)


def _wrap_deg(a):
    """Angles (numbers or arrays) folded into -180 .. 180."""
    return (a + 180.0) % 360.0 - 180.0


def _elev_deg(z_m, d_km, np):
    """Apparent elevation angle of a point z_m above the eye and d_km away (arrays): the angle its
    height subtends minus the earth's curvature drop, slightly reduced by refraction."""
    d = np.maximum(d_km, GROUND_NEAR_KM)
    return np.degrees(np.arctan2(z_m, d * 1000.0)) - np.degrees((1.0 - REFRACTION_K) * d / (2.0 * EARTH_RADIUS_KM))


def _snap(v, step=GROUND_STEP_KM):
    """Round a horizontal position to the nearest line of the shared grid."""
    return round(v / step) * step


def forecast_boxes(sky_h, elev_m, np):
    """The forecast as boxes: one per 30 km cell and layer that has cloud, spanning the model's
    cloud base to top (the layer's usual heights when the model gives none), cover as the opacity.
    Positions are rounded to the shared 3 km grid (the cell centres already lie on it, and a 30 km
    cell is ten 3 km squares across)."""
    cube = "cube" in sky_h
    typical = {L: layer_typical(sky_h, L) if cube else DEFAULT_LAYER_ASL_M[L] for L in LAYERS}
    rows = []
    for li, L in enumerate(LAYERS):
        for r in range(SIZE):
            for c in range(SIZE):
                cover = sky_h[L][r][c]
                if cover is None or cover < GROUND_MIN_COVER:
                    continue
                if cube:
                    b, t = cell_interval(sky_h, L, r, c, typical[L], elev_m)
                else:
                    b, t = typical[L][0] - elev_m, typical[L][1] - elev_m
                rows.append((_snap((c - N) * SPACING_KM), _snap((N - r) * SPACING_KM), SPACING_KM / 2.0,
                             b, t, li, min(1.0, cover)))
    return np.array(rows, dtype=float).reshape(-1, GROUND_BOX_COLS)


def new_lattice(np, n=GROUND_CELLS):
    """An empty lattice: per layer, the cover, base and top (m above the eye) of each 3 km square.
    Arrays are indexed [north, east], increasing away from the south-west corner; the observer stands
    on the corner shared by squares n/2 - 1 and n/2."""
    return {"n": n, "step": GROUND_STEP_KM,
            "cover": {L: np.zeros((n, n)) for L in LAYERS},
            "bottom": {L: np.full((n, n), np.nan) for L in LAYERS},
            "top": {L: np.full((n, n), np.nan) for L in LAYERS}}


def boxes_to_lattice(boxes, np):
    """Snap boxes onto the shared grid: each box fills the 3 km squares whose centres lie inside its
    footprint (a 30 km forecast cell becomes 10 x 10 squares at one height, like a plane of counting
    cubes).  Where boxes of one layer overlap, the one with more cover wins."""
    lat = new_lattice(np)
    n, step = lat["n"], lat["step"]
    arr = np.asarray(boxes, dtype=float).reshape(-1, np.asarray(boxes).shape[-1] if len(boxes) else GROUND_BOX_COLS)
    if not len(arr):
        return lat
    e, nn, half, b, t, layer, cover = (arr[:, k] for k in range(7))
    ce = lambda x: np.ceil(x / step + n / 2.0 - 0.5 - 1e-9).astype(int)
    a_e0, a_e1, a_n0, a_n1 = ce(e - half), ce(e + half), ce(nn - half), ce(nn + half)
    a_e0, a_e1, a_n0, a_n1 = np.clip(a_e0, 0, n), np.clip(a_e1, 0, n), np.clip(a_n0, 0, n), np.clip(a_n1, 0, n)
    live = (a_e1 > a_e0) & (a_n1 > a_n0)
    unit = live & (a_e1 - a_e0 == 1) & (a_n1 - a_n0 == 1)
    for li, L in enumerate(LAYERS):                                  # one-square boxes in one go (strongest last)
        sel = np.nonzero(unit & (layer.astype(int) == li))[0]
        sel = sel[np.argsort(cover[sel], kind="stable")]
        lat["cover"][L][a_n0[sel], a_e0[sel]] = cover[sel]
        lat["bottom"][L][a_n0[sel], a_e0[sel]] = b[sel]
        lat["top"][L][a_n0[sel], a_e0[sel]] = t[sel]
    for i in np.nonzero(live & ~unit)[0]:                            # bigger boxes
        L = LAYERS[int(layer[i])]
        sl = (slice(a_n0[i], a_n1[i]), slice(a_e0[i], a_e1[i]))
        win = cover[i] > lat["cover"][L][sl]
        lat["cover"][L][sl] = np.where(win, cover[i], lat["cover"][L][sl])
        lat["bottom"][L][sl] = np.where(win, b[i], lat["bottom"][L][sl])
        lat["top"][L][sl] = np.where(win, t[i], lat["top"][L][sl])
    return lat


def scene_cells(scene, which, np):
    """The scan (scene["observed"] or ["shifted"]) as lattice arrays [north, east]: per layer the share of
    the square whose cloud top is in that layer (0 or 1: a square is one scan pixel) and that top (m above
    sea level), plus whether the scan covered the square and whether it saw cloud of unknown height."""
    codes, heights = scene[which]
    codes, heights = codes[::-1], heights[::-1]                      # the scan is stored north edge first
    out = {"share": {}, "top": {}}
    for L, code in (("low", 2), ("mid", 3), ("high", 4)):
        hit = codes == code
        out["share"][L] = hit.astype(float)
        out["top"][L] = np.where(hit, heights, np.nan)
    out["known"] = (codes != 0).astype(float)
    out["nohgt"] = (codes == 5).astype(float)
    return out


def forecast_lattice(sky_h, elev_m, np):
    """The forecast on the shared lattice: per layer (cover, base, top), each [north, east], a 30 km cell
    repeated over its ten by ten squares; base and top in metres above the eye."""
    n, step = GROUND_CELLS, GROUND_STEP_KM
    centre = (np.arange(n) - n / 2.0 + 0.5) * step
    east, north = np.meshgrid(centre, centre)                          # [north, east]
    cube = "cube" in sky_h
    typical = {L: layer_typical(sky_h, L) if cube else DEFAULT_LAYER_ASL_M[L] for L in LAYERS}
    rr = np.clip(N - np.rint(north / SPACING_KM).astype(int), 0, SIZE - 1)
    cc = np.clip(N + np.rint(east / SPACING_KM).astype(int), 0, SIZE - 1)
    out = {}
    for L in LAYERS:
        f = np.clip(np.array([[sky_h[L][r][c] if sky_h[L][r][c] is not None else 0.0
                               for c in range(SIZE)] for r in range(SIZE)], dtype=float), 0.0, 1.0)[rr, cc]
        if cube:
            iv = [[cell_interval(sky_h, L, r, c, typical[L], elev_m) for c in range(SIZE)] for r in range(SIZE)]
            fb = np.array([[v[0] for v in row] for row in iv])[rr, cc]
            ft = np.array([[v[1] for v in row] for row in iv])[rr, cc]
        else:
            fb = np.full(f.shape, typical[L][0] - elev_m)
            ft = np.full(f.shape, typical[L][1] - elev_m)
        out[L] = (f, fb, ft)
    return out


def unify_lattice(fl, cells, cells_shifted, weights, elev_m, np, forecast=True):
    """Forecast and satellite as one lattice of 3 km squares.

    A satellite sees only the top of the cloud over each pixel, so per square and layer:
      s  = 1 if the cloud top there is in the layer (cloud that is certainly there)
      u  = 1 if the top is higher still (cloud of this layer may hide beneath: only the forecast knows)
      f  = the forecast's cover for the layer (its 30 km cell, repeated over the ten squares)
    satellite estimate  e = s + min(max(f - s, 0), u)     (what the forecast adds is capped by what can hide)
    cover = w * e + (1 - w) * f,  w = scan potency * 1 where the scan covers the square (sat_weights).
    Wherever the satellite sets the layer, its top gives the box top and the slab model its depth
    (SAT_THICKNESS_M, as in the gate); otherwise the forecast's base and top are used.
    forecast=False drops f: the satellite alone (hidden layers are then missing, as in the sky it saw).
    The scan and its wind-shifted version are mixed by their weights.  `fl` is forecast_lattice().

    Returns {"n", "step", "cover", "bottom", "top", "sat"} with per-layer [north, east] arrays; bottom / top
    are nan where there is no cloud, and "sat" is the share of the cover that the satellite set."""
    w0, w1 = weights.get("unshifted", 1.0), weights.get("shifted", 0.0)
    mix = 1.0 if (cells_shifted is None or w0 + w1 <= 0) else w0 / (w0 + w1)
    potency = weights.get("total", 1.0) if forecast else 1.0
    both = [(cells, mix)] + ([(cells_shifted, 1.0 - mix)] if cells_shifted is not None and mix < 1.0 else [])
    share, top = {}, {}
    for L in LAYERS:
        share[L] = sum(w * b["share"][L] for b, w in both)
        num = sum(w * b["share"][L] * np.nan_to_num(b["top"][L]) for b, w in both)
        top[L] = np.where(share[L] > 1e-9, num / np.maximum(share[L], 1e-9), np.nan)
    known = sum(w * b["known"] for b, w in both)
    unknown_top = sum(w * b["nohgt"] for b, w in both)
    above = {"low": share["mid"] + share["high"] + unknown_top, "mid": share["high"] + unknown_top,
             "high": unknown_top}
    n = share["low"].shape[0]
    out = {"n": n, "step": GROUND_STEP_KM, "cover": {}, "bottom": {}, "top": {}, "sat": {}}
    for L in LAYERS:
        if forecast:
            f, fb, ft = fl[L]
        else:
            f = np.zeros(share[L].shape)
            fb = ft = np.zeros(share[L].shape)
        sat_est = share[L] + np.minimum(np.maximum(f - share[L], 0.0), above[L])
        w = potency * known
        cover = w * sat_est + (1.0 - w) * f
        from_sat = (share[L] > 0) & (share[L] >= 0.5 * np.maximum(sat_est, 1e-9)) & ~np.isnan(top[L])
        box_top = np.where(from_sat, top[L] - elev_m, ft)
        box_bot = np.where(from_sat, np.maximum(top[L] - SAT_THICKNESS_M[L], 0.0) - elev_m, fb)
        present = cover >= GROUND_MIN_COVER
        out["cover"][L] = np.where(present, np.minimum(1.0, cover), 0.0)
        out["bottom"][L] = np.where(present, box_bot, np.nan)
        out["top"][L] = np.where(present, box_top, np.nan)
        out["sat"][L] = np.where(present, np.clip(w * sat_est / np.maximum(cover, 1e-9), 0.0, 1.0), 0.0)
    return out


def lattice_boxes(lat, np):
    """A lattice (unify_lattice) as box rows: east, north, half, bottom, top, layer, cover."""
    n, step = lat["n"], lat["step"]
    centre = (np.arange(n) - n / 2.0 + 0.5) * step
    east, north = np.meshgrid(centre, centre)
    rows = []
    for li, L in enumerate(LAYERS):
        an, ae = np.nonzero(lat["cover"][L] >= GROUND_MIN_COVER)
        if len(an):
            rows.append(np.column_stack([east[an, ae], north[an, ae], np.full(len(an), step / 2.0),
                                         lat["bottom"][L][an, ae], lat["top"][L][an, ae], np.full(len(an), li),
                                         lat["cover"][L][an, ae]]))
    return np.concatenate(rows).reshape(-1, GROUND_BOX_COLS) if rows else np.zeros((0, GROUND_BOX_COLS))


def unified_boxes(sky_h, elev_m, cells, cells_shifted, weights, np, forecast=True):
    """Forecast and satellite as one set of boxes on the shared 3 km grid (see unify_lattice)."""
    fl = forecast_lattice(sky_h, elev_m, np) if forecast else None
    return lattice_boxes(unify_lattice(fl, cells, cells_shifted, weights, elev_m, np, forecast), np)


def sunset_lit(lat, az, elev_m, detail, gate, np, sun_deg=SUN_REF_DEG):
    """How much of each lattice square's cloud the score expects to be lit by the sunset, 0..1, per layer.

    It is the score's own decoration: a layer in a region (the wedge toward the sun, the disc overhead, the
    wedge away from the sun) has a decoration value (`detail[region][layer]`, sweet spot of the cover times
    the texture factor); every cloud square of that layer in that region gets it.  In the sunset wedge only
    the share of the cloud above the sun counts (cloud at the sun's height is a silhouette).  Cloud outside
    the three regions is not part of the score: 0.  All of it is scaled by the gate, since a hidden sun
    lights nothing."""
    n, step = lat["n"], lat["step"]
    centre = (np.arange(n) - n / 2.0 + 0.5) * step
    east, north = np.meshgrid(centre, centre)
    dist = np.hypot(east, north)
    bearing = np.degrees(np.arctan2(east, north)) % 360.0
    off_sun = np.abs(_wrap_deg(bearing - az))
    off_anti = np.abs(_wrap_deg(bearing - (az + 180.0)))
    dip = horizon_dip_deg(elev_m)
    hi = sun_deg + SUN_HALF_DEG
    g = 1.0 if gate is None else min(1.0, max(0.0, gate))
    out = {}
    for L in LAYERS:
        top = np.nan_to_num(lat["top"][L], nan=-1e4)
        bot = np.nan_to_num(lat["bottom"][L], nan=-1e4)
        e_t, e_b = _elev_deg(top, dist, np), _elev_deg(bot, dist, np)
        visible = e_t > -dip
        with np.errstate(divide="ignore", invalid="ignore"):
            above_sun = np.where(e_t <= hi, 0.0, np.where(e_b < hi, (e_t - hi) / (e_t - e_b), 1.0))
        dec = {r: (detail[r][L][2] if detail and r in detail else 0.0) for r in ("fwd", "over", "anti")}
        val = np.zeros((n, n))
        val = np.maximum(val, ((off_sun <= WEDGE_HALF) & visible & (dist > 0)) * above_sun * dec["fwd"])
        val = np.maximum(val, (dist <= OVERHEAD_KM) * dec["over"])
        val = np.maximum(val, ((off_anti <= WEDGE_HALF) & visible) * dec["anti"])
        out[L] = np.clip(val * g, 0.0, 1.0) * (lat["cover"][L] >= GROUND_MIN_COVER)
    return out


# ---- drawing
def _march_distances(reach=GROUND_REACH_KM):
    """Distances at which each line of sight is sampled: every 200 m near the observer, then 0.6 % of the
    distance (a few hundred metres to a couple of km), well inside a 3 km square."""
    ds, d = [], 0.2
    while d < reach:
        ds.append(d)
        d += max(0.2, 0.006 * d)
    return ds


def _span_mask(y0, y1, col, h, w, np):
    """Pixels covered by vertical spans [y0, y1) in column `col` (all arrays of ints)."""
    size = (h + 1) * w
    diff = np.bincount(y0 * w + col, minlength=size) - np.bincount(y1 * w + col, minlength=size)
    return np.cumsum(diff.reshape(h + 1, w), axis=0)[:h] > 0


def _march_layer(cover, bottom, top, lit, L, yaw, ppd, w, h, style, np, keys=None, nkeys=None):
    """One layer as seen from the eye: for every picture column, step out along the line of sight; the
    lattice square found at each distance is cloud from its base to its top, which are elevation angles
    there (so the picture is the geometry itself: nothing is projected from a hull).  The layer's opacity
    at a pixel is the largest of the squares crossing it, so a long run of squares does not pile up into
    solid cloud.  Returns (opacity (h, w), colour step (h, w), border weight (h, w): how much outline the cloud
    there earns, see border_weight).  The colour step is the square's key in
    `keys` (an int array on the lattice, 0 .. nkeys - 1) when given, else its share of lit hue from `lit`."""
    n = cover.shape[0]
    ds = np.array(_march_distances())
    theta = (np.arange(w) + 0.5 - w / 2.0) / ppd
    b = np.radians(yaw + theta)
    east = ds[:, None] * np.sin(b)[None, :]
    north = ds[:, None] * np.cos(b)[None, :]
    ie = np.floor(east / GROUND_STEP_KM).astype(int) + n // 2
    inn = np.floor(north / GROUND_STEP_KM).astype(int) + n // 2
    ok = (ie >= 0) & (ie < n) & (inn >= 0) & (inn < n)
    flat = np.clip(inn, 0, n - 1) * n + np.clip(ie, 0, n - 1)
    cov = cover.ravel()[flat]
    tp, bt = top.ravel()[flat], bottom.ravel()[flat]
    sel = ok & (cov >= GROUND_MIN_COVER) & np.isfinite(tp) & np.isfinite(bt)
    ss, cc = np.nonzero(sel)
    opac = np.zeros((h, w), dtype=np.float32)
    colour = np.zeros((h, w), dtype=np.int8)
    bw = np.zeros((h, w), dtype=np.float32)
    if not len(ss):
        return opac, colour, bw
    d = ds[ss]
    fl = flat[ss, cc]
    y0 = np.ceil((GROUND_EL_MAX - _elev_deg(tp[ss, cc], d, np)) * ppd - 0.5).astype(int)
    y1 = np.ceil((GROUND_EL_MAX - _elev_deg(bt[ss, cc], d, np)) * ppd - 0.5).astype(int)
    y0, y1 = np.clip(y0, 0, h), np.clip(y1, 0, h)
    keep = y1 > y0
    ss, cc, fl, y0, y1 = ss[keep], cc[keep], fl[keep], y0[keep], y1[keep]
    q = np.clip(np.ceil(cov[ss, cc] * GROUND_ALPHA_LEVELS), 1, GROUND_ALPHA_LEVELS).astype(int)
    if keys is not None:
        steps = keys.ravel()[fl].astype(int)
    else:
        steps = (np.rint(np.clip((lit.ravel()[fl] - GROUND_LIT_FLOOR) / (1.0 - GROUND_LIT_FLOOR), 0.0, 1.0)
                         * (GROUND_LIT_LEVELS - 1)).astype(int) if lit is not None else np.zeros(len(ss), dtype=int))
    amax, floor = style["alpha_max"][L], style["alpha_floor"]
    for level in range(1, GROUND_ALPHA_LEVELS + 1):                # ascending opacity: the strongest square wins
        alpha = amax * (floor + (1.0 - floor) * level / GROUND_ALPHA_LEVELS)
        weight = float(border_weight((level - 0.5) / GROUND_ALPHA_LEVELS, L, np))
        for s_ in range(GROUND_LIT_LEVELS if keys is None else nkeys):
            m = (q == level) & (steps == s_)
            if m.any():
                covered = _span_mask(y0[m], y1[m], cc[m], h, w, np)
                opac[covered] = alpha
                colour[covered] = s_
                bw[covered] = weight
    return opac, colour, bw


def _project(east, north, z, yaw, ppd, w, np):
    """Picture (x, y) of points (arrays) at east / north km and z metres above the eye."""
    dist = np.hypot(east, north)
    rel = _wrap_deg(np.degrees(np.arctan2(east, north)) - yaw)
    return w / 2.0 + rel * ppd, (GROUND_EL_MAX - _elev_deg(z, dist, np)) * ppd, rel, dist


def _draw_segments(buf, x0, y0, x1, y1, value, np, budget=2500000):
    """Draw straight pieces (arrays of picture coordinates) into `buf` as one-pixel lines of `value`."""
    h, w = buf.shape
    lens = np.maximum(np.abs(x1 - x0), np.abs(y1 - y0))
    count = np.ceil(lens).astype(int) + 1
    start = 0
    while start < len(count):
        stop = start
        total = 0
        while stop < len(count) and total + count[stop] <= budget:
            total += count[stop]
            stop += 1
        if stop == start:
            stop = start + 1
        c = count[start:stop]
        idx = np.repeat(np.arange(stop - start), c)
        first = np.cumsum(c) - c
        t = (np.arange(int(c.sum())) - first[idx]) / np.maximum(c[idx] - 1, 1)
        xs = x0[start:stop][idx] + t * (x1[start:stop] - x0[start:stop])[idx]
        ys = y0[start:stop][idx] + t * (y1[start:stop] - y0[start:stop])[idx]
        xi, yi = np.floor(xs).astype(int), np.floor(ys).astype(int)
        ok = (xi >= 0) & (xi < w) & (yi >= 0) & (yi < h)
        buf[yi[ok], xi[ok]] = value[start:stop][idx][ok] if hasattr(value, "shape") and value.shape else value
        start = stop


def _cloud_lines(cover, bottom, top, yaw, ppd, w, h, hfov, np, pieces=3, layer=None):
    """The shared 3 km grid drawn on the top and the underside of every cloud square (crisscrossing lines,
    like a plane of counting cubes), where a square's edge is drawn once unless it borders open sky.  With
    `layer` given, only cloud with substance gets lines (border_weight): a square of thin cover has none, and
    one a little thicker has fainter ones, so a sky of wisps is not a sky of grid.  Returns an (h, w) array:
    1 on a full line, less on a fainter one."""
    n, step = cover.shape[0], GROUND_STEP_KM
    weight = border_weight(cover, layer, np)
    present = (weight > 0) & np.isfinite(top) & np.isfinite(bottom) & (cover >= GROUND_MIN_COVER)
    an, ae = np.nonzero(present)
    out = np.zeros((h, w), dtype=np.float32)
    if not len(an):
        return out
    cx, cy = (ae - n / 2.0 + 0.5) * step, (an - n / 2.0 + 0.5) * step
    dist = np.hypot(cx, cy)
    rel = _wrap_deg(np.degrees(np.arctan2(cx, cy)) - yaw)
    margin = np.degrees(np.arctan2(step * 1.5, np.maximum(dist - step * 1.5, 0.3)))
    keep = (np.abs(rel) - margin <= hfov / 2.0 + 2.0)
    an, ae = an[keep], ae[keep]
    if not len(an):
        return out
    wsq = weight[an, ae]
    pad = np.pad(present, 1)
    e0, n0 = (ae - n / 2.0) * step, (an - n / 2.0) * step
    segs = [(e0, n0, e0, n0 + step, np.ones(len(an), bool)),                          # west edge
            (e0, n0, e0 + step, n0, np.ones(len(an), bool)),                          # south edge
            (e0 + step, n0, e0 + step, n0 + step, ~pad[an + 1, ae + 2]),              # east edge, if open sky beyond
            (e0, n0 + step, e0 + step, n0 + step, ~pad[an + 2, ae + 1])]              # north edge, if open sky beyond
    t = np.linspace(0.0, 1.0, pieces + 1)
    for face in (top, bottom):
        z = face[an, ae]
        for ea, na, eb, nb, use in segs:
            ea_, na_, eb_, nb_, z_, wt_ = ea[use], na[use], eb[use], nb[use], z[use], wsq[use]
            if not len(ea_):
                continue
            pe = ea_[:, None] + (eb_ - ea_)[:, None] * t[None, :]
            pn = na_[:, None] + (nb_ - na_)[:, None] * t[None, :]
            pz = np.repeat(z_[:, None], pieces + 1, axis=1)
            x, y, rel_p, d_p = _project(pe, pn, pz, yaw, ppd, w, np)
            # a line is only worth drawing where its neighbour (one grid step to the side) is a few pixels away:
            # toward the horizon the lines of a layer pile up into scan lines that say nothing
            me, mn = 0.5 * (pe[:, :-1] + pe[:, 1:]), 0.5 * (pn[:, :-1] + pn[:, 1:])
            de, dn = pe[:, 1:] - pe[:, :-1], pn[:, 1:] - pn[:, :-1]
            norm = np.maximum(np.hypot(de, dn), 1e-9)
            mx, my, _, _ = _project(me, mn, pz[:, :-1], yaw, ppd, w, np)
            sx, sy, _, _ = _project(me - dn / norm * step, mn + de / norm * step, pz[:, :-1], yaw, ppd, w, np)
            spaced = (np.hypot(sx - mx, sy - my) >= GROUND_LINE_SPACING_PX).ravel()
            x0, y0, x1, y1 = x[:, :-1].ravel(), y[:, :-1].ravel(), x[:, 1:].ravel(), y[:, 1:].ravel()
            near = np.minimum(d_p[:, :-1], d_p[:, 1:]).ravel()
            rel_a, rel_b = rel_p[:, :-1].ravel(), rel_p[:, 1:].ravel()
            length = np.hypot(x1 - x0, y1 - y0)
            good = (spaced & (near > 0.3) & (np.abs(rel_a) < hfov / 2.0 + 8.0) & (np.abs(rel_b) < hfov / 2.0 + 8.0)
                    & (np.abs(rel_a - rel_b) < 60.0) & (length >= GROUND_LINE_MIN_PX) & (length < 1500.0)
                    & (np.maximum(y0, y1) > -20) & (np.minimum(y0, y1) < h + 20))
            if good.any():
                val = np.repeat(wt_, pieces)[good]
                order = np.argsort(val, kind="stable")                          # the strongest line is drawn last, so it wins
                _draw_segments(out, x0[good][order], y0[good][order], x1[good][order], y1[good][order], val[order], np)
    return out


def _sky_canvas(w, h, ppd, yaw, sun_az, sun_deg, gate, dip, style, np):
    """Sky gradient with a warm glow around the sun, as a float canvas."""
    el = GROUND_EL_MAX - (np.arange(h) + 0.5) / ppd                       # elevation of each row
    t = np.clip((el + dip) / (GROUND_EL_MAX + dip), 0.0, 1.0) ** style["sky_pow"]
    horizon, zenith = np.array(style["sky_horizon"], dtype=float), np.array(style["sky_zenith"], dtype=float)
    sky = horizon[None, :] * (1.0 - t[:, None]) + zenith[None, :] * t[:, None]
    canvas = np.repeat(sky[:, None, :], w, axis=1)
    rel_sun = _wrap_deg(sun_az - yaw)
    theta = (np.arange(w) + 0.5 - w / 2.0) / ppd
    dist = np.hypot(theta[None, :] - rel_sun, el[:, None] - sun_deg)
    strength = 0.3 + 0.7 * (0.0 if gate is None else gate)
    glow = strength * (0.55 * np.exp(-(dist / 9.0) ** 2) + 0.28 * np.exp(-(dist / 30.0) ** 2))
    canvas += glow[..., None] * np.array(style["glow_rgb"], dtype=float)[None, None, :] * style["glow_k"]
    return np.clip(canvas, 0.0, 255.0)


def _draw_sun(canvas, ppd, yaw, sun_az, sun_deg, gate, style, np, radius_deg=None):
    """The sun disc, over the clouds (it is the program's own reading, not what the boxes would hide):
    its shade and its opacity both follow the gate, the share of the sun the score lets through, and a
    thin ring keeps a faint sun findable."""
    h, w, _ = canvas.shape
    cx = w / 2.0 + _wrap_deg(sun_az - yaw) * ppd
    cy = (GROUND_EL_MAX - sun_deg) * ppd
    g = 1.0 if gate is None else min(1.0, max(0.0, gate))
    dull, bright = np.array(style["sun_dull"], dtype=float), np.array(style["sun_bright"], dtype=float)
    rgb = dull * (1.0 - g) + bright * g
    R = (GROUND_SUN_DRAW_DEG if radius_deg is None else radius_deg) * ppd
    x0, x1 = max(int(cx - R - 3), 0), min(int(cx + R + 4), w)
    y0, y1 = max(int(cy - R - 3), 0), min(int(cy + R + 4), h)
    if x1 <= x0 or y1 <= y0:
        return
    X, Y = np.meshgrid(np.arange(x0, x1) + 0.5, np.arange(y0, y1) + 0.5)
    r = np.hypot(X - cx, Y - cy)
    disc = np.clip(R - r + 0.5, 0.0, 1.0)
    ring = np.clip(1.0 - np.abs(r - R - 1.5) / 1.0, 0.0, 1.0) * 0.55
    a = (disc * (0.3 + 0.7 * g))[..., None]
    patch = canvas[y0:y1, x0:x1]
    patch[:] = patch * (1.0 - a) + rgb * a
    ring = ring[..., None]
    patch[:] = patch * (1.0 - ring) + np.array(style["sun_ring"], dtype=float) * ring


def _ground_plain(canvas, yaw, ppd, eye_m, sun_az, gate, style, np):
    """A flat plain at sea level out to the horizon, seen from `eye_m` above it (the observer's height, the
    same assumption the horizon dip makes).  Each row below the horizon is a distance on the plain; the grid
    is the same 3 km grid the clouds sit on, drawn brighter every 30 km (the forecast cell edges), and the
    far ground fades into the haze of the sky's horizon so that it recedes."""
    h, w, _ = canvas.shape
    dip = horizon_dip_deg(eye_m)
    gy = max(int(math.ceil((GROUND_EL_MAX + dip) * ppd - 0.5)), 0)
    if gy >= h:
        return h
    rows = np.arange(gy, h)
    el = GROUND_EL_MAX - (rows + 0.5) / ppd
    d_h = math.sqrt(2.0 * EARTH_RADIUS_KM * (eye_m / 1000.0) / (1.0 - REFRACTION_K))          # km to the horizon
    dg = np.geomspace(1e-3, d_h, 4000)
    eg = (-np.degrees(np.arctan2(eye_m, dg * 1000.0)) - np.degrees((1.0 - REFRACTION_K) * dg / (2.0 * EARTH_RADIUS_KM)))
    d_row = np.interp(el, eg, dg)                                                             # eg rises to -dip at d_h
    theta = (np.arange(w) + 0.5 - w / 2.0) / ppd
    b = np.radians(yaw + theta)
    E = d_row[:, None] * np.sin(b)[None, :]
    Nn = d_row[:, None] * np.cos(b)[None, :]
    haze = np.array(style["ground_haze"] or style["sky_horizon"], dtype=float)
    near = np.array(style["ground_near"], dtype=float)
    fh = np.clip(1.0 - np.exp(-2.4 * d_row / d_h), 0.0, 1.0)[:, None, None]
    base = near[None, None, :] * (1.0 - 0.72 * fh) + haze[None, None, :] * (0.72 * fh)
    rel_sun = _wrap_deg(sun_az - yaw)
    g = 1.0 if gate is None else min(1.0, max(0.0, gate))
    warm = style["ground_glow"] * g * np.exp(-((theta - rel_sun) / 24.0) ** 2)[None, :] * (fh[:, :, 0] ** 1.5)
    base = base + warm[..., None] * np.array(style["glow_rgb"], dtype=float)[None, None, :]

    def lines(u, scale):
        du_x, du_y = np.gradient(u, axis=1), np.gradient(u, axis=0)
        width = np.maximum((np.abs(du_x) + np.abs(du_y)) / scale, 1e-6)                       # grid units per pixel
        f = np.abs(u / scale - np.rint(u / scale))
        cov = np.clip(1.0 - f / width, 0.0, 1.0)
        return cov * np.clip((1.0 - width) / 0.5, 0.0, 1.0)

    minor = np.maximum(lines(E, GROUND_STEP_KM), lines(Nn, GROUND_STEP_KM))
    major = np.maximum(lines(E - 15.0, 30.0), lines(Nn - 15.0, 30.0))
    line_rgb = np.array(style["ground_line"], dtype=float)
    ground = base
    for cov, a in ((minor, 0.45), (major, 0.80)):
        k = (cov * a)[..., None]
        ground = ground * (1.0 - k) + line_rgb * k
    canvas[gy:] = ground
    canvas[gy] = canvas[gy] * 0.5 + haze * 0.5                                                # the horizon itself
    return gy


def render_ground_view(boxes, yaw, elev_m, sun_az=None, sun_deg=GROUND_SUN_DEG, gate=None, title="",
                       subtitle="", legend=None, np=None, ppd=GROUND_PPD, hfov=GROUND_HFOV,
                       style="data", lattice=None, lit=None, frame=None):
    """The sky as seen from the ground looking toward compass bearing `yaw`.

    Boxes are snapped onto the shared 3 km grid (boxes_to_lattice) and drawn by marching along each line of
    sight: flat translucent colour per layer, opaque in proportion to cover (merged within a layer), the grid
    drawn on the top and the underside of every cloud square, over a sky with the sun in it and a flat plain
    out to the horizon.  The sun is bigger than life, its shade set by the gate.  style "data" colours each
    layer; style "sunset" draws the sky blue, clouds grey and, where `lit` (per layer, on the lattice; see
    sunset_lit) says the score expects the sunset to reach them, in a sunset hue.  `boxes`: GROUND_BOX_COLS.
    `frame` (a time-slider frame, see sunset_motion): {"style": the style dict for this moment, "keys": {layer:
    int array on the lattice}, "palette": {layer: (nkeys, 3) colours}, "sun_radius": degrees}; it replaces
    `style` and `lit`, and the sun is then drawn where `sun_deg` puts it (below the horizon it is hidden)."""
    st = GROUND_STYLES[style] if frame is None else frame["style"]
    w = int(round(hfov * ppd))
    h = int(round((GROUND_EL_MAX - GROUND_EL_MIN) * ppd))
    eye = max(elev_m, 2.0)
    dip = horizon_dip_deg(eye)
    sun_az = yaw if sun_az is None else sun_az
    canvas = _sky_canvas(w, h, ppd, yaw, sun_az, sun_deg, gate, dip, st, np)
    if frame is not None and frame.get("sky_extra") is not None:               # e.g. the Earth's shadow in the reverse view
        frame["sky_extra"](canvas, ppd, yaw, w, h, dip, np)
    if lattice is None:
        lattice = boxes_to_lattice(boxes, np)
    for L in ("high", "mid", "low"):                                           # far layers first, low cloud in front
        cover, bottom, top = lattice["cover"][L], lattice["bottom"][L], lattice["top"][L]
        if not (cover >= GROUND_MIN_COVER).any():
            continue
        if frame is None:
            opac, colour, bw = _march_layer(cover, bottom, top, None if lit is None else lit[L], L, yaw, ppd, w, h, st, np)
            grey, hue = (np.array(c, dtype=float) for c in st["cloud"][L])
            table = np.array([_lit_shade(grey, hue, k / (GROUND_LIT_LEVELS - 1), np) for k in range(GROUND_LIT_LEVELS)])
        else:
            table = np.asarray(frame["palette"][L], dtype=float)
            opac, colour, bw = _march_layer(cover, bottom, top, None, L, yaw, ppd, w, h, st, np,
                                            keys=frame["keys"][L], nkeys=len(table))
        rgb = table[colour]
        canvas[:] = canvas * (1.0 - opac[..., None]) + rgb * opac[..., None]
        mask = bw > 0                                                          # the outline round cloud that has substance
        inner = mask.copy()
        inner[1:] &= mask[:-1]
        inner[:-1] &= mask[1:]
        inner[:, 1:] &= mask[:, :-1]
        inner[:, :-1] &= mask[:, 1:]
        edge_rgb = np.minimum(255.0, 0.4 * rgb + 155.0)
        line = (0.8 * (mask & ~inner) * bw)[..., None]
        canvas[:] = canvas * (1.0 - line) + edge_rgb * line
        grid = _cloud_lines(cover, bottom, top, yaw, ppd, w, h, hfov, np, layer=L)   # the 3 km grid on every square worth one
        k = (grid * st["line_alpha"])[..., None]
        canvas[:] = canvas * (1.0 - k) + edge_rgb * k
    _draw_sun(canvas, ppd, yaw, sun_az, sun_deg, gate, st, np, None if frame is None else frame.get("sun_radius"))
    gy = _ground_plain(canvas, yaw, ppd, eye, sun_az, gate, st, np)
    img = np.clip(canvas, 0, 255).astype(np.uint8)

    # elevation scale on the left; compass bearings on a strip under the picture
    for el in range(0, int(GROUND_EL_MAX) + 1, 10):
        row = int(round((GROUND_EL_MAX - el) * ppd))
        if 0 <= row < h:
            if el > 0:
                img[row, ::6] = (235, 235, 245)
            _draw_text(img, max(row - 4, 0) if el < GROUND_EL_MAX else row, 4, "%d" % el, color=(235, 238, 248), scale=1)
    names = {0: "N", 45: "NE", 90: "E", 135: "SE", 180: "S", 225: "SW", 270: "W", 315: "NW"}
    strip_h = 26
    strip = np.zeros((strip_h, w, 3), dtype=np.uint8)
    strip[:] = (14, 18, 26)
    first = int(math.ceil((yaw - hfov / 2.0) / 5.0)) * 5
    for b in range(first, int(yaw + hfov / 2.0) + 1, 5):
        col = int(round(w / 2.0 + (b - yaw) * ppd))
        bb = b % 360
        long_tick = bb % 10 == 0
        if 0 <= col < w:
            strip[0:(8 if long_tick else 4), col] = (200, 205, 215)
        if long_tick and 12 <= col < w - 18:
            _draw_text(strip, 9, col - 9, "%d" % bb, color=(190, 200, 215), scale=1)
        if bb in names and 12 <= col < w - 18:
            _draw_text(strip, 17, col - 3 * len(names[bb]), names[bb], color=(255, 215, 110), scale=1)

    rows = legend if legend is not None else []
    head, foot = 46, 10 + 15 * len(rows)
    out = np.zeros((head + h + strip_h + foot, w, 3), dtype=np.uint8)
    out[head:head + h] = img
    out[head + h:head + h + strip_h] = strip
    _draw_text(out, 6, 8, title)
    _draw_text(out, 26, 8, subtitle, color=(190, 200, 215))
    sun_col = int(round(w / 2.0 + _wrap_deg(sun_az - yaw) * ppd))
    if 40 <= sun_col < w - 140 and (frame is None or sun_deg > -dip - 0.3):
        sun_row = head + int((GROUND_EL_MAX - sun_deg) * ppd)
        label = "SUN" if gate is None else "SUN  GATE %.2f" % gate
        _draw_text(out, max(head + 2, sun_row - int(GROUND_SUN_DRAW_DEG * ppd) - 14), sun_col - 3 * len(label), label,
                   color=(255, 245, 225), scale=1)
    for r_i, row in enumerate(rows):
        col = 8
        top_px = head + h + strip_h + 6 + r_i * 15
        for rgb, label in row:
            out[top_px:top_px + 10, col:col + 12] = rgb
            _draw_text(out, top_px, col + 16, label, scale=1)
            col += 16 + 6 * len(label) + 18
    return out


def anti_twilight(el, rel, depression, np):
    """The sky opposite the setting sun, as weights 0..1: (shadow, belt).

    After sunset the Earth's own shadow rises from the horizon opposite the sun as a dark blue-grey band, and
    above it the air the sun still reaches (low sun, long path) glows pink: the Belt of Venus.  At the antisolar
    point the shadow's top stands as high as the sun is deep below the horizon (`depression`, degrees; a
    geometric height, refraction ignored); away from it, at azimuth offset `rel`, it sinks as cos(rel).  The
    band shows from about sunset, is strongest in the first twilight and merges into the night sky after.
    `el` (elevation) and `rel` (azimuth offset from the antisolar bearing) are degrees and broadcast together."""
    d = max(0.0, float(depression))
    el, rel = np.broadcast_arrays(np.asarray(el, dtype=float), np.asarray(rel, dtype=float))
    zero = np.zeros(el.shape)
    if d <= 0.0:
        return zero, zero
    c = np.maximum(np.cos(np.radians(rel)), 0.0)
    x = el - d * c                                                      # height above the shadow's top
    shadow = 1.0 / (1.0 + np.exp(np.clip(x / 0.6, -30.0, 30.0)))
    onset = min(1.0, d / 0.8)
    shadow = shadow * onset * max(0.0, min(1.0, (16.0 - d) / 6.0)) * np.clip(c * 1.5, 0.0, 1.0)
    rise = 1.0 / (1.0 + np.exp(np.clip(-x / 1.0, -30.0, 30.0)))          # none below the top of the shadow
    belt = (np.exp(-((x - 3.5) / 4.5) ** 2) * rise * np.exp(-(rel / 45.0) ** 2)
            * onset * max(0.0, min(1.0, (14.0 - d) / 6.0)) * np.clip(c * 1.2, 0.0, 1.0))
    return shadow, belt


DOME_RADIUS_PX = 330                    # the overhead picture: pixels from the zenith to the horizon
DOME_SAMPLES = 96                       # points along each line of sight inside a layer's height range
DOME_CHUNK = 20000
SHADOW_RGB = (52, 60, 98)
BELT_RGB = (236, 150, 172)


def _dome_layer(cover, bottom, top, keys, nkeys, el, phi, ok_px, style, L, np):
    """One cloud layer in the overhead picture.  Each pixel is a direction (elevation `el`, bearing `phi`); the line
    of sight is followed through the layer's height range and every sample is looked up on the 3 km lattice
    (a sample is in the cloud when it is between that square's bottom and top).  The pixel's opacity is the
    largest cover found, as in the ground view (so a long run of squares does not pile up).  Returns (opacity, key)."""
    n = cover.shape[0]
    present = (cover >= GROUND_MIN_COVER) & np.isfinite(top) & np.isfinite(bottom)
    opac = np.zeros(el.shape, dtype=np.float32)
    colour = np.zeros(el.shape, dtype=np.int16)
    bw = np.zeros(el.shape, dtype=np.float32)
    if not present.any():
        return opac, colour, bw
    zlo = max(float(bottom[present].min()), 1.0)
    zhi = float(top[present].max())
    cov_all = np.where(present, cover, 0.0).ravel()
    bot_all, top_all = np.nan_to_num(bottom).ravel(), np.nan_to_num(top).ravel()
    key_all = keys.ravel()
    amax, floor = style["alpha_max"][L], style["alpha_floor"]
    pix = np.nonzero(ok_px.ravel())[0]
    u = (np.arange(DOME_SAMPLES) + 0.5) / DOME_SAMPLES
    op_flat, co_flat, bw_flat = opac.ravel(), colour.ravel(), bw.ravel()
    el_f, phi_f = el.ravel(), phi.ravel()
    for s0 in range(0, len(pix), DOME_CHUNK):
        ix = pix[s0:s0 + DOME_CHUNK]
        e, b = el_f[ix], np.radians(phi_f[ix])
        tn = np.tan(np.radians(e))
        d_lo = np.minimum(0.6 * zlo / 1000.0 / tn, GROUND_REACH_KM)
        d_hi = np.minimum(zhi / 1000.0 / tn, GROUND_REACH_KM)
        live = d_hi > d_lo
        if not live.any():
            continue
        d = d_lo[:, None] + (d_hi - d_lo)[:, None] * u[None, :]
        curv = np.degrees((1.0 - REFRACTION_K) * d / (2.0 * EARTH_RADIUS_KM))
        z = d * 1000.0 * np.tan(np.radians(e[:, None] + curv))
        ie = np.floor(d * np.sin(b)[:, None] / GROUND_STEP_KM).astype(int) + n // 2
        inn = np.floor(d * np.cos(b)[:, None] / GROUND_STEP_KM).astype(int) + n // 2
        inside = (ie >= 0) & (ie < n) & (inn >= 0) & (inn < n)
        flat = np.clip(inn, 0, n - 1) * n + np.clip(ie, 0, n - 1)
        hit = inside & (z >= bot_all[flat]) & (z <= top_all[flat]) & live[:, None]
        cov = np.where(hit, cov_all[flat], 0.0)
        best = np.argmax(cov, axis=1)
        rows = np.arange(len(ix))
        cmax = cov[rows, best]
        found = cmax >= GROUND_MIN_COVER
        if not found.any():
            continue
        q = np.clip(np.ceil(cmax * GROUND_ALPHA_LEVELS), 1, GROUND_ALPHA_LEVELS)
        a = amax * (floor + (1.0 - floor) * q / GROUND_ALPHA_LEVELS)
        op_flat[ix[found]] = a[found]
        co_flat[ix[found]] = key_all[flat[rows, best]][found]
        bw_flat[ix[found]] = border_weight((q - 0.5) / GROUND_ALPHA_LEVELS, L, np)[found]
    return opac, colour, bw


def render_dome_view(lattice, elev_m, sun_az, sun_deg, gate, frame, title, subtitle, legend, np,
                     depression=0.0, radius=DOME_RADIUS_PX):
    """The sky straight up: an azimuthal-equidistant fisheye, zenith in the middle and the horizon on the rim
    (angle from the zenith is proportional to the distance from the centre), north at the top and east on the
    left, as on a chart held overhead.  Clouds are the same lattice squares as in the ground view, found by
    following each pixel's line of sight through each layer; the sky has the sun's glow and, opposite it, the
    Earth's shadow and the Belt of Venus (anti_twilight).  `frame` is a ground-view frame dict (style, keys, palette)."""
    st = frame["style"]
    R = int(radius)
    size = 2 * R
    yy, xx = np.mgrid[0:size, 0:size]
    dx, dy = xx + 0.5 - R, yy + 0.5 - R
    r = np.hypot(dx, dy)
    disc = r <= R
    el = 90.0 - r / R * 90.0
    phi = np.degrees(np.arctan2(-dx, -dy)) % 360.0                             # north up, east on the left
    t = np.clip(el / 50.0, 0.0, 1.0) ** st["sky_pow"]
    horizon, zenith = np.array(st["sky_horizon"], dtype=float), np.array(st["sky_zenith"], dtype=float)
    canvas = horizon[None, None, :] * (1.0 - t[..., None]) + zenith[None, None, :] * t[..., None]
    se, er = math.radians(sun_deg), np.radians(np.clip(el, -5.0, 90.0))
    cosg = np.sin(er) * math.sin(se) + np.cos(er) * math.cos(se) * np.cos(np.radians(phi - sun_az))
    gamma = np.degrees(np.arccos(np.clip(cosg, -1.0, 1.0)))
    g = 1.0 if gate is None else min(1.0, max(0.0, gate))
    glow = (0.3 + 0.7 * g) * (0.55 * np.exp(-(gamma / 9.0) ** 2) + 0.28 * np.exp(-(gamma / 30.0) ** 2))
    canvas = canvas + glow[..., None] * np.array(st["glow_rgb"], dtype=float)[None, None, :] * st["glow_k"]
    shadow, belt = anti_twilight(el, _wrap_deg(phi - (sun_az + 180.0)), depression, np)
    canvas = canvas * (1.0 - 0.75 * shadow[..., None]) + np.array(SHADOW_RGB, dtype=float) * 0.75 * shadow[..., None]
    canvas = canvas * (1.0 - 0.50 * belt[..., None]) + np.array(BELT_RGB, dtype=float) * 0.50 * belt[..., None]
    ok_px = disc & (el > 0.05)
    for L in ("high", "mid", "low"):
        cover, bottom, top = lattice["cover"][L], lattice["bottom"][L], lattice["top"][L]
        if not (cover >= GROUND_MIN_COVER).any():
            continue
        table = np.asarray(frame["palette"][L], dtype=float)
        opac, colour, bw = _dome_layer(cover, bottom, top, frame["keys"][L], len(table), el, phi, ok_px, st, L, np)
        rgb = table[np.clip(colour, 0, len(table) - 1)]
        canvas = canvas * (1.0 - opac[..., None]) + rgb * opac[..., None]
        mask = bw > 0                                                          # the outline round cloud that has substance
        inner = mask.copy()
        inner[1:] &= mask[:-1]
        inner[:-1] &= mask[1:]
        inner[:, 1:] &= mask[:, :-1]
        inner[:, :-1] &= mask[:, 1:]
        line = (0.8 * (mask & ~inner) * bw)[..., None]
        canvas = canvas * (1.0 - line) + np.minimum(255.0, 0.4 * rgb + 155.0) * line
    if sun_deg > -1.5:                                                         # the sun, where it stands
        rs = (90.0 - sun_deg) / 90.0 * R
        sx, sy = R - rs * math.sin(math.radians(sun_az)), R - rs * math.cos(math.radians(sun_az))
        Rd = max(3.0, GROUND_SUN_DRAW_DEG / 90.0 * R)
        dull, bright = np.array(st["sun_dull"], dtype=float), np.array(st["sun_bright"], dtype=float)
        a = np.clip(Rd - np.hypot(xx + 0.5 - sx, yy + 0.5 - sy) + 0.5, 0.0, 1.0) * (0.3 + 0.7 * g)
        canvas = canvas * (1.0 - a[..., None]) + (dull * (1.0 - g) + bright * g)[None, None, :] * a[..., None]
    canvas = np.clip(canvas, 0.0, 255.0)
    for ring_el in (60.0, 30.0):                                               # elevation rings
        rr = (90.0 - ring_el) / 90.0 * R
        near = np.abs(r - rr) < 0.7
        canvas[near & disc] = canvas[near & disc] * 0.65 + np.array([235.0, 238.0, 248.0]) * 0.35
    rim = (np.abs(r - R) < 1.1)
    canvas[rim] = (200.0, 205.0, 215.0)
    bg = np.array([14, 18, 26], dtype=np.uint8)
    pad = 26
    rows = legend if legend is not None else []
    head, foot = 46, 10 + 15 * len(rows)
    out = np.zeros((head + size + 2 * pad + foot, size + 2 * pad, 3), dtype=np.uint8)
    out[:] = bg
    out[head + pad:head + pad + size, pad:pad + size] = np.where(disc[..., None], canvas, bg[None, None, :]).astype(np.uint8)
    for ring_el in (60.0, 30.0):
        rr = (90.0 - ring_el) / 90.0 * R
        _draw_text(out, head + pad + R - int(rr) + 2, pad + R + 3, "%d" % ring_el, color=(235, 238, 248), scale=1)
    gold = (255, 215, 110)
    _draw_text(out, head + 4, pad + R - 6, "N", color=gold, scale=2)
    _draw_text(out, head + pad + 2 * R + 6, pad + R - 6, "S", color=gold, scale=2)
    _draw_text(out, head + pad + R - 7, 6, "E", color=gold, scale=2)
    _draw_text(out, head + pad + R - 7, pad + 2 * R + 8, "W", color=gold, scale=2)
    _draw_text(out, 6, 8, title)
    _draw_text(out, 26, 8, subtitle, color=(190, 200, 215))
    for r_i, row in enumerate(rows):
        col = 8
        top_px = head + size + 2 * pad + 6 + r_i * 15
        for rgb, label in row:
            out[top_px:top_px + 10, col:col + 12] = rgb
            _draw_text(out, top_px, col + 16, label, scale=1)
            col += 16 + 6 * len(label) + 18
    return out


def clear_ground_views(out_dir):
    for path in ([os.path.join(out_dir, GROUND_FILE), os.path.join(out_dir, GROUND_SUNSET_FILE)]
                 + glob.glob(os.path.join(out_dir, MASK_DIR, GROUND_PREFIX + "*.png"))):
        try:
            os.remove(path)
        except OSError:
            pass


def _compass_word(b):
    names = ("N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW")
    return names[int((b % 360.0) / 22.5 + 0.5) % 16]


def write_ground_views(out_dir, lat, lon, az, elev_m, sky_h, hour_label, source, lead_h, gate, sat=None,
                       detail=None, sun_deg=GROUND_SUN_DEG, opposite=True, log=print):
    """Pictures of the sky as seen from the ground, facing the sunset:
        ground_view.png                 forecast and satellite united (the forecast alone when there is no scan)
        ground_sunset_view.png          the same sky in sunset colours: blue sky, grey cloud, and a sunset hue
                                        on the cloud the score expects to be lit (needs `detail`, the score's
                                        region / layer decoration)
        Masks/Ground_Forecast.png       the forecast alone (30 km cells, the model's heights)
        Masks/Ground_Satellite.png      the satellite alone (tops from the scan)
        Masks/Ground_Opposite.png       the united sky facing away from the sun
    Every box sits on the shared 3 km grid; a 30 km forecast cell is a 10 x 10 plane of squares.
    Returns the paths written."""
    try:
        import numpy as np
    except ImportError:
        return []
    clear_ground_views(out_dir)
    os.makedirs(os.path.join(out_dir, MASK_DIR), exist_ok=True)
    where = "%.3f,%.3f" % (lat, lon)
    written = []
    legend = lambda extra: [[(MASK_COLORS[2], "LOW"), (MASK_COLORS[3], "MID"), (MASK_COLORS[4], "HIGH"),
                             ((90, 90, 100), "OPACITY = COVER"), ((255, 238, 160), "SUN SHADE = GATE")] + extra]

    def save(rel, boxes, yaw, title, subtitle, rows, style="data", lit=None, lattice=None):
        path = os.path.join(out_dir, rel)
        img = render_ground_view(boxes, yaw, elev_m, az, sun_deg, gate, title, subtitle, rows, np,
                                 style=style, lattice=lattice, lit=lit)
        _write_png(path, img, np)
        written.append(path)

    def sunset(boxes, subtitle):
        if detail is None:
            return
        lattice = boxes_to_lattice(boxes, np)
        lit = sunset_lit(lattice, az, elev_m, detail, gate, np)
        rows = [[((255, 140, 40), "LOW LIT"), ((255, 86, 52), "MID LIT"), ((240, 96, 170), "HIGH LIT"),
                 ((128, 132, 142), "NOT LIT OR NOT SCORED"), ((60, 110, 190), "SKY"), ((255, 238, 160), "SUN")]]
        save(GROUND_SUNSET_FILE, boxes, az, "SUNSET VIEW  %s  %s" % (where, face),
             "HUE: DECORATION THE SCORE EXPECTS, TIMES GATE  " + subtitle, rows, "sunset", lit, lattice)

    face = "FACING %d (%s)" % (round(az), _compass_word(az))
    fc = forecast_boxes(sky_h, elev_m, np)
    stamp_f = "%s  CELLS 30 KM  LEAD %d H  %s" % (source.upper(), round(lead_h), hour_label)
    scene = sat.get("scene") if sat else None
    if scene is None:
        save(GROUND_FILE, fc, az, "GROUND VIEW  %s  %s" % (where, face), "FORECAST ONLY  " + stamp_f,
             legend([((60, 60, 70), "GRID 3 KM")]))
        sunset(fc, "FORECAST ONLY")
        return written
    obs = scene_cells(scene, "observed", np)
    shf = scene_cells(scene, "shifted", np) if scene.get("shifted") else None
    weights = sat["weights"]
    united = unified_boxes(sky_h, elev_m, obs, shf, weights, np, forecast=True)
    sat_only = unified_boxes(sky_h, elev_m, obs, shf, weights, np, forecast=False)
    stamp = "UNITED FORECAST + SATELLITE  SATELLITE WEIGHT %d%%  SCAN AGE %d MIN" % (
        round(100 * weights["total"]), round(60 * sat["age_h"]))
    note = legend([((60, 60, 70), "GRID 3 KM")])
    save(GROUND_FILE, united, az, "GROUND VIEW  %s  %s" % (where, face), stamp, note)
    sunset(united, "SATELLITE WEIGHT %d%%" % round(100 * weights["total"]))
    save(os.path.join(MASK_DIR, GROUND_PREFIX + "Forecast.png"), fc, az, "GROUND VIEW  FORECAST ONLY  " + face,
         stamp_f, note)
    save(os.path.join(MASK_DIR, GROUND_PREFIX + "Satellite.png"), sat_only, az, "GROUND VIEW  SATELLITE ONLY  " + face,
         "SCAN %s Z  AGE %d MIN  TOPS ONLY, LOWER LAYERS UNDER HIGHER CLOUD NOT SEEN"
         % (sat["scan_utc"].strftime("%Y-%m-%d %H:%M"), round(60 * sat["age_h"])), note)
    if opposite:
        save(os.path.join(MASK_DIR, GROUND_PREFIX + "Opposite.png"), united, (az + 180.0) % 360.0,
             "GROUND VIEW  FACING AWAY FROM THE SUN %d (%s)" % (round((az + 180.0) % 360.0), _compass_word(az + 180.0)),
             stamp, note)
    return written


def build_sat_scene(lat, lon, mask_arr, mask_geom, ht_arr, ht_geom, mask_var, shift, np, step=SAT_STEP_KM):
    """The scan as a map of the sky's contents on the shared 3 km grid: one sample at the centre of every
    `step` km square within SIGHT_MAX_KM of the observer (square edges fall on multiples of `step`, so the
    observer stands on a grid corner and a 30 km forecast cell is ten squares across; row 0 = north edge):
    the class code and the cloud top, as observed and (with a wind shift) as carried to sunset.  This is
    what the ground view is built from."""
    reach = float(SIGHT_MAX_KM)
    k = int(reach // step)
    axis = (np.arange(-k, k) + 0.5) * step
    east, north = np.meshgrid(axis, axis[::-1])
    grids = (mask_arr, mask_geom, ht_arr, ht_geom, mask_var)
    observed = _sat_scan_grid(lat, lon, east, north, *grids, np)
    shifted = _shift_scan_grid(lat, lon, east, north, shift, grids, np) if shift else None
    return {"step": float(step), "reach": reach, "observed": observed, "shifted": shifted}


def satellite_check(lat, lon, az, radius_km, when_utc, cache_dir="cache",
                    get_text=None, get_file=None, log=print, elev_m=None, layer_tops=None,
                    winds=None, sunset_utc=None, mask_dir=None, want_scene=False):
    """Gate computed from the satellite's cloud pixels along the sunset direction,
    plus (when elev_m is given) dapple measured from the satellite pixels.

    winds ({layer: (u, v)} m/s) and sunset_utc turn on the wind shift: the scan is
    read twice, as observed and carried to sunset on the steering winds, and the
    two are blended by sat_weights (a scan loses potency the older it is by sunset).
    Without them only the observed scan is used.

    mask_dir: if given, the pictures of what was read are saved there
    (see write_sat_masks); a failure to draw never costs the check.
    want_scene (or mask_dir): also return the scan as a map of class codes and cloud tops, as
    observed and as shifted (build_sat_scene), for the ground view."""
    get_text = get_text or _http_get
    get_file = get_file or _http_get_file
    os.makedirs(cache_dir, exist_ok=True)
    paths = {}
    for product in (GOES_MASK_PRODUCT, GOES_HEIGHT_PRODUCT):
        try:
            key = goes_scan_key(product, when_utc, get_text)
            dest = os.path.join(cache_dir, os.path.basename(key))
            if not os.path.exists(dest):
                get_file(GOES_URL + key, dest)
        except SatelliteUnavailable:
            raise
        except Exception as err:                          # network, disk, ...
            raise SatelliteUnavailable("could not fetch %s: %s" % (product, err))
        paths[product] = (key, dest)

    mask_ds, mask_geom, np = _open_dataset(paths[GOES_MASK_PRODUCT][1])
    ht_ds, ht_geom, _ = _open_dataset(paths[GOES_HEIGHT_PRODUCT][1])
    try:
        mask_var = next((v for v in ("ACM", "BCM") if v in mask_ds.variables), None)
        if mask_var is None or "HT" not in ht_ds.variables:
            raise SatelliteUnavailable(
                "unexpected GOES variables: mask file has %s, height file has %s"
                % (sorted(mask_ds.variables), sorted(ht_ds.variables)))
        scan_t = _parse_scan_start(paths[GOES_MASK_PRODUCT][0])
        age_h = max(0.0, (sunset_utc - scan_t).total_seconds() / 3600.0) if sunset_utc else 0.0
        shift = shift_vectors(winds, age_h) if (winds and age_h > 0) else None
        weights = sat_weights(age_h, shift is not None)

        def ray_sample(east, north):
            """[] clear / [(layer, top_m)] cloud / None unknown, at this offset."""
            plat, plon = km_to_latlon(lat, lon, east, north)
            m = goes_pixel(mask_ds, mask_geom, np, plat, plon, mask_var)
            if m is None:
                return None
            if not _mask_is_cloudy(mask_var, m):
                return []
            ht = goes_pixel(ht_ds, ht_geom, np, plat, plon, "HT")
            return None if ht is None else [(sat_layer(ht), float(ht))]

        low = valid = total = 0
        offsets = ray_offsets(az, radius_km)
        per_ray = len(offsets) // 3
        rays, rays_shifted = [], []
        for n_ray in range(3):
            samples, samples_shifted = [], []
            for east, north in offsets[n_ray * per_ray:(n_ray + 1) * per_ray]:
                total += 1
                d = math.hypot(east, north)
                got = ray_sample(east, north)
                if got is not None:
                    valid += 1                                  # clear or cloudy-with-height: usable
                    samples += [(d, top) for _, top in got]
                    if any(top < LOW_TOP_M for _, top in got):
                        low += 1
                if shift:
                    moved = shifted_layers(ray_sample, east, north, shift)
                    if moved is not None:
                        samples_shifted += [(d, top) for _, top in moved]
            rays.append(samples)
            rays_shifted.append(samples_shifted)
        block_obs = sat_sight_block(rays, elev_m or 0.0)
        block_shifted = sat_sight_block(rays_shifted, elev_m or 0.0) if shift else None
        ir = ir_img = None
        if elev_m is not None and valid:
            try:
                ir_key = goes_scan_key(GOES_IR_PRODUCT, when_utc, get_text, GOES_IR_BAND)
                ir_dest = os.path.join(cache_dir, os.path.basename(ir_key))
                if not os.path.exists(ir_dest):
                    get_file(GOES_URL + ir_key, ir_dest)
                ir_ds, ir_geom, _ = _open_dataset(ir_dest)
                try:
                    ir_arr = ir_ds.variables["CMI"][:]
                    ir_img = (ir_arr, ir_geom)
                    ir = satellite_ir_texture(lat, lon, az, elev_m, ir_arr, ir_geom, np, layer_tops)
                finally:
                    ir_ds.close()
            except Exception as err:                      # imagery is a bonus; never lose the gate
                log("Infrared texture skipped: %s" % err)
        dap = dap_obs = dap_shifted = None
        mask_full = ht_full = None
        if valid and (elev_m is not None or mask_dir or want_scene):
            mask_full, ht_full = mask_ds.variables[mask_var][:], ht_ds.variables["HT"][:]
        if elev_m is not None and valid:
            try:
                args = (lat, lon, az, elev_m, mask_full, mask_geom, ht_full, ht_geom, mask_var, np)
                dap_obs = satellite_dapple(*args, layer_tops=layer_tops)
                if shift:
                    dap_shifted = satellite_dapple(*args, layer_tops=layer_tops, shift=shift)
                dap = blend_dapple(dap_obs, dap_shifted, weights["unshifted"], weights["shifted"])
            except Exception as err:                      # never lose the gate over this
                log("Satellite dapple skipped: %s" % err)
        scene = None
        if (mask_dir or want_scene) and valid:
            try:
                scene = build_sat_scene(lat, lon, mask_full, mask_geom, ht_full, ht_geom, mask_var, shift, np)
            except Exception as err:
                log("Satellite scene skipped: %s" % err)
        if mask_dir and valid:
            try:
                files = write_sat_masks(mask_dir, lat, lon, az, elev_m or 0.0, layer_tops, scan_t, age_h,
                                        mask_full, mask_geom, ht_full, ht_geom, mask_var, ir_img, shift, np,
                                        scene=scene)
                log("Satellite mask pictures: %s and %d more in %s"
                    % (os.path.join(mask_dir, MASK_FILE), len(files) - 1, os.path.join(mask_dir, MASK_DIR)))
            except Exception as err:
                log("Mask pictures skipped: %s" % err)
    finally:
        mask_ds.close()
        ht_ds.close()
    if valid == 0:
        raise SatelliteUnavailable("no valid satellite pixels along the sunset direction")
    frac = low / valid
    gate_obs = gate_value(block_obs, 0.0)
    gate_shifted = gate_value(block_shifted, 0.0) if block_shifted is not None else None
    if shift and weights["unshifted"] + weights["shifted"] > 0:
        w0, w1 = weights["unshifted"], weights["shifted"]
        gate = (w0 * gate_obs + w1 * gate_shifted) / (w0 + w1)
        block = (w0 * block_obs + w1 * block_shifted) / (w0 + w1)
    else:
        gate, block = gate_obs, block_obs
    return {"gate": gate, "block": block, "gate_observed": gate_obs, "gate_shifted": gate_shifted,
            "block_observed": block_obs, "block_shifted": block_shifted,
            "low_fraction": frac, "valid": valid, "total": total, "scan_utc": scan_t,
            "age_h": age_h, "weights": weights, "winds": winds if shift else None,
            "shift_km": shift, "dapple": dap, "ir": ir, "scene": scene}


# --------------------------------------------------------- the explanation
def _cover_word(c):
    if c < 0.10:
        return "almost clear"
    if c < 0.33:
        return "light"
    if c <= 0.67:
        return "a good amount"
    if c < 0.90:
        return "heavy"
    return "solid"


def _texture_word(d):
    if d >= 0.65:
        return "broken and dappled"
    if d >= 0.35:
        return "patchy"
    return "clumped together"


def verdict(score):
    if score < 15:
        return "sun blocked or nothing to see"
    if score < 35:
        return "plain"
    if score < 60:
        return "decent"
    if score < 80:
        return "good"
    return "excellent"


def explain(result):
    """A few plain sentences about where the score came from (mid hour)."""
    r = result["mid_hour"]
    lines = []
    low = r["low_mean"]
    sight = r.get("sight")
    if r["gate"] >= 0.9:
        head = "The sun should be visible"
    elif r["gate"] > 0.3:
        head = "The sun may be partly hidden"
    else:
        head = "The sun is likely blocked"
    if sight:
        lines.append("%s: cloud at the sun's own height covers about %d%% of the line of sight "
                     "(low cloud toward it averages %d%%)." % (head, round(100 * sight["block"]), round(100 * low)))
        worst = max(sight["layers"].items(), key=lambda kv: kv[1]["block"])
        name, lay = worst
        if lay["block"] >= 0.1 and lay["span_km"]:
            lines.append("That comes from the %s layer (%.1f-%.1f km up), %d-%d km out."
                         % (name, lay["bottom_m"] / 1000.0, lay["top_m"] / 1000.0,
                            lay["span_km"][0], lay["span_km"][1]))
    else:
        lines.append("%s: low cloud toward the sunset direction averages %d%%."
                     % (head, round(100 * low)))
    if r["rain_mean"] > RAIN_LIMIT:
        lines.append("Rain along the sun direction cuts the score further.")
    best, best_val = None, 0.0
    if r["gate"] <= 0.3:                      # sun hidden: colour talk would mislead
        lines.append("Whatever colour is up there will mostly stay hidden from you.")
        return lines + _satellite_lines(result, r)
    for region, per_layer in r["detail"].items():
        for L, (cover, dap, dec) in per_layer.items():
            contrib = R_WEIGHT[region] * LAYER_WEIGHTS[region][L] * dec
            if contrib > best_val:
                best, best_val = (region, L, cover, dap), contrib
    if best is None or best_val < 0.02:
        lines.append("There is little cloud in the right places to catch colour, so "
                     "expect a plain sunset.")
    else:
        region, L, cover, dap = best
        lines.append("Most colour should come from %s cloud in the %s (%s, %s)."
                     % (L, REGION_NAMES[region], _cover_word(cover), _texture_word(dap)))
    return lines + _satellite_lines(result, r)


def _satellite_lines(result, r):
    sat = result.get("satellite")
    if sat:
        agree = abs(sat["gate"] - r.get("gate_forecast", r["gate"])) <= 0.5
        lines = ["Satellite check: cloud tops seen from space hide about %d%% of the sun "
                 "(%d%% of the pixels toward it are low cloud; gate %.2f) -- %s the forecast."
                 % (round(100 * sat["block"]), round(100 * sat["low_fraction"]), sat["gate"],
                    "agrees with" if agree else "DISAGREES with")]
        w = sat.get("weights")
        if w and sat.get("age_h", 0.0) > 0:
            age = "%d min" % round(60 * sat["age_h"]) if sat["age_h"] < 2 else "%.1f h" % sat["age_h"]
            if sat.get("shift_km"):
                sp = {L: math.hypot(*sat["winds"][L]) for L in LAYERS}
                lines.append("The scan is %s old by sunset, so it is carried on the model's steering winds "
                             "(%s) and given %d%% of its full weight: %d%% moved, %d%% as observed "
                             "(the rest is the forecast)."
                             % (age, ", ".join("%s %d m/s" % (L, round(sp[L])) for L in LAYERS),
                                round(100 * w["total"]), round(100 * w["shifted"]),
                                round(100 * w["unshifted"])))
            else:
                lines.append("The scan is %s old by sunset (no wind shift); it gets %d%% of its full weight."
                             % (age, round(100 * w["total"])))
        dap = sat.get("dapple")
        if dap:
            parts = ["%s %.2f" % (L, dap["fwd"][L]) for L in LAYERS if dap["fwd"][L] is not None]
            if parts:
                lines.append("Dapple measured from satellite pixels toward the sun "
                             "(0 smooth .. 1 broken): " + ", ".join(parts) + ".")
        ir = sat.get("ir")
        if ir:
            parts = ["%s %.1f K (%d%% cold cloud)" % (REGION_NAMES[k], ir[k]["roughness"],
                                                        round(100 * ir[k]["valid"]))
                     for k in ("fwd", "over") if ir.get(k)]
            if parts:
                lines.append("Infrared cloud-top roughness (smooth overcast ~1 K, rippled ~1.8 K): "
                             + "; ".join(parts) + ".")
        return lines
    if result.get("satellite_note"):
        note = result["satellite_note"]
        if len(note) > 110:
            note = note[:107] + "..."
        return ["Satellite check skipped: %s." % note]
    return []


# -------------------------------------------------------------- the program
def run(lat, lon, date_str, now_utc=None, cache_dir="cache", use_sat=True,
        fetch_json=None, goes_get_text=None, goes_get_file=None, log=print,
        source=None, fetch_file=None, gfs_cube=True, mask_dir=None, ground_view=True, frames=False):
    """Compute the whole result for one location and date (no printing of the
    report itself; see format_report).

    source: "gfs" (NOAA GFS grid, one download; falls back to Open-Meteo if it
    fails) or "openmeteo".  None picks "openmeteo" only when an Open-Meteo
    fetcher was injected (tests), otherwise "gfs"."""
    date = datetime.date.fromisoformat(date_str)
    now_utc = now_utc or datetime.datetime.now(datetime.timezone.utc)
    az = sunset_azimuth(lat, date.year, date.month, date.day)
    local, sunset_utc = sunset_local(lat, lon, date)
    hours = sunset_hours(local)
    today = now_utc.astimezone(datetime.timezone(datetime.timedelta(
        hours=eastern_utc_offset_hours(now_utc.date())))).date()

    if source is None:
        source = "openmeteo" if (fetch_json is not None and fetch_file is None) else "gfs"
    sky = None
    used = "Open-Meteo"
    if source == "gfs":
        try:
            sky, elev = fetch_sky_gfs(lat, lon, date_str, hours, sunset_utc, cache_dir,
                                      fetch_file, log, now_utc, cube=gfs_cube)
            used = "NOAA GFS"
        except RuntimeError as err:
            log("GFS unavailable (%s); falling back to Open-Meteo" % err)
    if sky is None:
        sky, elev = fetch_sky(lat, lon, date_str, hours, cache_dir, fetch_json, today, log)
    elev_m = elev[N][N]
    mid_h = hours[len(hours) // 2]
    tops = None                          # each layer's top above the observer, when the model gives it
    if "cube" in sky[mid_h]:
        typical = {L: layer_typical(sky[mid_h], L) for L in LAYERS}
        tops = {L: max(typical[L][1] - elev_m, 100.0) for L in LAYERS}

    lead_h = max((sunset_utc - now_utc).total_seconds() / 3600.0, 0.0)
    sat, note = None, None
    winds = None
    if use_sat:
        when = satellite_time(now_utc, sunset_utc)
        if when is None:
            note = "sunset is more than %d hours away" % SAT_WINDOW_H
        else:
            if used == "NOAA GFS" and when < sunset_utc:        # a scan from before sunset gets carried to it
                try:
                    winds = fetch_winds(lat, lon, date_str, when, sunset_utc, cache_dir,
                                        fetch_file, log, now_utc)
                except Exception as err:
                    log("Wind shift skipped (%s); using the scan as observed" % str(err)[:90])
            try:
                sat = satellite_check(lat, lon, az, SIGHT_MAX_KM, when, cache_dir,
                    goes_get_text, goes_get_file, log, elev_m=elev_m, layer_tops=tops,
                    winds=winds, sunset_utc=sunset_utc, mask_dir=mask_dir,
                    want_scene=bool((mask_dir and ground_view) or frames))
            except SatelliteUnavailable as err:
                note = str(err)
    if frames and used == "NOAA GFS" and winds is None:         # the time slider moves cloud on the winds
        try:
            winds = fetch_winds(lat, lon, date_str, sunset_utc - datetime.timedelta(hours=1), sunset_utc,
                                cache_dir, fetch_file, log, now_utc)
        except Exception as err:
            log("Winds for the time slider unavailable (%s); the clouds will not drift" % str(err)[:90])
    if mask_dir and sat is None:
        clear_masks(mask_dir, log)
    if mask_dir:
        try:
            detail = None
            if used == "NOAA GFS":
                try:
                    detail = fetch_detail(lat, lon, date_str, sunset_utc, cache_dir, fetch_file, log, now_utc)
                except Exception as err:
                    log("Forecast detail pictures skipped (%s)" % str(err)[:90])
            written = write_forecast_masks(mask_dir, lat, lon, az, elev_m, sky[mid_h], elev,
                                           "%02d:00 LOCAL" % mid_h, used, lead_h, detail, tops)
            if written:
                log("Forecast pictures: %s and %d more in %s"
                    % (os.path.join(mask_dir, FORECAST_FILE), len(written) - 1, os.path.join(mask_dir, MASK_DIR)))
        except Exception as err:
            log("Forecast pictures skipped: %s" % err)
    sat_w = sat["weights"]["total"] if sat else 0.0
    mean, lo, hi, per_hour = score_range(sky, hours, az, elev_m,
                                         sat["dapple"] if sat else None,
                                         sat.get("ir") if sat else None,
                                         sat_weight=sat_w,
                                         sat_gate=sat["gate"] if sat else None,
                                         sat_gate_w=SAT_GATE_MAX_W * sat_w)
    mid = per_hour[hours[len(hours) // 2]]
    if mask_dir and ground_view:
        try:
            written = write_ground_views(mask_dir, lat, lon, az, elev_m, sky[mid_h], "%02d:00 LOCAL" % mid_h,
                                         used, lead_h, mid["gate"], sat, detail=mid["detail"], log=log)
            if written:
                log("Ground view pictures: %s and %d more in %s"
                    % (os.path.join(mask_dir, GROUND_FILE), len(written) - 1, os.path.join(mask_dir, MASK_DIR)))
        except Exception as err:
            log("Ground view skipped: %s" % err)
    elif mask_dir:
        clear_ground_views(mask_dir)
    breakdown = average_points([per_hour[h]["points"] for h in hours])
    gap = abs(sat["gate"] - mid["gate_forecast"]) if sat else 0.0
    return {"lat": lat, "lon": lon, "date": date_str, "azimuth": az, "source": used,
            "cube": tops is not None, "breakdown": breakdown,
            "sunset_local": local, "hours": hours, "elevation_m": elev_m,
            "score": mean, "low": lo, "high": hi, "per_hour": per_hour,
            "mid_hour": mid, "lead_h": lead_h, "confidence": confidence(lead_h, gap),
            "satellite": sat, "satellite_note": note,
            "motion_inputs": ({"lat": lat, "lon": lon, "az": az, "elev_m": elev_m, "sunset_utc": sunset_utc,
                               "sunset_local": local, "sky": sky, "hours": hours, "winds": winds,
                               "detail": mid["detail"], "gate": mid["gate"], "sat": sat,
                               "typical": mid.get("typical"),
                               "source": used, "lead_h": lead_h} if frames else None)}


LAYER_NAMES = {"low": "low cloud", "mid": "mid cloud", "high": "high cloud"}


def breakdown_lines(bd):
    """The score as points earned / points possible, averaged over the hours."""
    def row(label, earned, mx, indent=4):
        return "%s%-*s %5.1f / %4.1f" % (" " * indent, 26 - indent + 4, label, earned, mx)
    out = ["  Score breakdown (points earned / possible; a perfect sky is 100):",
           row("Sun visible (floor)", bd["floor"]["earned"], bd["floor"]["max"])]
    for name in ("fwd", "over", "anti"):
        reg = bd["regions"][name]
        out.append(row(REGION_NAMES[name].capitalize(), reg["earned"], reg["max"]))
        for L in LAYERS:
            lay = reg["layers"][L]
            out.append(row(LAYER_NAMES[L], lay["earned"], lay["max"], 8))
        if abs(reg["ir"]) >= 0.05:
            out.append("%s%-*s %+5.1f" % (" " * 8, 22, "infrared texture bonus", reg["ir"]))
    if bd["cloud_loss"] >= 0.05:
        out.append("%s%-*s %+5.1f" % (" " * 4, 26, "Sun hidden by cloud", -bd["cloud_loss"]))
    if bd["rain_loss"] >= 0.05:
        out.append("%s%-*s %+5.1f" % (" " * 4, 26, "Rain along the sun line", -bd["rain_loss"]))
    out.append("%s%-*s %5.1f" % (" " * 4, 26, "Total", bd["total"]))
    short = [(reg["max"] - reg["earned"], REGION_NAMES[n]) for n, reg in bd["regions"].items()]
    short += [(bd["cloud_loss"], "sun hidden by cloud"), (bd["rain_loss"], "rain")]
    short = sorted((s_ for s_ in short if s_[0] >= 1.0), reverse=True)[:3]
    if short:
        out.append("    Biggest shortfalls: " + ", ".join("%s (-%.1f)" % (n, v) for v, n in short))
    return out


def format_report(res, brief=False):
    t = res["sunset_local"]
    abbr = "EDT" if t.utcoffset() == datetime.timedelta(hours=-4) else "EST"
    mid = res["mid_hour"]
    out = [
        "Sunset Score for %.4f, %.4f on %s" % (res["lat"], res["lon"], res["date"]),
        "Sunset %s %s, direction %.1f degrees; observer elevation %d m"
        % (t.strftime("%H:%M"), abbr, res["azimuth"], round(res["elevation_m"])),
        "Hours averaged: %s" % " ".join(str(h) for h in res["hours"]),
        "",
        "SCORE: %d / 100   (range %d to %d, confidence %.2f)  -- %s"
        % (res["score"], res["low"], res["high"], res["confidence"], verdict(res["score"])),
        "  gate %.2f   decoration %.2f   [sunset direction %.2f, overhead %.2f, opposite sky %.2f]"
        % (mid["gate"], mid["decoration"], mid["regions"]["fwd"],
           mid["regions"]["over"], mid["regions"]["anti"]),
        "",
    ]
    out += ["  " + line for line in explain(res)]
    if res.get("breakdown") and not brief:
        out += [""] + breakdown_lines(res["breakdown"])
    if res.get("source") == "NOAA GFS":
        out += ["", "Forecast: NOAA GFS 0.25 degree, via UCAR Unidata THREDDS"
                + (" (cloud cover with base and top heights)" if res.get("cube") else "")]
    else:
        out += ["", "Weather data by Open-Meteo.com"]
    return "\n".join(out)


def _ask(prompt):
    value = input(prompt)
    print(value)                       # echo, like the course homeworks
    return value.strip()


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    use_sat = "--no-sat" not in argv
    mask_dir = None if "--no-masks" in argv else os.getcwd()
    ground = "--no-ground" not in argv
    source = "openmeteo" if "--openmeteo" in argv else None
    brief = "--brief" in argv
    argv = [a for a in argv if a not in ("--no-sat", "--openmeteo", "--brief", "--no-masks", "--no-ground")]
    try:
        if len(argv) >= 3:
            lat, lon, date_str = float(argv[0]), float(argv[1]), argv[2]
        else:
            lat = float(_ask("Enter latitude ==> "))
            lon = float(_ask("Enter longitude ==> "))
            date_str = _ask("Enter date (YYYY-MM-DD) ==> ")
        datetime.date.fromisoformat(date_str)
        if not (math.isfinite(lat) and math.isfinite(lon) and -90 < lat < 90 and -180 <= lon <= 180):
            raise ValueError("latitude/longitude out of range")
    except ValueError as err:
        print("Could not read the input (%s). Use e.g.: 41.4278 -74.1654 2026-11-06" % err)
        return 2
    if not (40.4 <= lat <= 45.1 and -79.9 <= lon <= -71.7):
        print("Note: v1.1 assumes New York (Eastern time); results elsewhere will be off.")
    print()
    try:
        res = run(lat, lon, date_str, use_sat=use_sat, source=source, mask_dir=mask_dir, ground_view=ground)
    except (RuntimeError, ValueError) as err:
        print("Could not compute a score: %s" % err)
        return 1
    print(format_report(res, brief))
    return 0


if __name__ == "__main__":
    sys.exit(main())
