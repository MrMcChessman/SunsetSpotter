import datetime
import math
import os
import shutil
import sys
import tempfile
import unittest
from zoneinfo import ZoneInfo

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np

import mocks
import sunset_v1_1 as s

TROY = (42.7284, -73.6918)
WASH = (41.4278, -74.1654)          # Washingtonville, NY (approx.)
UTC = datetime.timezone.utc


def uniform(v):
    return [[v] * s.SIZE for _ in range(s.SIZE)]


def checker():
    return [[1.0 if (r + c) % 2 == 0 else 0.0 for c in range(s.SIZE)] for r in range(s.SIZE)]


def fake_sky(low=None, mid=None, high=None, precip=None):
    z = uniform(0.0)
    return {"low": low or z, "mid": mid or z, "high": high or z, "precip": precip or z}


# ============================================================ sun geometry
class TestSun(unittest.TestCase):
    def test_azimuth_handout_values(self):
        for (m, d), want in (((11, 7), 246.5), ((3, 20), 268.8), ((6, 21), 302.8), ((12, 21), 237.2)):
            self.assertAlmostEqual(s.sunset_azimuth(42.7284, 2026, m, d), want, delta=0.06)

    def test_azimuth_vs_astral_within_2_5_degrees(self):
        from astral import LocationInfo
        from astral.sun import azimuth, sun
        loc = LocationInfo("t", "US", "America/New_York", *TROY)
        worst = 0.0
        for doy in range(1, 366, 7):
            day = datetime.date(2026, 1, 1) + datetime.timedelta(days=doy - 1)
            ss = sun(loc.observer, date=day, tzinfo=ZoneInfo("America/New_York"))["sunset"]
            worst = max(worst, abs(azimuth(loc.observer, ss) - s.sunset_azimuth(42.7284, day.year, day.month, day.day)))
        self.assertLess(worst, 2.5)

    def test_azimuth_polar_clamp_does_not_crash(self):
        self.assertTrue(0 <= s.sunset_azimuth(89.0, 2026, 6, 21) <= 360)

    def test_sunset_time_vs_astral_all_year(self):
        from astral import LocationInfo

        from astral.sun import sunset
        worst = 0.0
        for name, place in (("troy", TROY), ("wash", WASH)):
            loc = LocationInfo(name, "US", "America/New_York", *place)
            for doy in range(1, 366, 3):
                day = datetime.date(2026, 1, 1) + datetime.timedelta(days=doy - 1)
                want = sunset(loc.observer, date=day, tzinfo=ZoneInfo("America/New_York"))
                got = s.sunset_time_utc(place[0], place[1], day)
                worst = max(worst, abs((want - got).total_seconds()) / 60.0)
        self.assertLess(worst, 1.0, "sunset time off by %.2f min" % worst)

    def test_troy_nov7_sunset_is_1639(self):
        local, _ = s.sunset_local(TROY[0], TROY[1], datetime.date(2026, 11, 7))
        self.assertEqual(local.strftime("%H:%M"), "16:39")

    def test_eastern_offset_matches_zoneinfo(self):
        tz = ZoneInfo("America/New_York")
        day = datetime.date(2024, 1, 1)
        while day < datetime.date(2031, 1, 1):
            dt = datetime.datetime(day.year, day.month, day.day, 17, 0, tzinfo=tz)
            self.assertEqual(s.eastern_utc_offset_hours(day), dt.utcoffset().total_seconds() / 3600, day)
            day += datetime.timedelta(days=1)

    def test_sunset_hours(self):
        t = datetime.datetime(2026, 11, 7, 16, 39)
        self.assertEqual(s.sunset_hours(t), [16, 17, 18])
        self.assertEqual(s.sunset_hours(t.replace(hour=20, minute=10)), [19, 20, 21])
        self.assertEqual(s.sunset_hours(t.replace(hour=23, minute=40)), [23])   # clipped, no hour 24


# ===================================================== flat map + radii
class TestGeometry(unittest.TestCase):
    def test_offset_values(self):
        lat, lon = s.offset_point(*TROY, 270, 100)
        self.assertAlmostEqual(lat, 42.7284, places=4)
        self.assertAlmostEqual(lon, -74.91822, places=4)
        self.assertEqual(s.offset_point(*TROY, 0, 111)[0], 43.7284)

    def test_grid_orientation_matches_independent_geometry(self):
        pts = s.grid_points(*WASH)
        self.assertEqual(len(pts), 961)
        for (r, c), want_b, want_d in (((0, 15), 0, 450), ((30, 15), 180, 450),
                                       ((15, 30), 90, 450), ((15, 0), 270, 450),
                                       ((0, 30), 45, 636.4), ((30, 0), 225, 636.4)):
            b, d = mocks.bearing_dist_km(*WASH, *pts[r * s.SIZE + c])
            # far corners: true (great-circle) bearings drift from the flat grid by
            # meridian convergence, up to ~3 deg at 640 km -- expected, documented
            self.assertLess(mocks.angdiff(b, want_b), 2.5 if want_d == 450 else 3.5, (r, c))
            self.assertAlmostEqual(d, want_d, delta=want_d * (0.012 if want_d == 450 else 0.02))
        self.assertEqual(pts[15 * 31 + 15], WASH)

    def test_flat_map_error_is_small(self):
        for bearing in (0, 90, 246.5, 300):
            for dist in (120, 210, 390):
                p = s.offset_point(*TROY, bearing, dist)
                b, d = mocks.bearing_dist_km(*TROY, *p)
                self.assertLess(abs(d - dist) / dist, 0.012)
                self.assertLess(mocks.angdiff(b, bearing), 2.0)

    def test_radius_table(self):
        for h, sea, hill in ((1000, 123.3, 190.9), (3000, 213.6, 281.2), (10000, 390.0, 457.5)):
            self.assertAlmostEqual(s.visibility_radius(h, 0), sea, places=1)
            self.assertAlmostEqual(s.visibility_radius(h, 300), hill, places=1)


# ================================================================ regions
class TestRegions(unittest.TestCase):
    az = s.sunset_azimuth(42.7284, 2026, 11, 7)

    def test_wedge_sizes(self):
        self.assertEqual([len(s.wedge_cells(self.az, r)) for r in (123.3, 213.6, 390.0)], [3, 12, 43])
        self.assertEqual(len(s.disc_cells()), 9)

    def test_wedge_points_the_right_way(self):
        # every cell of a due-west wedge is in the western half of the grid
        for r, c in s.wedge_cells(270.0, 300):
            self.assertLess(c, s.N)
        for r, c in s.wedge_cells(0.0, 300):      # due north: row index smaller
            self.assertLess(r, s.N)
        for r, c in s.wedge_cells(355.0, 300):    # wrap-around across 0/360
            self.assertLess(r, s.N)
        self.assertTrue(s.wedge_cells(355.0, 300) & s.wedge_cells(5.0, 300))

    def test_bilinear(self):
        g = [[0, 1], [2, 3]]
        self.assertEqual(s.bilinear(g, 0.5, 0.5), 1.5)
        self.assertEqual(s.bilinear(g, 0, 1), 1)
        self.assertEqual(s.bilinear(g, 1, 0.25), 2.25)
        self.assertEqual(s.bilinear(g, 1, 1), 3)
        self.assertIsNone(s.bilinear(g, -0.01, 0.5))
        self.assertIsNone(s.bilinear(g, 0.5, 1.01))

    def test_ray_counts(self):
        self.assertEqual(len(s.ray_offsets(self.az, 123.3)), 36)
        self.assertEqual(len(s.ray_offsets(self.az, 190.9)), 57)
        self.assertEqual(len(s.ray_offsets(self.az, 120.0)), 36)     # exactly on a step

    def test_ray_mean_is_directional(self):
        west = [[1.0 if c < s.N else 0.0 for c in range(s.SIZE)] for r in range(s.SIZE)]
        offs = s.ray_offsets(270.0, 120)
        self.assertGreater(s.ray_mean(west, offs)[0], 0.9)
        offs_e = s.ray_offsets(90.0, 120)
        self.assertLess(s.ray_mean(west, offs_e)[0], 0.1)

    def test_ray_mean_skips_off_grid_points(self):
        mean, n = s.ray_mean(uniform(1.0), s.ray_offsets(270.0, 900))
        self.assertEqual(mean, 1.0)
        self.assertLess(n, len(s.ray_offsets(270.0, 900)))


# ======================================================= gate and dapple
class TestScoring(unittest.TestCase):
    az = s.sunset_azimuth(42.7284, 2026, 11, 7)

    def test_gate(self):
        # hidden share -> gate: log-shaped, 0 only when wholly hidden, full at half the disc out
        for c, want in ((0.0, 1.0), (0.2, 1.0), (0.5, 1.0), (0.57, 0.9383), (0.7, 0.7927),
                        (0.8, 0.6327), (0.9, 0.3738), (0.95, 0.1437), (0.97, 0.0), (0.99, 0.0), (1.0, 0.0)):
            self.assertAlmostEqual(s.gate_value(c), want, places=3)
        self.assertAlmostEqual(s.gate_value(0.5, 1.0), 0.25)
        self.assertAlmostEqual(s.gate_value(0.5, 0.5), 1.0)          # at the limit is not rain
        self.assertEqual(s.gate_value(1.5), 0.0)                      # out-of-range input is clamped
        self.assertEqual(s.gate_value(-0.3), 1.0)

    def test_gate_is_lenient_and_monotone(self):
        grid = [i / 100.0 for i in range(0, 101)]
        vals = [s.gate_value(b) for b in grid]
        self.assertTrue(all(a >= b - 1e-12 for a, b in zip(vals, vals[1:])))        # more hidden never helps
        lo, hi = s.GATE_SHUT, 1.0 - s.GATE_OPEN
        for b in grid:                                    # never below the straight line from (SHUT, 0) to (full, 1)
            seen = 1.0 - b
            line = max(0.0, min(1.0, (seen - lo) / (hi - lo)))
            self.assertGreaterEqual(s.gate_value(b), line - 1e-9)
        self.assertGreater(s.gate_value(0.95), 0.1)                   # 5% of the sun showing still earns credit
        self.assertAlmostEqual(s.gate_value(1.0 - s.GATE_SHUT), 0.0)  # but "wholly hidden" is zero

    def test_cover_gate_keeps_the_v1_ramp(self):
        # plain cloud-cover fractions (no-cube fallback, satellite pixels) are not a hidden share
        for c, want in ((0.2, 1.0), (0.5, 1.0), (0.7, 0.5), (0.9, 0.0), (0.95, 0.0)):
            self.assertAlmostEqual(s.cover_gate(c), want)
        self.assertAlmostEqual(s.cover_gate(0.5, 1.0), 0.25)
        self.assertAlmostEqual(s.cover_gate(0.5, 0.5), 1.0)          # at the limit is not rain

    def test_sweet_spot(self):
        self.assertEqual([round(s.sweet_spot(c), 3) for c in (0, 1 / 6, 0.5, 5 / 6, 1)], [0, 0.5, 1, 0.5, 0])

    def test_texture_handout_values(self):
        all3 = {(r, c) for r in range(3) for c in range(3)}
        all5 = {(r, c) for r in range(5) for c in range(5)}
        self.assertEqual(s.texture([[1, 1, 1]] * 3, all3, 1), 0.0)
        self.assertEqual(s.texture([[1, 0, 1], [0, 1, 0], [1, 0, 1]], all3, 1), 1.0)
        self.assertAlmostEqual(s.texture([[1, 1, 0], [0, 0, 0], [0, 0, 0]], all3, 1), 0.5833, places=4)
        f = [[1, 1, 0, 0, 1], [0, 0, 0, 1, 1], [1, 0, 0, 0, 0], [0, 1, 1, 0, 0], [0, 0, 0, 0, 1]]
        self.assertAlmostEqual(s.texture(f, all5, 1), 0.6944, places=4)
        self.assertAlmostEqual(s.texture(f, all5, 2), 0.9074, places=4)
        self.assertAlmostEqual(s.dapple(f, all5), 0.8009, places=4)

    def test_texture_edge_cases(self):
        self.assertEqual(s.texture(uniform(0.0), {(1, 1), (1, 2)}, 1), 0.0)       # no cloud
        self.assertIsNone(s.texture(uniform(1.0), {(5, 5)}, 1))                    # no neighbours
        self.assertEqual(s.dapple(uniform(1.0), {(5, 5)}), 0.5)                    # undefined -> neutral
        self.assertEqual(s.layer_decoration(uniform(1.0), set()), 0.0)

    def test_sky_weights_favour_near_cells(self):
        near, far = (s.N, s.N + 2), (s.N, s.N + 12)            # 60 km and 360 km east
        w = s.sky_weights({near, far}, 9000.0)
        self.assertGreater(w[near], 20 * w[far])                # near cloud fills far more sky
        w_low = s.sky_weights({near, far}, 1000.0)
        self.assertGreater(w_low[near] / w_low[far], w[near] / w[far])   # lower cloud: steeper

    def test_weighted_cover_is_the_share_of_sky(self):
        near, far = (s.N, s.N + 2), (s.N, s.N + 12)
        grid = uniform(0.0)
        grid[near[0]][near[1]] = 1.0                            # only the near cell is cloudy
        cells = {near, far}
        self.assertAlmostEqual(s.mean_coverage(grid, cells), 0.5)
        self.assertGreater(s.mean_coverage(grid, cells, s.sky_weights(cells, 9000.0)), 0.95)
        self.assertEqual(s.mean_coverage(grid, set(), {}), 0.0)

    def test_fake_sky_table(self):
        east = [[1.0 if c > s.N else 0.0 for c in range(s.SIZE)] for r in range(s.SIZE)]
        west = [[1.0 if c < s.N else 0.0 for c in range(s.SIZE)] for r in range(s.SIZE)]
        table = (("clear", fake_sky(), 25), ("overcast", fake_sky(low=uniform(1.0)), 0),
                 ("rain", fake_sky(precip=uniform(2.0)), 6), ("high solid", fake_sky(high=uniform(1.0)), 25),
                 ("high half", fake_sky(high=uniform(0.5)), 44), ("high checker", fake_sky(high=checker()), 54),
                 ("low east only", fake_sky(low=east), 26), ("low west only", fake_sky(low=west), 0))
        for name, sky, want in table:
            self.assertEqual(s.score_hour(sky, self.az)["score"], want, name)

    def test_score_is_bounded_and_monotone_in_gate(self):
        best = s.score_hour(fake_sky(high=checker(), mid=checker()), self.az)["score"]
        self.assertTrue(0 <= best <= 100)
        # once low cloud is thick enough to start closing the gate, more of it
        # can only lower the score (below that it also acts as decoration)
        prev = 101
        for v in (0.6, 0.7, 0.8, 0.9, 1.0):
            sc = s.score_hour(fake_sky(low=uniform(v), high=checker()), self.az)["score"]
            self.assertLessEqual(sc, prev)
            prev = sc

    def test_elevation_widens_view(self):
        # a distant low bank (visible only from a hill) gates the sun for the hill-top
        bank = [[1.0 if (math.hypot((c - s.N) * 30, (s.N - r) * 30) >= 150) else 0.0
                 for c in range(s.SIZE)] for r in range(s.SIZE)]
        valley = s.score_hour(fake_sky(low=bank), self.az, elev_m=0.0)
        hill = s.score_hour(fake_sky(low=bank), self.az, elev_m=300.0)
        self.assertLess(valley["low_mean"], 0.01)   # bank is beyond the valley's 123 km radius (tiny interpolation leak only)
        self.assertGreater(hill["low_mean"], 0.1)   # ... but inside the hill-top's 191 km

    def test_confidence(self):
        self.assertAlmostEqual(s.confidence(9, 0), 0.5)
        self.assertEqual(s.confidence(0, 0), 1.0)
        self.assertEqual(s.confidence(-3, 0), 1.0)
        self.assertEqual(s.confidence(30, 0), 0.2)
        self.assertAlmostEqual(s.confidence(3, 0.8), 0.6333, places=3)
        self.assertEqual(s.confidence(30, 0.8), 0.1)

    def test_score_range(self):
        sky = {16: fake_sky(), 17: fake_sky(low=uniform(1.0)), 18: fake_sky(high=uniform(0.5))}
        mean, lo, hi, per = s.score_range(sky, [16, 17, 18], self.az)
        self.assertEqual((lo, hi), (0, 44))
        self.assertEqual(mean, round((25 + 0 + 44) / 3))


# ================================================== Open-Meteo plumbing
class TestOpenMeteo(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_url(self):
        url = s.open_meteo_url([(41.4278, -74.1654), (41.5, -74.2)], "2026-11-06", today=datetime.date(2026, 11, 7))
        self.assertTrue(url.startswith(s.FORECAST_URL))
        self.assertIn("latitude=41.4278,41.5000&longitude=-74.1654,-74.2000", url)
        self.assertIn("start_date=2026-11-06&end_date=2026-11-06", url)
        old = s.open_meteo_url([(41.4, -74.1)], "2026-01-06", today=datetime.date(2026, 11, 7))
        self.assertTrue(old.startswith(s.HISTORICAL_URL))

    def test_chunking_order_and_cache(self):
        mock = mocks.MockOpenMeteo(WASH, mocks.bank_at(270, half=60, layer="low"))
        sky, elev = s.fetch_sky(*WASH, "2026-11-06", [16, 17, 18], self.tmp, mock, today=datetime.date(2026, 11, 7), log=lambda *a: None)
        self.assertEqual(len(mock.calls), 10)                  # 961 places, 100 at a time
        self.assertEqual(elev[15][15], 140.0)
        # order check: western cells (low column index) hold the low-cloud bank, eastern do not
        west_cell = sky[17]["low"][15][3]
        east_cell = sky[17]["low"][15][27]
        self.assertEqual((west_cell, east_cell), (1.0, 0.0))
        north_cell, south_cell = sky[17]["low"][2][15], sky[17]["low"][28][15]
        self.assertEqual((north_cell, south_cell), (0.0, 0.0))
        # second run must come from the cache, with zero network calls
        mock2 = mocks.MockOpenMeteo(WASH, mocks.clear_sky)
        s.fetch_sky(*WASH, "2026-11-06", [16, 17, 18], self.tmp, mock2, log=lambda *a: None)
        self.assertEqual(mock2.calls, [])

    def test_null_values_become_zero(self):
        mock = mocks.MockOpenMeteo(WASH, mocks.bank_at(270, half=180, far=2000, layer="mid"))
        mock.drop_values = True
        sky, _ = s.fetch_sky(*WASH, "2026-11-06", [16, 17], self.tmp, mock, log=lambda *a: None)
        self.assertEqual(sky[16]["mid"][5][5], 0.0)
        self.assertEqual(sky[17]["mid"][5][5], 1.0)

    def test_single_place_dict_is_wrapped(self):
        resp = mocks.MockOpenMeteo(WASH, mocks.clear_sky)(s.open_meteo_url([WASH], "2026-11-06"))
        self.assertIsInstance(resp, dict)
        calls = []

        def one_at_a_time(url):
            calls.append(1)
            data = mocks.MockOpenMeteo(WASH, mocks.clear_sky)(url)
            return data
        s.CHUNK, old = 1, s.CHUNK
        try:
            # a chunk of one place returns a bare dict: fetch_sky must cope
            sky, elev = s.fetch_sky(*WASH, "2026-11-06", [17], self.tmp, one_at_a_time, log=lambda *a: None)
        finally:
            s.CHUNK = old
        self.assertEqual(len(calls), 961)

    def test_wrong_place_count_is_an_error(self):
        def short(url):
            return mocks.MockOpenMeteo(WASH, mocks.clear_sky)(url)[:-1]
        with self.assertRaises(RuntimeError):
            s.fetch_sky(*WASH, "2026-11-06", [17], self.tmp, short, log=lambda *a: None)
        self.assertEqual(os.listdir(self.tmp), [])             # nothing half-cached

    def test_hour_index_on_dst_day(self):
        times = ["2026-11-01T%02d:00" % h for h in range(2)] + ["2026-11-01T%02d:00" % h for h in range(1, 24)]
        self.assertEqual(len(times), 25)                         # 1 AM appears twice
        self.assertEqual(s.hour_index(times, 1), 1)              # first 1 AM
        self.assertEqual(s.hour_index(times, 5), 6)              # later hours are shifted
        with self.assertRaises(ValueError):
            s.hour_index(["2026-11-01T00:00"], 5)


# ============================================================== GOES
class TestGoes(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.az = s.sunset_azimuth(*WASH[:1], 2026, 11, 6)
        cls.when = datetime.datetime(2026, 11, 6, 21, 40, tzinfo=UTC)   # ~4:40 PM EST

        def pattern(kind):
            def f(b, d):
                acm = np.zeros(b.shape)
                ht = np.full(b.shape, np.nan)
                sun = (np.abs((b - cls.az + 180) % 360 - 180) <= 14) & (d > 5) & (d <= 125)
                if kind == "bank":
                    acm[sun], ht[sun] = 3, 800.0
                elif kind == "cirrus":
                    acm[sun], ht[sun] = 3, 9500.0
                elif kind == "unknown_ht":
                    acm[sun] = 3
                return acm, ht
            return f
        cls.fields = {k: mocks.goes_field(WASH, cls.az, pattern(k)) for k in ("clear", "bank", "cirrus", "unknown_ht")}

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def goes(self, kind, mask_var="ACM"):
        d = tempfile.mkdtemp(dir=self.tmp)
        decoy = self.fields["bank"] if kind != "bank" else self.fields["clear"]
        scans = {(21, 31): decoy, (21, 36): self.fields[kind], (21, 46): decoy}   # 21:46 is after `when`
        return mocks.MockGoes(d, WASH, scans, mask_var=mask_var), d

    def check(self, kind, **kw):
        g, d = self.goes(kind, **kw)
        out = s.satellite_check(*WASH, self.az, s.visibility_radius(1000, 140), self.when,
                                os.path.join(d, "cache"), g.get_text, g.get_file, log=lambda *a: None)
        return out, g

    def full_run(self, kind, forecast):
        g, d = self.goes(kind)
        mock = mocks.MockOpenMeteo(WASH, forecast)
        res = s.run(*WASH, "2026-11-06", now_utc=datetime.datetime(2026, 11, 7, 18, 0, tzinfo=UTC),
                    cache_dir=os.path.join(d, "cache"), use_sat=True, fetch_json=mock,
                    goes_get_text=g.get_text, goes_get_file=g.get_file, log=lambda *a: None)
        return res

    def test_run_satellite_agrees_with_clear_forecast(self):
        res = self.full_run("clear", mocks.clear_sky)
        self.assertIsNotNone(res["satellite"])
        self.assertAlmostEqual(res["satellite"]["gate"], 1.0)
        self.assertEqual(res["confidence"], 1.0)             # event is already over
        self.assertIn("agrees with the forecast", s.format_report(res))

    def test_run_satellite_disagrees_and_lowers_confidence(self):
        res = self.full_run("bank", mocks.clear_sky)         # forecast says clear, satellite sees a bank
        # the mock bank fills 5-125 km of the ~170 km ray (about 73% low cloud)
        self.assertAlmostEqual(res["satellite"]["low_fraction"], 0.26, delta=0.05)   # of the whole 450 km sight line
        self.assertGreater(res["satellite"]["block"], 0.9)    # a low bank on the sun line hides the sun
        self.assertLess(res["satellite"]["gate"], 0.5)
        self.assertAlmostEqual(res["confidence"], 0.8)
        self.assertIn("DISAGREES with the forecast", s.format_report(res))
        # the satellite pulls the gate halfway (SAT_GATE_MAX_W x potency ~1) toward its own 0: 25 -> ~13
        self.assertAlmostEqual(res["score"], 13, delta=1)
        self.assertEqual(res["mid_hour"]["gate_forecast"], 1.0)

    def test_run_high_cirrus_in_satellite_does_not_block_the_sun(self):
        res = self.full_run("cirrus", mocks.clear_sky)
        self.assertAlmostEqual(res["satellite"]["gate"], 1.0)

    def test_sat_sight_block_geometry(self):
        ray = lambda top, d0, d1: [(float(d), top) for d in range(10, 451, 10)]
        clear = [(float(d), None) for d in range(10, 451, 10)]
        self.assertEqual(s.sat_sight_block([clear]), 0.0)
        # a low deck (top 2 km) out to 160 km fills the sun line: the sun is hidden
        near = [(float(d), 2000.0 if d <= 160 else None) for d in range(10, 451, 10)]
        self.assertGreater(s.sat_sight_block([near]), 0.95)
        # the same deck 300 km out sits below the sun line (earth's curvature): no block
        far = [(float(d), 2000.0 if 280 <= d <= 320 else None) for d in range(10, 451, 10)]
        self.assertEqual(s.sat_sight_block([far]), 0.0)
        # a mid deck (top 6 km) reaches the sun line at 250-330 km
        mid = [(float(d), 6000.0 if 250 <= d <= 330 else None) for d in range(10, 451, 10)]
        self.assertGreater(s.sat_sight_block([mid]), 0.5)
        # cirrus (top 10.5 km) overhead-ish does not block; its far edge only dims
        hi = [(float(d), 10500.0 if d <= 300 else None) for d in range(10, 451, 10)]
        self.assertEqual(s.sat_sight_block([hi]), 0.0)
        self.assertEqual(s.sat_sight_block([]), 0.0)

    def test_scan_angles_match_pyproj(self):
        from pyproj import Proj
        geom = {"h": mocks.H_SAT, "req": mocks.REQ, "rpol": mocks.RPOL, "lon0": -75.0}
        p = Proj(proj="geos", h=mocks.H_SAT, lon_0=-75.0, sweep="x", a=mocks.REQ, b=mocks.RPOL)
        for lat, lon in (TROY, WASH, (44.9, -73.4), (40.7, -79.5)):
            x, y = s.latlon_to_scan(lat, lon, geom)
            X, Y = p(lon, lat)
            self.assertAlmostEqual(x, X / mocks.H_SAT, places=9)
            self.assertAlmostEqual(y, Y / mocks.H_SAT, places=9)
        x, y = s.latlon_to_scan(*TROY, geom)
        self.assertAlmostEqual(x, 0.002840, places=6)
        self.assertAlmostEqual(y, 0.114392, places=6)

    def test_pixel_lookup_lands_on_the_right_ground_point(self):
        g, d = self.goes("clear")
        path = os.path.join(d, "x.nc")
        mocks.write_goes_file(path, "ABI-L2-ACMC", acm=self.fields["clear"][0])
        ds, geom, np_ = s._open_dataset(path)
        lat_g, lon_g = mocks.pixel_latlon()
        for lat, lon in (WASH, TROY, (43.5, -75.5), (41.0, -73.0)):
            x, y = s.latlon_to_scan(lat, lon, geom)
            i = round((x - geom["x0"]) / geom["dx"]); j = round((y - geom["y0"]) / geom["dy"])
            b, dist = mocks.bearing_dist_km(lat, lon, lat_g[j, i], lon_g[j, i])
            self.assertLess(dist, 2.0, "pixel centre %.2f km from the target" % dist)
        self.assertIsNone(s.goes_pixel(ds, geom, np_, 20.0, -150.0, "ACM"))        # off the scan
        ds.close()

    def test_clear_sky_opens_gate(self):
        out, g = self.check("clear")
        self.assertEqual(out["low_fraction"], 0.0)
        self.assertEqual(out["gate"], 1.0)
        self.assertEqual(out["valid"], out["total"])

    def test_low_bank_closes_gate(self):
        out, g = self.check("bank")
        self.assertGreater(out["low_fraction"], 0.55)
        self.assertLess(out["gate"], 0.5)

    def test_high_cirrus_is_not_low_cloud(self):
        out, g = self.check("cirrus")
        self.assertEqual(out["low_fraction"], 0.0)
        self.assertEqual(out["gate"], 1.0)

    def test_unknown_height_pixels_are_skipped_not_counted(self):
        out, g = self.check("unknown_ht")
        self.assertLess(out["valid"], out["total"])           # cloudy pixels with no height dropped
        self.assertEqual(out["low_fraction"], 0.0)

    def test_scan_selection_and_both_products_fetched(self):
        out, g = self.check("bank")
        self.assertEqual(out["scan_utc"], datetime.datetime(2026, 11, 6, 21, 36, 17, tzinfo=UTC))
        self.assertEqual(sorted(k.split("/")[0] for k in g.fetched), ["ABI-L2-ACHAC", "ABI-L2-ACMC"])
        self.assertTrue(all("G19" in k and "_s2026310213617" in k for k in g.fetched))   # doy 310, 21:36

    def test_scan_from_previous_hour_when_this_hour_is_empty(self):
        g, d = self.goes("clear")
        early = datetime.datetime(2026, 11, 6, 22, 0, 30, tzinfo=UTC)        # nothing yet in hour 22
        key = s.goes_scan_key("ABI-L2-ACMC", early, g.get_text)
        self.assertIn("/21/", key)
        self.assertTrue(key.endswith(".nc"))
        with self.assertRaises(s.SatelliteUnavailable):
            s.goes_scan_key("ABI-L2-ACMC", datetime.datetime(2026, 11, 6, 3, 0, tzinfo=UTC), g.get_text)

    def test_binary_cloud_mask_variable_fallback(self):
        out, g = self.check("bank", mask_var="BCM")
        self.assertGreater(out["low_fraction"], 0.55)

    def test_download_is_cached(self):
        g, d = self.goes("clear")
        cache = os.path.join(d, "cache")
        for _ in range(2):
            s.satellite_check(*WASH, self.az, 142.0, self.when, cache, g.get_text, g.get_file, log=lambda *a: None)
        self.assertEqual(len(g.fetched), 2)                  # one file per product, not four

    def test_network_failure_becomes_unavailable(self):
        def boom(url, dest):
            raise OSError("connection reset")
        g, d = self.goes("clear")
        with self.assertRaises(s.SatelliteUnavailable):
            s.satellite_check(*WASH, self.az, 142.0, self.when, os.path.join(d, "c2"), g.get_text, boom, log=lambda *a: None)

    def test_satellite_time_rules(self):
        sunset = datetime.datetime(2026, 11, 6, 21, 40, tzinfo=UTC)
        h = datetime.timedelta
        self.assertEqual(s.satellite_time(sunset + h(days=1), sunset), sunset)           # past: at sunset
        self.assertEqual(s.satellite_time(sunset + h(minutes=1), sunset), sunset)
        self.assertEqual(s.satellite_time(sunset - h(hours=2), sunset), sunset - h(hours=2))
        self.assertIsNone(s.satellite_time(sunset - h(hours=3, minutes=1), sunset))


# ======================================================= whole program
class TestEndToEnd(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def run_case(self, scenario, center=WASH, day="2026-11-06", now=None, **kw):
        mock = mocks.MockOpenMeteo(center, scenario, day=day)
        now = now or datetime.datetime(2026, 11, 7, 18, 0, tzinfo=UTC)       # the next day
        return s.run(center[0], center[1], day, now_utc=now, cache_dir=self.tmp,
                     use_sat=False, fetch_json=mock, log=lambda *a: None, **kw)

    def test_stratus_deck_means_no_sunset(self):
        res = self.run_case(mocks.stratus_everywhere)
        self.assertEqual(res["score"], 0)
        self.assertIn("blocked", " ".join(s.explain(res)))

    def test_clear_sky_is_plain(self):
        res = self.run_case(mocks.clear_sky)
        self.assertEqual((res["score"], res["low"], res["high"]), (25, 25, 25))
        self.assertIn("plain sunset", " ".join(s.explain(res)))

    def test_bank_toward_the_sun_vs_behind_you(self):
        az = s.sunset_azimuth(WASH[0], 2026, 11, 6)
        toward = self.run_case(mocks.bank_at(az, half=25, far=400))
        shutil.rmtree(self.tmp); os.makedirs(self.tmp)
        behind = self.run_case(mocks.bank_at((az + 180) % 360, half=25, far=400))
        shutil.rmtree(self.tmp); os.makedirs(self.tmp)
        partial = self.run_case(mocks.bank_at(az, half=25, far=110))   # covers ~60% of the sight line
        self.assertEqual(toward["score"], 0)
        self.assertGreaterEqual(behind["score"], 25)
        self.assertEqual(behind["mid_hour"]["gate"], 1.0)
        self.assertTrue(0.0 < partial["mid_hour"]["gate"] < 1.0)

    def test_dappled_beats_solid_with_same_coverage(self):
        az = s.sunset_azimuth(WASH[0], 2026, 11, 6)
        dap = self.run_case(mocks.dappled_west(az))
        shutil.rmtree(self.tmp); os.makedirs(self.tmp)
        sol = self.run_case(mocks.solid_west(az))
        self.assertGreater(dap["score"], sol["score"])
        self.assertGreater(dap["score"], 55)

    def test_confidence_for_forecast_vs_past(self):
        future = datetime.datetime(2026, 11, 6, 11, 0, tzinfo=UTC)           # 6 AM EST, ~10.7 h ahead
        res = self.run_case(mocks.clear_sky, now=future)
        self.assertAlmostEqual(res["confidence"], 1 - res["lead_h"] / 18, places=6)
        self.assertGreater(res["lead_h"], 10)
        shutil.rmtree(self.tmp); os.makedirs(self.tmp)
        past = self.run_case(mocks.clear_sky)
        self.assertEqual(past["confidence"], 1.0)

    def test_report_text(self):
        res = self.run_case(mocks.clear_sky)
        text = s.format_report(res)
        for needle in ("Sunset Score for 41.4278, -74.1654 on 2026-11-06", "EST",
                       "SCORE: 25 / 100", "Weather data by Open-Meteo.com"):
            self.assertIn(needle, text)

    def test_satellite_skipped_when_sunset_is_far_off(self):
        def no_network(*a, **k):
            raise AssertionError("must not touch the satellite bucket")
        mock = mocks.MockOpenMeteo(WASH, mocks.clear_sky)
        res = s.run(*WASH, "2026-11-06", now_utc=datetime.datetime(2026, 11, 6, 11, 0, tzinfo=UTC),
                    cache_dir=self.tmp, use_sat=True, fetch_json=mock, goes_get_text=no_network,
                    goes_get_file=no_network, log=lambda *a: None)
        self.assertIsNone(res["satellite"])
        self.assertIn("more than 3 hours", res["satellite_note"])
        self.assertIn("Satellite check skipped", s.format_report(res))

    def test_satellite_failure_does_not_break_the_score(self):
        def down(*a, **k):
            raise OSError("no route to host")
        mock = mocks.MockOpenMeteo(WASH, mocks.clear_sky)
        res = s.run(*WASH, "2026-11-06", now_utc=datetime.datetime(2026, 11, 7, 12, 0, tzinfo=UTC),
                    cache_dir=self.tmp, use_sat=True, fetch_json=mock, goes_get_text=down,
                    goes_get_file=down, log=lambda *a: None)
        self.assertEqual(res["score"], 25)
        self.assertIsNone(res["satellite"])
        self.assertTrue(res["satellite_note"])

    def test_dst_summer_label(self):
        res = self.run_case(mocks.clear_sky, day="2026-06-21", now=datetime.datetime(2026, 6, 22, 12, 0, tzinfo=UTC))
        self.assertIn("EDT", s.format_report(res))
        self.assertEqual(res["hours"], [20, 21, 22])      # sunset ~20:35 EDT


# ======================================================== command line / text
class TestCommandLine(unittest.TestCase):
    def setUp(self):
        import contextlib
        import io
        self.contextlib, self.io = contextlib, io
        self.old_cwd = os.getcwd()
        self.tmp = tempfile.mkdtemp()
        os.chdir(self.tmp)
        az = s.sunset_azimuth(WASH[0], 2026, 11, 6)
        mock = mocks.MockOpenMeteo(WASH, mocks.dappled_west(az))
        s.fetch_sky(*WASH, "2026-11-06", [16, 17, 18], "cache", mock, None, lambda *a: None)
        self.real_get = s.http_get_json

    def tearDown(self):
        s.http_get_json = self.real_get
        os.chdir(self.old_cwd)
        shutil.rmtree(self.tmp, ignore_errors=True)

    def call(self, argv, stdin=""):
        out = self.io.StringIO()
        old_in = sys.stdin
        sys.stdin = self.io.StringIO(stdin)
        try:
            with self.contextlib.redirect_stdout(out):
                code = s.main(argv)
        finally:
            sys.stdin = old_in
        return code, out.getvalue()

    def test_arguments_with_cached_forecast(self):
        code, text = self.call(["41.4278", "-74.1654", "2026-11-06", "--no-sat"])
        self.assertEqual(code, 0)
        self.assertIn("SCORE: 73 / 100", text)
        self.assertIn("Sunset 16:45 EST", text)
        self.assertIn("Weather data by Open-Meteo.com", text)

    def test_prompts_echo_the_input(self):
        code, text = self.call(["--no-sat"], "41.4278\n-74.1654\n2026-11-06\n")
        self.assertEqual(code, 0)
        self.assertIn("Enter latitude ==> 41.4278", text)
        self.assertIn("SCORE: 73 / 100", text)

    def test_bad_input_is_reported_not_crashed(self):
        for argv in (["abc", "1", "2026-11-06"], ["41.4", "-74.1", "2026-13-45"],
                     ["95", "-74", "2026-11-06"], ["nan", "-74", "2026-11-06"]):
            code, text = self.call(argv)
            self.assertEqual(code, 2, argv)
            self.assertIn("Could not read the input", text)

    def test_network_failure_is_reported(self):
        def down(url):
            raise RuntimeError("network error for x: down")
        s.http_get_json = down
        code, text = self.call(["41.4278", "-74.1654", "2026-11-07", "--no-sat"])
        self.assertEqual(code, 1)
        self.assertIn("Could not compute a score", text)

    def test_outside_new_york_gets_a_warning(self):
        s.http_get_json = lambda url: (_ for _ in ()).throw(RuntimeError("stop"))
        code, text = self.call(["34.05", "-118.24", "2026-11-06", "--no-sat"])
        self.assertIn("v1.1 assumes New York", text)

    def test_blocked_sun_does_not_talk_about_colour(self):
        mock = mocks.MockOpenMeteo(WASH, mocks.stratus_everywhere)
        res = s.run(*WASH, "2026-11-06", now_utc=datetime.datetime(2026, 11, 6, 20, 0, tzinfo=UTC),
                    cache_dir=os.path.join(self.tmp, "c2"), use_sat=False, fetch_json=mock,
                    log=lambda *a: None)
        text = "\n".join(s.explain(res))
        self.assertEqual(res["score"], 0)
        self.assertIn("blocked", text)
        self.assertNotIn("Most colour should come from", text)
        self.assertNotIn("plain sunset", text)

    def test_long_satellite_note_is_shortened(self):
        res = {"mid_hour": {"gate": 1.0, "low_mean": 0.0, "rain_mean": 0.0, "detail": {}},
               "satellite": None, "satellite_note": "x" * 400}
        line = s.explain(res)[-1]
        self.assertLess(len(line), 160)


# ================================================================ GFS source
class TestGfs(unittest.TestCase):
    NOW = datetime.datetime(2026, 11, 6, 20, 0, tzinfo=UTC)

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def go(self, scenario, ncss=None, **kw):
        ncss = ncss or mocks.MockNcss(WASH, scenario)
        kw.setdefault("gfs_cube", False)               # this class tests the v1 (plain cover) request
        res = s.run(*WASH, "2026-11-06", now_utc=self.NOW, cache_dir=self.tmp, use_sat=False,
                    fetch_file=ncss, log=lambda *a: None, **kw)
        return res, ncss

    def test_url_names_variables_box_and_times(self):
        start = datetime.datetime(2026, 11, 6, 16, 45, tzinfo=UTC)
        url = s.gfs_url(*WASH, start, start + datetime.timedelta(hours=10), cube=False)
        for name in ("Low_cloud_cover_low_cloud", "Medium_cloud_cover_middle_cloud",
                     "High_cloud_cover_high_cloud", "Precipitation_rate_surface"):
            self.assertIn("var=" + name, url)
        self.assertIn("/ncss/grid/grib/NCEP/GFS/Global_0p25deg/Best?", url)
        self.assertIn("time_start=2026-11-06T16:45:00Z", url)
        self.assertNotIn("Precipitation", s.gfs_url(*WASH, start, start, extras=False, cube=False))
        q = dict(p.split("=") for p in url.split("?")[1].split("&") if not p.startswith("var="))
        self.assertGreater(float(q["north"]), WASH[0] + 4.05)       # covers the whole +-450 km grid
        self.assertLess(float(q["west"]), WASH[1] - 5.3)
        self.assertLess(len(url), 600)

    def test_axis_position_works_both_ways(self):
        self.assertAlmostEqual(s._axis_position([46.0, 45.75, 45.5], 45.875), 0.5)
        self.assertAlmostEqual(s._axis_position([280.0, 280.25, 280.5], 280.375), 1.5)
        self.assertEqual(s._axis_position([46.0, 45.75], 50.0), 0.0)
        self.assertEqual(s._axis_position([46.0, 45.75], 40.0), 1.0)

    def test_clear_and_stratus(self):
        res, _ = self.go(mocks.clear_sky)
        self.assertEqual(res["score"], 25)
        self.assertEqual(res["source"], "NOAA GFS")
        self.assertAlmostEqual(res["elevation_m"], 140.0, delta=1.0)
        shutil.rmtree(self.tmp)                       # a fresh download, not the cached clear sky
        res, _ = self.go(mocks.stratus_everywhere)
        self.assertEqual(res["score"], 0)

    def test_matches_open_meteo_path_on_a_smooth_sky(self):
        az = s.sunset_azimuth(WASH[0], 2026, 11, 6)
        sc = mocks.solid_west(az)
        gfs, _ = self.go(sc)
        om = s.run(*WASH, "2026-11-06", now_utc=self.NOW, cache_dir=os.path.join(self.tmp, "om"),
                   use_sat=False, fetch_json=mocks.MockOpenMeteo(WASH, sc), log=lambda *a: None)
        self.assertAlmostEqual(gfs["score"], om["score"], delta=6)

    def test_grid_orientation_is_not_mirrored(self):
        az = s.sunset_azimuth(WASH[0], 2026, 11, 6)
        res, ncss = self.go(mocks.bank_at(az, half=20, near=40, far=400, layer="mid", pct=100))
        sky, _ = s.parse_gfs(os.path.join(self.tmp, [n for n in os.listdir(self.tmp)
                                                       if n.startswith("gfs_")][0]), *WASH,
                             datetime.date(2026, 11, 6), [17])
        mid = sky[17]["mid"]
        west_row = s.N - round(math.cos(math.radians(az)) * 4)      # 4 cells toward the sun
        west_col = s.N + round(math.sin(math.radians(az)) * 4)
        self.assertGreater(mid[west_row][west_col], 0.9)
        self.assertLess(mid[s.N - (west_row - s.N)][s.N - (west_col - s.N)], 0.1)   # opposite side

    def test_times_are_interpolated_between_model_steps(self):
        ramp = lambda b, d, h: {"low": 0, "mid": 0, "high": max(0, min(100, (h - 10) * 10)), "precip": 0.0}
        res, _ = self.go(ramp)
        # model steps at 21Z (16 local) and 00Z (19 local): 60% -> 90%; 17 local = 70%
        self.assertAlmostEqual(res["per_hour"][17]["detail"]["fwd"]["high"][0], 0.70, delta=0.02)

    def test_cache_is_reused_then_refreshed_when_stale(self):
        res, ncss = self.go(mocks.clear_sky)
        self.assertEqual(len(ncss.urls), 1)
        self.go(mocks.clear_sky, ncss=ncss)
        self.assertEqual(len(ncss.urls), 1)                          # fresh: no new download
        path = os.path.join(self.tmp, [n for n in os.listdir(self.tmp) if n.endswith(".nc")][0])
        old = self.NOW.timestamp() - 4 * 3600          # downloaded 4 h before "now"
        os.utime(path, (old, old))
        self.go(mocks.clear_sky, ncss=ncss)
        self.assertEqual(len(ncss.urls), 2)

    def test_server_rejecting_optional_variables_is_survived(self):
        res, ncss = self.go(mocks.clear_sky, ncss=mocks.MockNcss(WASH, mocks.clear_sky, reject_extras=True))
        self.assertEqual(len(ncss.urls), 3)            # full, clouds only, then terrain height alone
        self.assertNotIn("Precipitation", ncss.urls[1])
        self.assertEqual(ncss.urls[2].count("var="), 1)
        self.assertIn("var=Geopotential_height_surface", ncss.urls[2])
        self.assertEqual(res["score"], 25)
        self.assertEqual(res["elevation_m"], 0.0)      # this server refuses terrain height outright

    def test_failure_falls_back_to_open_meteo(self):
        def down(url, dest):
            raise OSError("tunnel failed")
        logs = []
        res = s.run(*WASH, "2026-11-06", now_utc=self.NOW, cache_dir=self.tmp, use_sat=False,
                    fetch_file=down, fetch_json=mocks.MockOpenMeteo(WASH, mocks.clear_sky),
                    log=logs.append)
        self.assertEqual(res["source"], "Open-Meteo")
        self.assertTrue(any("GFS unavailable" in str(x) for x in logs))

    def test_report_credits_the_right_source(self):
        res, _ = self.go(mocks.clear_sky)
        self.assertIn("NOAA GFS", s.format_report(res))
        self.assertNotIn("Open-Meteo", s.format_report(res))
        res["source"] = "Open-Meteo"
        self.assertIn("Open-Meteo.com", s.format_report(res))


# ===================================================== satellite dapple (3 km)
class TestSatelliteDapple(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.az = s.sunset_azimuth(WASH[0], 2026, 11, 6)
        cls.res = {}

        def east_north(b, d):
            return d * np.sin(np.radians(b)), d * np.cos(np.radians(b))

        def make(kind, layer_ht):
            def f(b, d):
                e, n = east_north(b, d)
                inside = (np.abs((b - cls.az + 180) % 360 - 180) <= 40) & (d > 5) & (d <= 420)
                if kind == "solid":
                    cloudy = inside
                elif kind == "stripes":
                    cloudy = inside & (np.floor(e / 9.0).astype(int) % 2 == 0)
                else:                                   # speckle: 4 km cells, pseudo-random
                    ci, cj = np.floor(e / 4.0).astype(int), np.floor(n / 4.0).astype(int)
                    cloudy = inside & (((ci * 73856093) ^ (cj * 19349663)) % 2 == 0)
                acm = np.where(cloudy, 3.0, 0.0)
                ht = np.where(cloudy, layer_ht, np.nan)
                return acm, ht
            return f

        for kind in ("solid", "stripes", "speckle"):
            acm, ht = mocks.goes_field(WASH, cls.az, make(kind, 9500.0))
            mpath, hpath = os.path.join(cls.tmp, kind + "_m.nc"), os.path.join(cls.tmp, kind + "_h.nc")
            mocks.write_goes_file(mpath, "ABI-L2-ACMC", acm=acm)
            mocks.write_goes_file(hpath, "ABI-L2-ACHAC", ht=ht)
            mds, mg, np_ = s._open_dataset(mpath)
            hds, hg, _ = s._open_dataset(hpath)
            cls.res[kind] = s.satellite_dapple(WASH[0], WASH[1], cls.az, 140.0,
                                               mds.variables["ACM"][:], mg, hds.variables["HT"][:],
                                               hg, "ACM", np_)
            mds.close()
            hds.close()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def test_solid_deck_is_smooth(self):
        self.assertLess(self.res["solid"]["fwd"]["high"], 0.08)
        self.assertLess(self.res["solid"]["over"]["high"] or 0.0, 0.15)   # the mock deck's edge is inside the disc

    def test_more_broken_cloud_scores_more_dappled(self):
        solid = self.res["solid"]["fwd"]["high"]
        stripes = self.res["stripes"]["fwd"]["high"]
        speckle = self.res["speckle"]["fwd"]["high"]
        self.assertLess(solid, stripes)
        self.assertLess(stripes, speckle)
        self.assertGreater(speckle, 0.30)

    def test_only_the_layer_that_has_cloud_is_measured(self):
        for kind in ("solid", "stripes", "speckle"):
            fwd = self.res[kind]["fwd"]
            self.assertIsNone(fwd["low"])                  # tops are 9.5 km: no low/mid cloud
            self.assertIsNone(fwd["mid"])
            self.assertIsNotNone(fwd["high"])

    def test_opposite_sky_without_cloud_keeps_the_forecast(self):
        for kind in ("solid", "stripes", "speckle"):
            self.assertIsNone(self.res[kind]["anti"]["high"])   # the mock clouds are only toward the sun

    def test_score_hour_uses_a_measured_dapple(self):
        sky = fake_sky(high=uniform(0.5))
        base = s.score_hour(sky, self.az)["decoration"]
        smooth = s.score_hour(sky, self.az, 0.0, {"fwd": {"high": 0.0}})["decoration"]
        broken = s.score_hour(sky, self.az, 0.0, {"fwd": {"high": 1.0}})["decoration"]
        keep = s.score_hour(sky, self.az, 0.0, {"fwd": {"high": None}})["decoration"]
        self.assertLess(smooth, broken)
        self.assertEqual(keep, base)
        detail = s.score_hour(sky, self.az, 0.0, {"fwd": {"high": 0.7}})["detail"]["fwd"]["high"]
        self.assertAlmostEqual(detail[1], 0.7)

    def test_run_feeds_the_measured_dapple_into_the_score(self):
        scans = {}
        for kind in ("solid", "speckle"):
            d = tempfile.mkdtemp(dir=self.tmp)

            def f(b, dist, kind=kind):
                e, n = dist * np.sin(np.radians(b)), dist * np.cos(np.radians(b))
                inside = (np.abs((b - self.az + 180) % 360 - 180) <= 40) & (dist > 5) & (dist <= 420)
                if kind == "solid":
                    cloudy = inside
                else:
                    ci, cj = np.floor(e / 4.0).astype(int), np.floor(n / 4.0).astype(int)
                    cloudy = inside & (((ci * 73856093) ^ (cj * 19349663)) % 2 == 0)
                return np.where(cloudy, 3.0, 0.0), np.where(cloudy, 9500.0, np.nan)
            scans[kind] = (mocks.MockGoes(d, WASH, {(21, 36): mocks.goes_field(WASH, self.az, f)}), d)
        out = {}
        sky = mocks.MockOpenMeteo(WASH, lambda b, d, h: {"low": 0, "mid": 0, "high": 50, "precip": 0.0})
        for kind, (g, d) in scans.items():
            out[kind] = s.run(*WASH, "2026-11-06", now_utc=datetime.datetime(2026, 11, 7, 18, 0, tzinfo=UTC),
                              cache_dir=os.path.join(d, "cache"), use_sat=True, fetch_json=sky,
                              goes_get_text=g.get_text, goes_get_file=g.get_file, log=lambda *a: None)
        self.assertLess(out["solid"]["satellite"]["dapple"]["fwd"]["high"], 0.08)
        self.assertGreater(out["speckle"]["satellite"]["dapple"]["fwd"]["high"], 0.30)
        self.assertGreater(out["speckle"]["score"], out["solid"]["score"])      # same forecast, different texture
        used = out["speckle"]["mid_hour"]["detail"]["fwd"]["high"][1]
        self.assertAlmostEqual(used, out["speckle"]["satellite"]["dapple"]["fwd"]["high"], delta=0.01)
        self.assertIn("Dapple measured from satellite pixels", s.format_report(out["speckle"]))


# ====================================================== rate limit / resume
class TestRateLimit(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.saved = (s._sleep, s._clock, s.http_get_json, s._http_get)
        self.now = 1000.0
        self.sleeps = []

        def fake_sleep(sec):
            self.sleeps.append(sec)
            self.now += sec
        s._sleep, s._clock = fake_sleep, lambda: self.now

    def tearDown(self):
        s._sleep, s._clock, s.http_get_json, s._http_get = self.saved
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_download_stays_under_the_per_minute_limit(self):
        mock = mocks.MockOpenMeteo(WASH, mocks.clear_sky)
        stamps = []

        def counting(url):
            data = mock(url)
            stamps.append((self.now, len(data)))
            return data
        s.http_get_json = counting
        s.fetch_sky(*WASH, "2026-11-06", [17], self.tmp, log=lambda *a: None)
        self.assertEqual(sum(n for _, n in stamps), 961)
        self.assertGreaterEqual(len(self.sleeps), 1)
        for t0, _ in stamps:                              # any 60 s window
            in_window = sum(n for t1, n in stamps if t0 <= t1 < t0 + 60)
            self.assertLessEqual(in_window, 600)

    def test_failed_download_resumes_where_it_stopped(self):
        mock = mocks.MockOpenMeteo(WASH, mocks.dappled_west(250))
        calls = []

        def flaky(url):
            calls.append(url)
            if len(calls) == 5:
                raise RuntimeError("HTTP 429 daily limit")
            return mock(url)
        s.http_get_json = flaky
        with self.assertRaises(RuntimeError):
            s.fetch_sky(*WASH, "2026-11-06", [17], self.tmp, log=lambda *a: None)
        names = sorted(os.listdir(self.tmp))
        self.assertEqual(len(names), 1)
        self.assertTrue(names[0].endswith(".part"))
        calls.clear()
        s.http_get_json = lambda url: (calls.append(url), mock(url))[1]
        sky, elev = s.fetch_sky(*WASH, "2026-11-06", [17], self.tmp, log=lambda *a: None)
        self.assertEqual(len(calls), 6)                   # 10 chunks - 4 already saved
        self.assertEqual([n for n in os.listdir(self.tmp)], [n[:-5] for n in names])
        ref = s.fetch_sky(*WASH, "2026-11-06", [17], tempfile.mkdtemp(), mock, log=lambda *a: None)
        self.assertEqual(sky, ref[0])

    def test_minutely_429_waits_and_retries(self):
        replies = [RuntimeError('HTTP 429 from x: {"reason":"Minutely API request limit exceeded."}')] * 2
        replies.append('{"ok": 1}')

        def fake_get(url):
            r = replies.pop(0)
            if isinstance(r, Exception):
                raise r
            return r
        s._http_get = fake_get
        self.assertEqual(s.http_get_json("u", log=lambda *a: None), {"ok": 1})
        self.assertEqual(self.sleeps, [s.RATE_WAIT_S, s.RATE_WAIT_S])

    def test_daily_429_is_not_retried(self):
        def fake_get(url):
            raise RuntimeError('HTTP 429 from x: {"reason":"Daily API request limit exceeded."}')
        s._http_get = fake_get
        with self.assertRaises(RuntimeError):
            s.http_get_json("u", log=lambda *a: None)
        self.assertEqual(self.sleeps, [])


if __name__ == "__main__":
    unittest.main(verbosity=1)


# ================================================ v1.1: cloud cube + sight line
def disc_grid(radius_km, value=1.0):
    """Cover `value` in every cell within radius_km of the observer, 0 beyond."""
    return [[value if math.hypot((c - s.N) * s.SPACING_KM, (r - s.N) * s.SPACING_KM) <= radius_km
             else 0.0 for c in range(s.SIZE)] for r in range(s.SIZE)]


def cube_sky(low=None, mid=None, high=None, heights=None, precip=None):
    """A sky with a cloud cube: constant (bottom, top) metres above sea level
    wherever a layer has cloud, None elsewhere."""
    sky = fake_sky(low, mid, high, precip)
    hts = {"low": (500.0, 2500.0), "mid": (4000.0, 5500.0), "high": (8500.0, 10500.0)}
    hts.update(heights or {})
    sky["cube"] = {}
    for L in s.LAYERS:
        b, t = hts[L]
        sky["cube"][L] = {
            "bottom": [[b if sky[L][r][c] > 0 else None for c in range(s.SIZE)] for r in range(s.SIZE)],
            "top": [[t if sky[L][r][c] > 0 else None for c in range(s.SIZE)] for r in range(s.SIZE)]}
    return sky


class TestSightGeometry(unittest.TestCase):
    AZ = s.sunset_azimuth(WASH[0], 2026, 11, 6)

    def test_pressure_to_height(self):
        self.assertAlmostEqual(s.pressure_to_height_m(101325.0), 0.0, places=3)
        self.assertAlmostEqual(s.pressure_to_height_m(50000.0), 5574.0, delta=10)     # standard atmosphere
        self.assertAlmostEqual(s.pressure_to_height_m(25000.0), 10362.0, delta=15)

    def test_apparent_elevation(self):
        # 3 km at 100 km: 0.03 rad - 0.87 * 100 / (2 * 6371) rad = 1.3277 degrees
        self.assertAlmostEqual(s.apparent_elevation_deg(3000.0, 100.0), 1.3277, places=3)
        # the curvature hides it past sqrt(2 R h / 0.87): about 209.6 km for 3 km
        self.assertAlmostEqual(s.apparent_elevation_deg(3000.0, 209.6), 0.0, delta=0.01)
        self.assertLess(s.apparent_elevation_deg(3000.0, 260.0), -0.3)

    def test_horizon_dip(self):
        self.assertEqual(s.horizon_dip_deg(0.0), 0.0)
        self.assertAlmostEqual(s.horizon_dip_deg(171.0), 0.39, delta=0.02)

    def test_high_deck_does_not_block_the_sun(self):
        sky = cube_sky(high=uniform(1.0))               # a solid deck 8.5-10.5 km up, all the way out
        r = s.score_hour(sky, self.AZ)
        self.assertLess(r["sight"]["block"], 0.5)        # only its far edge (350+ km) meets the sun line, and it is thin
        self.assertEqual(r["gate"], 1.0)
        short = cube_sky(high=disc_grid(300.0))
        self.assertEqual(s.score_hour(short, self.AZ)["sight"]["block"], 0.0)

    def test_ground_fog_blocks_the_sun_but_not_when_the_sun_is_higher(self):
        sky = cube_sky(low=uniform(1.0), heights={"low": (0.0, 300.0)})
        self.assertEqual(s.score_hour(sky, self.AZ)["gate"], 0.0)
        # a 300 m fog bank seen from 10+ km is a thin strip at the horizon; the sun 5 degrees up clears it
        high_sun = s.score_hour(sky, self.AZ, 0.0, None, 5.0)
        self.assertEqual(high_sun["sight"]["block"], 0.0)
        self.assertEqual(high_sun["gate"], 1.0)

    def test_elevated_deck_blocks_only_if_it_reaches_the_sun_line(self):
        heights = {"low": (2300.0, 3200.0)}             # crosses the horizon line at ~184-216 km
        short = cube_sky(low=disc_grid(150.0), heights=heights)
        long_ = cube_sky(low=disc_grid(480.0), heights=heights)
        self.assertLess(s.score_hour(short, self.AZ)["sight"]["block"], 0.02)
        self.assertEqual(s.score_hour(short, self.AZ)["gate"], 1.0)
        self.assertGreater(s.score_hour(long_, self.AZ)["sight"]["block"], 0.9)
        self.assertEqual(s.score_hour(long_, self.AZ)["gate"], 0.0)
        span = s.score_hour(long_, self.AZ)["sight"]["layers"]["low"]["span_km"]
        self.assertGreaterEqual(span[0], 170)
        self.assertLessEqual(span[0], 220)

    def test_cube_gate_is_not_the_flat_low_cloud_average(self):
        deck = disc_grid(120.0)
        flat = fake_sky(low=deck)                       # v1: low cloud 120 km out closes the gate
        cube = cube_sky(low=deck, heights={"low": (2300.0, 3200.0)})
        a, b = s.score_hour(flat, self.AZ), s.score_hour(cube, self.AZ)
        self.assertLess(a["gate"], 0.5)
        self.assertEqual(b["gate"], 1.0)
        self.assertGreater(b["score"], a["score"])

    def test_cloud_below_the_horizon_is_not_counted(self):
        sky = cube_sky(low=disc_grid(480.0), heights={"low": (0.0, 1000.0)})
        grid, cells = s._layer_view(sky, "low", self.AZ, s.GRID_REACH_KM, 0.0, (0.0, 1000.0))
        dists = [s._bearing_dist(r - s.OBS[0], c - s.OBS[1])[1] for r, c in cells]
        self.assertTrue(dists)
        self.assertLess(max(dists), 180.0)              # a 1 km top is out of sight past ~123 km, 0.87 refraction: ~132

    def test_cloud_above_the_sun_decorates_and_cloud_at_or_below_it_does_not(self):
        az = self.AZ
        above = cube_sky(mid=uniform(1.0), heights={"mid": (4000.0, 5500.0)})
        grid, cells = s._layer_view(above, "mid", az, 100.0, 0.0, (4000.0, 5500.0), s.SUN_REF_DEG)
        self.assertTrue(cells)
        self.assertTrue(all(grid[r][c] == 1.0 for r, c in cells))        # all above the sun at < 100 km
        # from a 171 m hill the horizon is 0.39 degrees down, so a low bank 100-130 km out is
        # visible but its top (below 0 degrees) is at or under the sun: a silhouette, no credit
        low = cube_sky(low=uniform(1.0), heights={"low": (0.0, 500.0)})
        grid, cells = s._layer_view(low, "low", az, 130.0, 171.0, (0.0, 500.0), s.SUN_REF_DEG)
        far = [(r, c) for r, c in cells if s._bearing_dist(r - s.OBS[0], c - s.OBS[1])[1] >= 100.0]
        self.assertTrue(far)
        self.assertTrue(all(grid[r][c] == 0.0 for r, c in far))
        # the straddling share: a layer 0-2000 m high spans -0.26..+1.45 degrees at 67 km; the sun's top limb is at 0.0
        part = cube_sky(low=uniform(1.0), heights={"low": (0.0, 2000.0)})
        grid, cells = s._layer_view(part, "low", az, 100.0, 0.0, (0.0, 2000.0), s.SUN_REF_DEG)
        r, c = min(cells, key=lambda p: abs(s._bearing_dist(p[0] - s.OBS[0], p[1] - s.OBS[1])[1] - 67.0))
        d = s._bearing_dist(r - s.OBS[0], c - s.OBS[1])[1]
        e_b, e_t = s.apparent_elevation_deg(0.0, d), s.apparent_elevation_deg(2000.0, d)
        self.assertAlmostEqual(grid[r][c], (e_t - 0.0) / (e_t - e_b), places=6)
        self.assertAlmostEqual(grid[r][c], 0.847, delta=0.01)

    def test_observer_elevation_matters_for_the_geometry(self):
        deck = disc_grid(480.0)
        sky = cube_sky(low=deck, heights={"low": (2300.0, 3200.0)})
        flat = s.sight_line(sky, self.AZ, 0.0, s.SUN_REF_DEG, {"low": (2300.0, 3200.0), "mid": (4000.0, 5500.0),
                                                              "high": (8500.0, 10500.0)})["layers"]["low"]["span_km"]
        hill = s.sight_line(sky, self.AZ, 500.0, s.SUN_REF_DEG, {"low": (2300.0, 3200.0), "mid": (4000.0, 5500.0),
                                                                "high": (8500.0, 10500.0)})["layers"]["low"]["span_km"]
        self.assertLess(hill[0], flat[0])               # the deck is lower relative to a high eye: it meets the horizon sooner

    def test_report_names_the_blocking_layer(self):
        sky = cube_sky(low=disc_grid(480.0), heights={"low": (2300.0, 3200.0)})
        res = {"mid_hour": s.score_hour(sky, self.AZ), "satellite": None}
        text = " ".join(s.explain(res))
        self.assertIn("low layer", text)
        self.assertIn("2.3", text)


class TestCubeFile(unittest.TestCase):
    NOW = datetime.datetime(2026, 11, 6, 20, 0, tzinfo=UTC)

    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def go(self, scenario, ncss=None, **kw):
        ncss = ncss or mocks.MockNcss(WASH, scenario)
        res = s.run(*WASH, "2026-11-06", now_utc=self.NOW, cache_dir=self.tmp, use_sat=False,
                    fetch_file=ncss, log=lambda *a: None, **kw)
        return res, ncss

    def cube_file(self):
        return os.path.join(self.tmp, [n for n in os.listdir(self.tmp) if n.startswith("gfscube_")][0])

    def test_url_asks_for_the_cube_family(self):
        start = datetime.datetime(2026, 11, 6, 16, 45, tzinfo=UTC)
        url = s.gfs_url(*WASH, start, start + datetime.timedelta(hours=10))
        for name in ("Low_cloud_cover_low_cloud_Mixed_intervals_Average",
                     "High_cloud_cover_high_cloud_Mixed_intervals_Average",
                     "Precipitation_rate_surface_Mixed_intervals_Average",
                     "Pressure_low_cloud_top_Mixed_intervals_Average",
                     "Pressure_middle_cloud_bottom_Mixed_intervals_Average",
                     "Pressure_high_cloud_top_Mixed_intervals_Average",
                     "Geopotential_height_surface"):
            self.assertIn("var=" + name + "&", url)
        self.assertEqual(url.count("var="), 11)
        self.assertNotIn("Geopotential", s.gfs_url(*WASH, start, start, extras=False))

    def test_window_bins_use_the_six_hour_mean_to_get_the_second_half(self):
        H = lambda h: datetime.datetime(2026, 11, 6, h, tzinfo=UTC)
        iv = [(0, H(12), H(15)), (1, H(12), H(18)), (2, H(18), H(21)), (3, H(18), datetime.datetime(2026, 11, 7, 0, tzinfo=UTC))]
        bins = s._three_hour_bins(iv)
        self.assertEqual([(a.hour, b.hour, p) for a, b, p in bins],
                         [(12, 15, (0,)), (15, 18, (1, 0)), (18, 21, (2,)), (21, 0, (3, 2))])
        self.assertEqual(s._pick_interval(iv, H(22)), 3)        # only the 6 h mean spans 22Z
        self.assertEqual(s._pick_interval(iv, H(13)), 0)        # the narrower of two containing windows

    def test_cover_is_recovered_for_the_three_hour_window_not_the_six_hour_mean(self):
        step = lambda b, d, h: {"low": 0, "mid": 0, "high": 0.0 if h < 16.0 else 100.0, "precip": 0.0}
        res, _ = self.go(step)
        # 3 h windows centred 19.5Z (local 14.5 -> 0%) and 22.5Z (17.5 -> 100%); the 6 h mean is 50%.
        # 22Z (17 local) is 5/6 of the way between the centres.
        self.assertAlmostEqual(res["per_hour"][17]["detail"]["over"]["high"][0], 5.0 / 6.0, delta=0.02)
        self.assertAlmostEqual(res["per_hour"][16]["detail"]["over"]["high"][0], 0.5, delta=0.02)
        self.assertAlmostEqual(res["per_hour"][18]["detail"]["over"]["high"][0], 1.0, delta=0.02)

    def test_linear_ramp_comes_out_linear(self):
        ramp = lambda b, d, h: {"low": 0, "mid": 0, "high": max(0, min(100, (h - 10) * 10)), "precip": 0.0}
        res, _ = self.go(ramp)
        self.assertAlmostEqual(res["per_hour"][17]["detail"]["over"]["high"][0], 0.70, delta=0.02)

    def test_heights_come_back_in_metres_and_none_where_there_is_no_cloud(self):
        az = s.sunset_azimuth(WASH[0], 2026, 11, 6)
        sc = mocks.bank_at(az, half=20, near=40, far=400, layer="mid", pct=100)
        self.go(sc)
        sky, _ = s.parse_gfs(self.cube_file(), *WASH, datetime.date(2026, 11, 6), [17])
        cube = sky[17]["cube"]["mid"]
        west_row = s.N - round(math.cos(math.radians(az)) * 4)
        west_col = s.N + round(math.sin(math.radians(az)) * 4)
        self.assertAlmostEqual(cube["bottom"][west_row][west_col], 4000.0, delta=30)
        self.assertAlmostEqual(cube["top"][west_row][west_col], 5500.0, delta=30)
        self.assertIsNone(cube["bottom"][s.N + (s.N - west_row)][s.N + (s.N - west_col)])     # behind you
        self.assertIsNone(sky[17]["cube"]["high"]["top"][s.N][s.N])                          # no high cloud anywhere
        typ = s.layer_typical(sky[17], "mid")
        self.assertAlmostEqual(typ[0], 4000.0, delta=30)
        self.assertEqual(s.layer_typical(sky[17], "high"), s.DEFAULT_LAYER_ASL_M["high"])

    def test_heights_follow_the_scenario_not_a_constant(self):
        hts = lambda b, d, h: {"low": (300.0, 900.0), "mid": (4000.0, 5500.0),
                               "high": (8000.0, 8000.0 + 10.0 * d)}          # tops rise with distance
        self.go(lambda b, d, h: {"low": 0, "mid": 0, "high": 100, "precip": 0.0},
                ncss=mocks.MockNcss(WASH, lambda b, d, h: {"low": 0, "mid": 0, "high": 100, "precip": 0.0},
                                    heights=hts))
        sky, _ = s.parse_gfs(self.cube_file(), *WASH, datetime.date(2026, 11, 6), [17])
        top = sky[17]["cube"]["high"]["top"]
        self.assertGreater(top[s.N][s.N + 10], top[s.N][s.N + 2] + 1500.0)     # 300 km vs 60 km east

    def test_terrain_height_is_read(self):
        res, _ = self.go(mocks.clear_sky, ncss=mocks.MockNcss(WASH, mocks.clear_sky,
                                                             elevation_fn=lambda la, lo: 171.0))
        self.assertAlmostEqual(res["elevation_m"], 171.0, delta=1.0)
        self.assertTrue(res["cube"])

    def test_stratus_deck_means_no_sunset(self):
        res, _ = self.go(mocks.stratus_everywhere)
        self.assertEqual(res["score"], 0)
        self.assertIn("blocked", " ".join(s.explain(res)))

    def test_clear_sky_scores_the_floor(self):
        res, _ = self.go(mocks.clear_sky)
        self.assertEqual(res["score"], 25)

    def test_an_elevated_deck_that_stops_short_leaves_the_sun_but_a_ground_deck_blocks_it(self):
        az = s.sunset_azimuth(WASH[0], 2026, 11, 6)
        deck = mocks.bank_at(az, half=60, near=0, far=130, layer="low", pct=100)
        elevated = mocks.MockNcss(WASH, deck, heights={"low": (2300.0, 3200.0), "mid": (4000.0, 5500.0),
                                                       "high": (8500.0, 10500.0)})
        res, _ = self.go(deck, ncss=elevated)
        self.assertEqual(res["mid_hour"]["gate"], 1.0)
        shutil.rmtree(self.tmp)
        ground = mocks.MockNcss(WASH, deck, heights={"low": (0.0, 400.0), "mid": (4000.0, 5500.0),
                                                     "high": (8500.0, 10500.0)})
        res2, _ = self.go(deck, ncss=ground)
        self.assertLess(res2["mid_hour"]["gate"], 0.5)          # a 400 m ground deck sits at the sun's height
        # whereas the plain v1 reading of the same forecast closes the gate on any low cloud
        shutil.rmtree(self.tmp)
        flat, _ = self.go(deck, gfs_cube=False)
        self.assertLess(flat["mid_hour"]["gate"], 0.9)

    def test_a_fresh_plain_cache_file_is_not_used_when_the_cube_is_wanted(self):
        self.go(mocks.clear_sky, gfs_cube=False)                 # leaves gfs_...nc (plain) in the cache
        ncss = mocks.MockNcss(WASH, mocks.clear_sky)
        res, ncss = self.go(mocks.clear_sky, ncss=ncss)
        self.assertEqual(len(ncss.urls), 1)                      # downloaded the cube anyway
        self.assertTrue(res["cube"])
        self.assertTrue(any(n.startswith("gfscube_") for n in os.listdir(self.tmp)))

    def test_cube_download_is_cached(self):
        _, ncss = self.go(mocks.clear_sky)
        self.assertEqual(len(ncss.urls), 1)
        self.go(mocks.clear_sky, ncss=ncss)
        self.assertEqual(len(ncss.urls), 1)

    def test_server_refusing_the_cube_falls_back_to_the_plain_request(self):
        res, ncss = self.go(mocks.clear_sky, ncss=mocks.MockNcss(WASH, mocks.clear_sky, reject_cube=True))
        self.assertEqual(len(ncss.urls), 3)             # cube+terrain, cube, then plain+terrain
        self.assertIn("var=Low_cloud_cover_low_cloud&", ncss.urls[2])
        self.assertFalse(res["cube"])
        self.assertEqual(res["score"], 25)
        self.assertEqual(res["source"], "NOAA GFS")

    def test_terrain_refused_alongside_clouds_is_asked_for_alone(self):
        ncss = mocks.MockNcss(WASH, mocks.clear_sky, elevation_fn=lambda la, lo: 171.0,
                              reject_geo_with_clouds=True)
        res, ncss = self.go(mocks.clear_sky, ncss=ncss)
        self.assertEqual(len(ncss.urls), 3)
        self.assertEqual(ncss.urls[2].count("var="), 1)
        self.assertAlmostEqual(res["elevation_m"], 171.0, delta=1.0)
        self.assertTrue(res["cube"])
        n = len(ncss.urls)
        shutil.rmtree(os.path.join(self.tmp), ignore_errors=True)
        self.assertEqual(n, 3)

    def test_network_failure_is_not_retried_as_a_simpler_request(self):
        calls = []

        def down(url, dest):
            calls.append(url)
            raise OSError("tunnel failed")
        res = s.run(*WASH, "2026-11-06", now_utc=self.NOW, cache_dir=self.tmp, use_sat=False,
                    fetch_file=down, fetch_json=mocks.MockOpenMeteo(WASH, mocks.clear_sky),
                    log=lambda *a: None)
        self.assertEqual(len(calls), 1)
        self.assertEqual(res["source"], "Open-Meteo")

    def test_satellite_layer_bands_follow_the_model(self):
        self.assertAlmostEqual(s.pressure_to_height_m(64200.0), 3700.0, delta=100)     # 642 hPa
        self.assertAlmostEqual(s.pressure_to_height_m(35000.0), 8100.0, delta=100)     # 350 hPa
        self.assertEqual((s.LOW_TOP_M, s.MID_TOP_M), (3700.0, 8100.0))


# ====================================================== v1.1: wind-shifted satellite
class TestWindShift(unittest.TestCase):
    """Satellite scans carried to sunset on the steering wind, trusted less with age."""

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.az = s.sunset_azimuth(WASH[0], 2026, 11, 6)

        def pattern(kind):
            def f(b, d):
                acm = np.zeros(b.shape)
                ht = np.full(b.shape, np.nan)
                sun = (np.abs((b - cls.az + 180) % 360 - 180) <= 14) & (d > 5) & (d <= 125)
                if kind == "bank":
                    acm[sun], ht[sun] = 3, 800.0
                return acm, ht
            return f
        cls.fields = {k: mocks.goes_field(WASH, cls.az, pattern(k)) for k in ("clear", "bank")}

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def wind_toward(self, bearing, speed):
        b = math.radians(bearing)
        w = (speed * math.sin(b), speed * math.cos(b))
        return {L: w for L in s.LAYERS}

    # ---- weights
    def test_weights_fall_with_age_and_move_toward_the_unshifted_picture(self):
        w0 = s.sat_weights(0.0)
        self.assertEqual((w0["total"], w0["unshifted"], w0["shifted"]), (1.0, 0.0, 1.0))
        prev = 2.0
        for a in (0.5, 1.0, 1.5, 2.0, 2.5, 2.9):
            w = s.sat_weights(a)
            self.assertLess(w["total"], prev)
            prev = w["total"]
            self.assertAlmostEqual(w["unshifted"] + w["shifted"], w["total"])
        self.assertAlmostEqual(s.sat_weights(3.0)["total"], s.SAT_FLOOR)     # old scans keep a floor: decks persist
        self.assertAlmostEqual(s.sat_weights(5.0)["total"], s.SAT_FLOOR)
        self.assertGreater(s.sat_weights(1.0)["total"], 0.9)           # a fresh scan keeps nearly all of it
        self.assertLess(s.sat_weights(2.9)["total"], s.SAT_FLOOR + 0.07)
        # shifted share of the satellite's weight falls with age, unshifted share rises
        share = lambda a: s.sat_weights(a)["unshifted"] / s.sat_weights(a)["total"]
        self.assertLess(share(0.5), share(1.5))
        self.assertAlmostEqual(share(2.99), s.SHIFT_PERSIST_MAX, places=2)
        nowind = s.sat_weights(1.0, have_winds=False)
        self.assertEqual((nowind["shifted"], nowind["unshifted"]), (0.0, nowind["total"]))
        self.assertEqual(s.sat_weights(-1.0)["total"], 1.0)

    def test_shift_vectors(self):
        v = s.shift_vectors({L: (10.0, -5.0) for L in s.LAYERS}, 2.0)       # 10 m/s east, 5 m/s south
        self.assertAlmostEqual(v["low"][0], 72.0)
        self.assertAlmostEqual(v["low"][1], -36.0)

    # ---- tracing
    def test_clouds_are_traced_back_along_their_own_layers_wind(self):
        # a low cloud at (100, 0) km and a high one at (0, 100) km in the scan
        scan = {(100.0, 0.0): [("low", 800.0)], (0.0, 100.0): [("high", 10000.0)]}
        sample = lambda e, n: scan.get((round(e, 6), round(n, 6)), [])
        shift = {"low": (50.0, 0.0), "mid": (0.0, 0.0), "high": (0.0, -30.0)}    # low moves east 50, high south 30
        self.assertEqual(s.shifted_layers(sample, 150.0, 0.0, shift), [("low", 800.0)])
        self.assertEqual(s.shifted_layers(sample, 0.0, 70.0, shift), [("high", 10000.0)])
        self.assertEqual(s.shifted_layers(sample, 100.0, 0.0, shift), [])       # the low cloud has left
        # the high cloud's spot is not carried by the low wind
        self.assertEqual(s.shifted_layers(sample, 50.0, 100.0, {"low": (50, 0), "mid": (0, 0), "high": (0, 0)}),
                         [])
        self.assertEqual(s.shifted_layers(sample, 100.0, 0.0, None), [("low", 800.0)])

    def test_unknown_source_pixels_stay_unknown_unless_something_is_known(self):
        sample = lambda e, n: None if e > 0 else []
        shift = {L: (0.0, 0.0) for L in s.LAYERS}
        self.assertIsNone(s.shifted_layers(sample, 10.0, 0.0, shift))
        self.assertEqual(s.shifted_layers(sample, -10.0, 0.0, shift), [])
        # one trace lands on unknown, another on a known clear pixel: known wins
        shift2 = {"low": (0.0, 0.0), "mid": (0.0, 0.0), "high": (30.0, 0.0)}
        self.assertEqual(s.shifted_layers(sample, 10.0, 0.0, shift2), [])

    def test_blend_dapple(self):
        d0 = {"fwd": {"low": 0.2, "mid": None, "high": None}}
        d1 = {"fwd": {"low": 0.6, "mid": 0.5, "high": None}}
        out = s.blend_dapple(d0, d1, 0.25, 0.75)
        self.assertAlmostEqual(out["fwd"]["low"], 0.5)
        self.assertEqual(out["fwd"]["mid"], 0.5)                    # only the shifted scan has mid cloud
        self.assertIsNone(out["fwd"]["high"])
        self.assertEqual(s.blend_dapple(d0, None, 0.0, 0.0)["fwd"]["low"], 0.2)
        self.assertIsNone(s.blend_dapple(None, None, 0.5, 0.5))

    # ---- winds from the file
    def write_wind_file(self, path, u_by_level, v_by_level, times=(21, 24)):
        from netCDF4 import Dataset
        ds = Dataset(path, "w")
        ds.createDimension("time", len(times))
        ds.createDimension("isobaric", 3)
        ds.createDimension("latitude", 4)
        ds.createDimension("longitude", 5)
        tv = ds.createVariable("time", "f8", ("time",))
        tv.units = "Hour since 2026-11-01T00:00:00Z"
        tv[:] = [5 * 24 + 24 * 0 + h for h in times]
        pv = ds.createVariable("isobaric", "f8", ("isobaric",))
        pv[:] = [25000.0, 55000.0, 85000.0]
        for name, by in (("u-component_of_wind_isobaric", u_by_level), ("v-component_of_wind_isobaric", v_by_level)):
            var = ds.createVariable(name, "f4", ("time", "isobaric", "latitude", "longitude"))
            for ti in range(len(times)):
                for k in range(3):
                    var[ti, k, :, :] = by[ti][k]
        ds.close()

    def test_parse_winds_picks_levels_and_blends_in_time(self):
        path = os.path.join(self.tmp, "w.nc")
        # time 0 = 21Z Nov 6 ... (5 days after Nov 1 00Z = hour 120): 21Z and 24Z
        self.write_wind_file(path, u_by_level=[[40.0, 20.0, 10.0], [50.0, 30.0, 20.0]],
                             v_by_level=[[0.0, -5.0, 0.0], [10.0, 5.0, 0.0]])
        scan = datetime.datetime(2026, 11, 6, 21, 0, tzinfo=UTC)
        sunset = datetime.datetime(2026, 11, 7, 0, 0, tzinfo=UTC)      # midpoint 22:30Z: half-way in time
        w = s.parse_winds(path, scan, sunset)
        self.assertAlmostEqual(w["high"][0], 45.0)                     # 250 hPa u: 40 -> 50
        self.assertAlmostEqual(w["mid"][0], 25.0)                      # 550 hPa
        self.assertAlmostEqual(w["low"][0], 15.0)                      # 850 hPa
        self.assertAlmostEqual(w["mid"][1], 0.0)                       # v: -5 -> 5
        # a midpoint before the file's first time takes the first step
        early = s.parse_winds(path, scan - datetime.timedelta(hours=10), scan - datetime.timedelta(hours=6))
        self.assertAlmostEqual(early["high"][0], 40.0)

    def test_wind_url_asks_for_u_and_v_only(self):
        start = datetime.datetime(2026, 11, 6, 16, 45, tzinfo=UTC)
        url = s.gfs_wind_url(*WASH, start, start + datetime.timedelta(hours=10))
        self.assertIn("var=u-component_of_wind_isobaric", url)
        self.assertIn("var=v-component_of_wind_isobaric", url)
        self.assertNotIn("cloud", url.lower())

    # ---- the check itself
    def goes(self, kind):
        d = tempfile.mkdtemp(dir=self.tmp)
        return mocks.MockGoes(d, WASH, {(20, 36): self.fields[kind]}), d

    def run_check(self, kind, winds, sunset=datetime.datetime(2026, 11, 6, 21, 46, tzinfo=UTC)):
        g, d = self.goes(kind)
        when = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        return s.satellite_check(*WASH, self.az, s.SIGHT_MAX_KM, when, os.path.join(d, "cache"),
                                 g.get_text, g.get_file, log=lambda *a: None, elev_m=140.0,
                                 winds=winds, sunset_utc=sunset)

    def test_no_winds_means_the_observed_scan_only(self):
        out = self.run_check("bank", None)
        self.assertIsNone(out["block_shifted"])
        self.assertIsNone(out["shift_km"])
        self.assertAlmostEqual(out["gate"], out["gate_observed"])
        self.assertGreater(out["block"], 0.9)
        self.assertAlmostEqual(out["age_h"], 1.16, delta=0.02)
        self.assertEqual(out["weights"]["shifted"], 0.0)

    def test_wind_that_carries_the_bank_off_the_sun_line_opens_the_gate(self):
        out = self.run_check("bank", self.wind_toward(self.az, 80.0))       # 80 m/s toward the sun: ~330 km in 1.16 h
        self.assertGreater(out["block_observed"], 0.9)
        self.assertLess(out["block_shifted"], 0.1)
        self.assertLess(out["gate_observed"], 0.1)
        self.assertGreater(out["gate_shifted"], 0.9)
        # blended by the age weights: shifted dominates, but the unshifted picture keeps a share
        w = out["weights"]
        want = (w["unshifted"] * out["gate_observed"] + w["shifted"] * out["gate_shifted"]) / (w["unshifted"] + w["shifted"])
        self.assertAlmostEqual(out["gate"], want)
        self.assertGreater(out["gate"], 0.6)
        self.assertLess(out["gate"], 0.95)
        self.assertIsNotNone(out["shift_km"])

    def test_zero_wind_equals_the_observed_scan(self):
        out = self.run_check("bank", self.wind_toward(0.0, 0.0))
        self.assertAlmostEqual(out["block_shifted"], out["block_observed"])
        self.assertAlmostEqual(out["gate"], out["gate_observed"])

    def test_scan_at_sunset_is_not_shifted(self):
        sunset = datetime.datetime(2026, 11, 6, 20, 36, 17, tzinfo=UTC)     # the scan IS the sunset instant
        out = self.run_check("bank", self.wind_toward(self.az, 80.0), sunset=sunset)
        self.assertIsNone(out["shift_km"])
        self.assertEqual(out["age_h"], 0.0)

    def test_shifted_dapple_follows_the_cloud(self):
        calm = self.run_check("bank", self.wind_toward(0.0, 0.0))
        moved = self.run_check("bank", self.wind_toward(self.az, 80.0))
        self.assertIsNotNone(calm["dapple"])
        self.assertIsNotNone(moved["dapple"])

    def test_full_run_fetches_winds_shifts_and_reports(self):
        g, d = self.goes("bank")
        ncss = mocks.MockNcss(WASH, mocks.clear_sky)
        wind = self.wind_toward(self.az, 40.0)
        urls = []

        def fetch(url, dest):
            urls.append(url)
            if "u-component_of_wind" in url:
                self.write_wind_file(dest, [[wind["high"][0]] * 3] * 2, [[wind["high"][1]] * 3] * 2,
                                     times=(18, 21))
                return
            return ncss(url, dest)

        now = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        res = s.run(*WASH, "2026-11-06", now_utc=now, cache_dir=os.path.join(d, "cache"), use_sat=True,
                    fetch_file=fetch, goes_get_text=g.get_text, goes_get_file=g.get_file, log=lambda *a: None)
        sat = res["satellite"]
        self.assertTrue(any("u-component_of_wind" in u for u in urls))
        self.assertIsNotNone(sat["shift_km"])
        self.assertAlmostEqual(math.hypot(*sat["shift_km"]["low"]), 40.0 * 3.6 * sat["age_h"], delta=0.1)
        self.assertGreater(sat["weights"]["shifted"], sat["weights"]["unshifted"])
        report = s.format_report(res)
        self.assertIn("carried on the model's steering winds", report)
        self.assertLess(res["mid_hour"]["gate"], 1.0)                       # the satellite pulled the gate
        self.assertEqual(res["mid_hour"]["gate_forecast"], 1.0)

    def test_full_run_survives_a_wind_download_failure(self):
        g, d = self.goes("clear")
        ncss = mocks.MockNcss(WASH, mocks.clear_sky)

        def fetch(url, dest):
            if "u-component_of_wind" in url:
                raise RuntimeError("HTTP 400 from ncss: nope")
            return ncss(url, dest)

        now = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        logs = []
        res = s.run(*WASH, "2026-11-06", now_utc=now, cache_dir=os.path.join(d, "cache"), use_sat=True,
                    fetch_file=fetch, goes_get_text=g.get_text, goes_get_file=g.get_file, log=logs.append)
        self.assertIsNotNone(res["satellite"])
        self.assertIsNone(res["satellite"]["shift_km"])
        self.assertTrue(any("Wind shift skipped" in str(m) for m in logs))
        self.assertIn("no wind shift", s.format_report(res))

    # ---- mask pictures
    def png_size(self, path):
        with open(path, "rb") as fh:
            head = fh.read(24)
        self.assertEqual(head[:8], b"\x89PNG\r\n\x1a\n")
        return int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big")

    def test_mask_pictures_are_written_and_replaced(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        g, d = self.goes("bank")
        when = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        sunset = datetime.datetime(2026, 11, 6, 21, 46, tzinfo=UTC)
        for _ in range(2):                                    # the second query replaces the first
            s.satellite_check(*WASH, self.az, s.SIGHT_MAX_KM, when, os.path.join(d, "cache"), g.get_text,
                              g.get_file, log=lambda *a: None, elev_m=140.0,
                              winds=self.wind_toward(self.az, 40.0), sunset_utc=sunset, mask_dir=out)
        top = os.path.join(out, s.MASK_FILE)
        w, h = self.png_size(top)
        self.assertGreater(w, 500)
        self.assertGreater(h, w)                              # picture plus header and legend
        names = sorted(os.listdir(os.path.join(out, s.MASK_DIR)))
        for want in ("CloudMask_ACM.png", "CloudTopLayers_ACHA.png", "Region_SunsetDirection.png",
                     "Region_Overhead.png", "Region_OppositeSky.png", "Composite_WindShifted.png",
                     "Region_SunsetDirection_WindShifted.png"):
            self.assertIn(want, names)
            self.png_size(os.path.join(out, s.MASK_DIR, want))
        self.assertEqual(len(names), len([n for n in names if n.endswith(".png")]))      # no temp files left

    def test_mask_colours_follow_the_scan(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        g, d = self.goes("bank")
        when = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        s.satellite_check(*WASH, self.az, s.SIGHT_MAX_KM, when, os.path.join(d, "cache"), g.get_text, g.get_file,
                          log=lambda *a: None, elev_m=140.0, mask_dir=out)
        try:
            from PIL import Image
        except ImportError:
            self.skipTest("Pillow not installed (only this test reads the picture back)")
        img = np.array(Image.open(os.path.join(out, s.MASK_DIR, "CloudTopLayers_ACHA.png")).convert("RGB"))
        body = img[46:img.shape[0] - 40]
        n = body.shape[0]
        # the bank is low cloud 5-125 km toward the sun: 60 km out that way is a low-top colour
        b = math.radians(self.az)
        row = int(round((s.SIGHT_MAX_KM - 60 * math.cos(b)) / s.SAT_STEP_KM * s.MASK_SCALE))
        col = int(round((s.SIGHT_MAX_KM + 60 * math.sin(b)) / s.SAT_STEP_KM * s.MASK_SCALE))
        near = body[row - 3:row + 4, col - 3:col + 4].reshape(-1, 3)         # outlines may cross a pixel or two
        share = np.mean(np.all(near == np.array(s.MASK_COLORS[2]), axis=1))
        self.assertGreater(share, 0.6)
        opp = body[n - row - 3:n - row + 4, n - col - 3:n - col + 4].reshape(-1, 3)   # the opposite side is clear
        self.assertGreater(np.mean(np.all(opp == np.array(s.MASK_COLORS[1]), axis=1)), 0.6)

    def test_no_pictures_unless_asked(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        g, d = self.goes("clear")
        when = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        s.satellite_check(*WASH, self.az, s.SIGHT_MAX_KM, when, os.path.join(d, "cache"), g.get_text, g.get_file,
                          log=lambda *a: None, elev_m=140.0)
        self.assertEqual(os.listdir(out), [])

    def test_stale_pictures_are_removed_when_there_is_no_scan(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        os.makedirs(os.path.join(out, s.MASK_DIR))
        for rel in (s.MASK_FILE, os.path.join(s.MASK_DIR, "CloudMask_ACM.png")):
            open(os.path.join(out, rel), "wb").write(b"old")
        keep = os.path.join(out, "notes.txt")
        open(keep, "w").write("mine")
        logs = []
        s.clear_masks(out, logs.append)
        self.assertFalse(os.path.exists(os.path.join(out, s.MASK_FILE)))
        self.assertEqual([f for f in os.listdir(os.path.join(out, s.MASK_DIR)) if not f.startswith("Forecast_")], [])
        self.assertTrue(os.path.exists(keep))                  # only our own pictures
        self.assertTrue(logs)

    def test_run_writes_pictures_and_clears_them_when_the_check_is_skipped(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        g, d = self.goes("bank")
        ncss = mocks.MockNcss(WASH, mocks.clear_sky)
        now = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        kw = dict(cache_dir=os.path.join(d, "cache"), fetch_file=ncss, goes_get_text=g.get_text,
                  goes_get_file=g.get_file, log=lambda *a: None, mask_dir=out)
        s.run(*WASH, "2026-11-06", now_utc=now, use_sat=True, **kw)
        self.assertTrue(os.path.exists(os.path.join(out, s.MASK_FILE)))
        s.run(*WASH, "2026-11-06", now_utc=now, use_sat=False, **kw)          # --no-sat: last query's pictures are stale
        self.assertFalse(os.path.exists(os.path.join(out, s.MASK_FILE)))
        s.run(*WASH, "2026-11-06", now_utc=now, use_sat=True, **kw)
        self.assertTrue(os.path.exists(os.path.join(out, s.MASK_FILE)))
        far = datetime.datetime(2026, 11, 6, 12, 0, tzinfo=UTC)                # sunset > 3 h away: no scan used
        s.run(*WASH, "2026-11-06", now_utc=far, use_sat=True, **kw)
        self.assertFalse(os.path.exists(os.path.join(out, s.MASK_FILE)))
        self.assertEqual([f for f in os.listdir(os.path.join(out, s.MASK_DIR)) if not f.startswith("Forecast_")], [])

    # ---- borders and forecast pictures
    def test_border_data_decodes_to_real_outlines(self):
        b = s.us_borders()
        names = {ab: (c, lines) for ab, c, lines in b}
        for ab in ("NY", "NJ", "PA", "CT", "MA", "VT", "NH", "ME", "OH", "VA"):
            self.assertEqual(names[ab][0], "US")
        for ab in ("ON", "QC"):
            self.assertEqual(names[ab][0], "CA")
        for _, _, lines in b:
            for line in lines:
                for la, lo in line:
                    self.assertTrue(33.0 <= la <= 52.5 and -89.0 <= lo <= -62.0)
        # New York's outline passes through the Hudson valley and reaches Lake Erie's east end
        pts = [p for line in names["NY"][1] for p in line]
        self.assertTrue(any(abs(la - 42.7) < 0.3 and abs(lo + 73.7) < 0.3 for la, lo in pts) or
                        any(abs(la - 42.9) < 0.3 and abs(lo + 79.0) < 0.3 for la, lo in pts))
        self.assertGreater(min(la for la, lo in pts), 40.0)
        self.assertGreater(max(la for la, lo in pts), 44.9)

    def test_borders_are_drawn_on_the_picture(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        g, d = self.goes("clear")
        when = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        s.satellite_check(*WASH, self.az, s.SIGHT_MAX_KM, when, os.path.join(d, "cache"), g.get_text, g.get_file,
                          log=lambda *a: None, elev_m=140.0, mask_dir=out)
        try:
            from PIL import Image
        except ImportError:
            self.skipTest("Pillow not installed")
        img = np.array(Image.open(os.path.join(out, s.MASK_FILE)).convert("RGB")).astype(int)
        body = img[46:img.shape[0] - 40]
        clear = np.array(s.MASK_COLORS[1])
        lighter = np.sum(np.abs(body - clear).sum(axis=2) > 30)
        self.assertGreater(lighter, 800)                       # state lines, rings and labels sit on the clear background

    def test_parse_detail_optical_depth(self):
        from netCDF4 import Dataset
        path = os.path.join(self.tmp, "detail.nc")
        ds = Dataset(path, "w")
        ds.createDimension("time", 2)
        ds.createDimension("isobaric1", 3)
        ds.createDimension("latitude", 40)
        ds.createDimension("longitude", 50)
        tv = ds.createVariable("time", "f8", ("time",))
        tv.units = "Hour since 2026-11-01T00:00:00Z"
        tv[:] = [5 * 24 + 21, 5 * 24 + 24]
        pv = ds.createVariable("isobaric1", "f8", ("isobaric1",))
        pv[:] = [30000.0, 50000.0, 70000.0]
        la = ds.createVariable("latitude", "f8", ("latitude",))
        la[:] = np.arange(46.0, 36.0, -0.25)
        lo = ds.createVariable("longitude", "f8", ("longitude",))
        lo[:] = np.arange(279.0, 291.0, 0.24)
        for name, val in (("Ice_water_mixing_ratio_isobaric", 1e-4), ("Cloud_mixing_ratio_isobaric", 0.0)):
            v = ds.createVariable(name, "f4", ("time", "isobaric1", "latitude", "longitude"))
            v[:] = 0.0
            v[0, 1, :, :] = val                                 # one level, the time nearest sunset
        vis = ds.createVariable("Visibility_surface", "f4", ("time", "latitude", "longitude"))
        vis[:] = 16000.0
        ds.close()
        sunset = datetime.datetime(2026, 11, 6, 21, 40, tzinfo=UTC)
        out = s.parse_detail(path, *WASH, sunset)
        want = s.K_MASS_ICE * 1e-4 * 20000.0 / 9.80665          # kg/kg x Pa / g = kg/m2, x m2/kg
        self.assertAlmostEqual(out["ice_tau"][s.N][s.N], want, delta=0.01)
        self.assertEqual(out["liquid_tau"][s.N][s.N], 0.0)
        self.assertAlmostEqual(out["visibility"][s.N][s.N], 16000.0, delta=1)

    def test_forecast_pictures_follow_the_cube_and_are_replaced(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        ncss = mocks.MockNcss(WASH, mocks.bank_at(self.az, near=40, far=200, layer="low"))
        now = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        logs = []
        for _ in range(2):
            s.run(*WASH, "2026-11-06", now_utc=now, cache_dir=os.path.join(out, "cache"), use_sat=False,
                  fetch_file=ncss, log=logs.append, mask_dir=out)
        self.png_size(os.path.join(out, s.FORECAST_FILE))
        names = os.listdir(os.path.join(out, s.MASK_DIR))
        for want in ("Forecast_Cover_Low.png", "Forecast_Cover_Mid.png", "Forecast_Cover_High.png",
                     "Forecast_CloudTop_Highest.png", "Forecast_CloudBase_Lowest.png", "Forecast_SunLine_Cells.png",
                     "Forecast_Precipitation.png", "Forecast_Terrain.png"):
            self.assertIn(want, names)
        self.assertFalse(any(n.endswith(".tmp") for n in names))
        self.assertTrue(any("Forecast pictures:" in str(m) for m in logs))
        try:
            from PIL import Image
        except ImportError:
            return
        img = np.array(Image.open(os.path.join(out, s.MASK_DIR, "Forecast_Cover_Low.png")).convert("RGB"))
        body = img[46:img.shape[0] - 25]
        b = math.radians(self.az)
        row = int(round((s.SIGHT_MAX_KM - 100 * math.cos(b)) / s.SAT_STEP_KM * s.MASK_SCALE))
        col = int(round((s.SIGHT_MAX_KM + 100 * math.sin(b)) / s.SAT_STEP_KM * s.MASK_SCALE))
        in_bank = body[row - 2:row + 3, col - 2:col + 3].reshape(-1, 3).mean(axis=0)
        behind = body[body.shape[0] - row - 3:body.shape[0] - row + 2, body.shape[1] - col - 3:body.shape[1] - col + 2].reshape(-1, 3).mean(axis=0)
        self.assertGreater(in_bank[2], behind[2] + 60)         # full low cover is far brighter blue than clear sky

    # ---- the score uses the potency
    def test_old_scan_barely_moves_the_score_and_a_fresh_one_does(self):
        sky = cube_sky()
        base = s.score_hour(sky, self.az, 0.0)
        fresh = s.score_hour(sky, self.az, 0.0, sat_gate=0.0, sat_gate_w=s.SAT_GATE_MAX_W * 1.0)
        old = s.score_hour(sky, self.az, 0.0, sat_gate=0.0, sat_gate_w=s.SAT_GATE_MAX_W * 0.05)   # a nearly-zero weight
        self.assertEqual(base["gate_forecast"], fresh["gate_forecast"])
        self.assertAlmostEqual(fresh["gate"], 0.5)
        self.assertLess(fresh["score"], base["score"] * 0.6)
        self.assertGreater(old["score"], base["score"] * 0.9)

    def test_satellite_dapple_is_weighted_against_the_forecast(self):
        sky = cube_sky(high=checker())
        sat = {"fwd": {"low": None, "mid": None, "high": 0.0}, "over": {}, "anti": {}}
        full = s.score_hour(sky, self.az, 0.0, sat)["detail"]["fwd"]["high"][1]
        half = s.score_hour(sky, self.az, 0.0, sat, sat_weight=0.5)["detail"]["fwd"]["high"][1]
        none = s.score_hour(sky, self.az, 0.0, sat, sat_weight=0.0)["detail"]["fwd"]["high"][1]
        self.assertEqual(full, 0.0)
        self.assertAlmostEqual(half, none / 2.0)
        self.assertGreater(none, 0.0)


# ============================================ v1.1: infrared cloud-top texture
class TestInfraredTexture(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.az = s.sunset_azimuth(WASH[0], 2026, 11, 6)
        cls.cases = {
            "smooth": lambda b, d, k: 255.0 + 0.02 * k,
            "rough": lambda b, d, k: 255.0 + 1.5 * k,                      # neighbours differ by 3 K
            "medium": lambda b, d, k: 255.0 + 0.65 * k,                    # neighbours differ by 1.3 K
            "warm": lambda b, d, k: 285.0 + 1.5 * k,                       # warm tops: not read
            "near_only": lambda b, d, k: np.where(d <= 100, 255.0 + 1.5 * k, 285.0),
        }
        cls.out = {}
        for name, fn in cls.cases.items():
            bt = mocks.ir_field(WASH, fn)
            path = os.path.join(cls.tmp, name + ".nc")
            mocks.write_goes_file(path, "ABI-L2-CMIPC", bt=bt)
            ds, geom, np_ = s._open_dataset(path)
            cls.out[name] = s.satellite_ir_texture(WASH[0], WASH[1], cls.az, 140.0,
                                                   ds.variables["CMI"][:], geom, np_)
            ds.close()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def test_smooth_overcast_reads_smooth(self):
        for region in ("fwd", "over", "anti"):
            self.assertLess(self.out["smooth"][region]["roughness"], 0.2)
            self.assertEqual(self.out["smooth"][region]["texture"], 0.0)
            self.assertAlmostEqual(self.out["smooth"][region]["valid"], 1.0, places=2)

    def test_rippled_tops_read_rough(self):
        for region in ("fwd", "over", "anti"):
            self.assertAlmostEqual(self.out["rough"][region]["roughness"], 3.0, delta=0.15)
            self.assertEqual(self.out["rough"][region]["texture"], 1.0)

    def test_texture_is_linear_between_the_smooth_and_rough_marks(self):
        r = self.out["medium"]["over"]
        self.assertAlmostEqual(r["roughness"], 1.3, delta=0.1)
        self.assertAlmostEqual(r["texture"], (r["roughness"] - s.IR_SMOOTH_K) / (s.IR_ROUGH_K - s.IR_SMOOTH_K), places=6)
        self.assertTrue(0.3 < r["texture"] < 0.6)

    def test_warm_cloud_tops_are_not_read(self):
        self.assertTrue(all(v is None for v in self.out["warm"].values()))

    def test_valid_share_is_the_cold_cloud_area(self):
        near = self.out["near_only"]
        self.assertAlmostEqual(near["over"]["valid"], 1.0, places=2)          # the 45 km disc is all inside 100 km
        self.assertTrue(0.01 < near["fwd"]["valid"] < 0.25)                   # 100 km out of a ~400 km wedge

    def test_the_bonus_is_small_capped_and_scales_with_valid_area(self):
        sky = fake_sky(high=uniform(0.5))
        base = s.score_hour(sky, self.AZ)["regions"]["over"]
        full = s.score_hour(sky, self.AZ, ir={"over": {"texture": 1.0, "valid": 1.0}})["regions"]["over"]
        fifth = s.score_hour(sky, self.AZ, ir={"over": {"texture": 1.0, "valid": 0.2}})["regions"]["over"]
        none = s.score_hour(sky, self.AZ, ir={"over": {"texture": 0.0, "valid": 1.0}})["regions"]["over"]
        self.assertAlmostEqual(full / base, 1.0 + s.IR_MAX, places=6)
        self.assertAlmostEqual(fifth / base, 1.0 + 0.2 * s.IR_MAX, places=6)
        self.assertEqual(none, base)
        top = s.score_hour(fake_sky(mid=uniform(0.5), high=uniform(0.5)), self.AZ,
                           ir={"over": {"texture": 1.0, "valid": 1.0}})["regions"]["over"]
        self.assertLessEqual(top, 1.0)

    AZ = s.sunset_azimuth(WASH[0], 2026, 11, 6)

    def run_with(self, ir_fn, with_ir=True):
        d = tempfile.mkdtemp(dir=self.tmp)

        def f(b, dist):
            inside = (np.abs((b - self.AZ + 180) % 360 - 180) <= 40) & (dist > 5) & (dist <= 420)
            return np.where(inside, 3.0, 0.0), np.where(inside, 9500.0, np.nan)
        acm_ht = mocks.goes_field(WASH, self.AZ, f)
        ir = {(21, 36): mocks.ir_field(WASH, ir_fn)} if with_ir else None
        g = mocks.MockGoes(d, WASH, {(21, 36): acm_ht}, ir_fields=ir)
        sky = mocks.MockOpenMeteo(WASH, lambda b, dist, h: {"low": 0, "mid": 0, "high": 50, "precip": 0.0})
        logs = []
        res = s.run(*WASH, "2026-11-06", now_utc=datetime.datetime(2026, 11, 7, 18, 0, tzinfo=UTC),
                    cache_dir=os.path.join(d, "cache"), use_sat=True, fetch_json=sky,
                    goes_get_text=g.get_text, goes_get_file=g.get_file, log=logs.append)
        return res, g, logs

    def test_run_reads_band_13_not_another_band(self):
        res, g, _ = self.run_with(self.cases["rough"])
        self.assertTrue(any("C13" in k for k in g.fetched))
        self.assertFalse(any("C01" in k for k in g.fetched))
        self.assertEqual(res["satellite"]["ir"]["over"]["texture"], 1.0)        # band 1 would read 0 here
        self.assertIn("Infrared cloud-top roughness", s.format_report(res))

    def test_rougher_tops_score_higher_with_the_same_forecast(self):
        smooth, _, _ = self.run_with(self.cases["smooth"])
        rough, _, _ = self.run_with(self.cases["rough"])
        self.assertGreater(rough["mid_hour"]["decoration"], smooth["mid_hour"]["decoration"])
        self.assertLessEqual(rough["mid_hour"]["decoration"], smooth["mid_hour"]["decoration"] * (1 + s.IR_MAX) + 1e-9)

    def test_missing_infrared_does_not_cost_the_gate_or_the_dapple(self):
        res, _, logs = self.run_with(None, with_ir=False)
        self.assertIsNone(res["satellite"]["ir"])
        self.assertIsNotNone(res["satellite"]["dapple"])
        self.assertTrue(any("Infrared texture skipped" in str(x) for x in logs))
        self.assertNotIn("Infrared", s.format_report(res))


# ========================================================= v1.1: score breakdown
class TestBreakdown(unittest.TestCase):
    AZ = s.sunset_azimuth(WASH[0], 2026, 11, 6)

    def skies(self):
        yield "clear", fake_sky()
        yield "half everywhere", fake_sky(low=uniform(0.5), mid=uniform(0.5), high=uniform(0.5))
        yield "checker", fake_sky(mid=checker(), high=checker())
        yield "rain", fake_sky(high=uniform(0.4), precip=uniform(2.0))
        yield "partly blocked low bank", fake_sky(low=disc_grid(200.0, 0.8), high=uniform(0.4))
        yield "cube: elevated deck", cube_sky(low=disc_grid(480.0), heights={"low": (2300.0, 3200.0)})
        yield "cube: high deck", cube_sky(high=uniform(0.6), mid=disc_grid(150.0, 0.5))
        yield "cube: rain under deck", cube_sky(low=disc_grid(480.0, 0.7), precip=uniform(1.0),
                                                heights={"low": (2300.0, 3200.0)})

    def test_points_add_up_to_the_unrounded_score(self):
        for name, sky in self.skies():
            for elev in (0.0, 171.0):
                r = s.score_hour(sky, self.AZ, elev)
                exact = 100.0 * r["gate"] * (s.BASE + (1.0 - s.BASE) * r["decoration"])
                self.assertAlmostEqual(r["points"]["total"], exact, places=9, msg=name)
                self.assertEqual(round(exact), r["score"], msg=name)

    def test_what_is_possible_adds_to_100(self):
        bd = s.score_hour(fake_sky(), self.AZ)["points"]
        self.assertAlmostEqual(bd["floor"]["max"] + sum(r["max"] for r in bd["regions"].values()), 100.0)
        for reg in bd["regions"].values():
            self.assertAlmostEqual(sum(l["max"] for l in reg["layers"].values()), reg["max"])
        self.assertAlmostEqual(bd["regions"]["anti"]["max"], 75.0 * s.R_WEIGHT["anti"])      # 15 points

    def test_layers_add_up_to_their_region_and_never_exceed_it(self):
        for name, sky in self.skies():
            bd = s.score_hour(sky, self.AZ, 100.0)["points"]
            for reg in bd["regions"].values():
                self.assertAlmostEqual(sum(l["earned"] for l in reg["layers"].values()) + reg["ir"],
                                       reg["earned"], places=9, msg=name)
                self.assertLessEqual(reg["earned"], reg["max"] + 1e-9, msg=name)
                for l in reg["layers"].values():
                    self.assertLessEqual(l["earned"], l["max"] + 1e-9)

    def test_a_half_scoring_region_shows_half_its_points(self):
        # uniform 50% cloud in every layer: every region is worth exactly half (full sweet spot,
        # no texture) -- 7.5 of the opposite sky's 15 points, as in the example that motivated this
        r = s.score_hour(fake_sky(low=uniform(0.5), mid=uniform(0.5), high=uniform(0.5)), self.AZ)
        bd = r["points"]
        for name in ("fwd", "over", "anti"):
            self.assertAlmostEqual(bd["regions"][name]["earned"], 0.5 * bd["regions"][name]["max"], places=9)
        self.assertAlmostEqual(bd["regions"]["anti"]["earned"], 7.5)
        self.assertEqual(r["gate"], 1.0)
        self.assertAlmostEqual(bd["total"], 25.0 + 37.5)

    def test_clear_sky_earns_only_the_floor(self):
        bd = s.score_hour(fake_sky(), self.AZ)["points"]
        self.assertAlmostEqual(bd["total"], 25.0)
        self.assertEqual(bd["cloud_loss"], 0.0)
        self.assertEqual(bd["rain_loss"], 0.0)
        self.assertTrue(all(r["earned"] == 0.0 for r in bd["regions"].values()))

    def test_losses_are_split_between_cloud_and_rain(self):
        rain = s.score_hour(fake_sky(high=uniform(0.4), precip=uniform(2.0)), self.AZ)["points"]
        self.assertEqual(rain["cloud_loss"], 0.0)
        self.assertGreater(rain["rain_loss"], 0.0)
        pot = rain["floor"]["earned"] + sum(r["earned"] for r in rain["regions"].values())
        self.assertAlmostEqual(rain["rain_loss"], pot * (1 - s.RAIN_FACTOR))
        fog = s.score_hour(cube_sky(low=uniform(1.0), heights={"low": (0.0, 300.0)}), self.AZ)["points"]
        self.assertGreater(fog["cloud_loss"], 0.0)
        self.assertAlmostEqual(fog["total"], 0.0)
        mixed = s.score_hour(cube_sky(low=disc_grid(480.0, 0.7), precip=uniform(1.0),
                                      heights={"low": (2300.0, 3200.0)}), self.AZ)["points"]
        self.assertGreater(mixed["cloud_loss"], 0.0)
        self.assertGreater(mixed["rain_loss"], 0.0)

    def test_hours_are_averaged_leaf_by_leaf(self):
        a = s.score_hour(fake_sky(high=uniform(0.5)), self.AZ)["points"]
        b = s.score_hour(fake_sky(high=uniform(0.2)), self.AZ)["points"]
        m = s.average_points([a, b])
        self.assertAlmostEqual(m["total"], (a["total"] + b["total"]) / 2)
        self.assertAlmostEqual(m["regions"]["over"]["layers"]["high"]["earned"],
                               (a["regions"]["over"]["layers"]["high"]["earned"]
                                + b["regions"]["over"]["layers"]["high"]["earned"]) / 2)
        self.assertEqual(m["floor"]["max"], 25.0)

    def run_case(self, scenario, **kw):
        mock = mocks.MockOpenMeteo(WASH, scenario)
        tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, tmp, ignore_errors=True)
        return s.run(*WASH, "2026-11-06", now_utc=datetime.datetime(2026, 11, 7, 18, 0, tzinfo=UTC),
                     cache_dir=tmp, use_sat=False, fetch_json=mock, log=lambda *a: None, **kw)

    def test_run_breakdown_matches_the_headline_score(self):
        az = self.AZ
        for sc in (mocks.dappled_west(az), mocks.solid_west(az), mocks.clear_sky):
            res = self.run_case(sc)
            mean_total = sum(res["per_hour"][h]["points"]["total"] for h in res["hours"]) / len(res["hours"])
            self.assertAlmostEqual(res["breakdown"]["total"], mean_total)
            self.assertLess(abs(res["breakdown"]["total"] - res["score"]), 0.75)

    def test_report_shows_the_table_and_brief_hides_it(self):
        res = self.run_case(mocks.dappled_west(self.AZ))
        text = s.format_report(res)
        for needle in ("Score breakdown", "Sun visible (floor)", "Sunset direction", "Overhead",
                       "Opposite (eastern) sky", "high cloud", "Total", "/ 25.0"):
            self.assertIn(needle, text)
        self.assertNotIn("Score breakdown", s.format_report(res, brief=True))
        self.assertIn("SCORE: %d / 100" % res["score"], s.format_report(res, brief=True))

    def test_shortfalls_are_ranked_and_name_the_biggest_loss(self):
        res = self.run_case(mocks.clear_sky)
        line = [l for l in s.format_report(res).splitlines() if "Biggest shortfalls" in l][0]
        self.assertLess(line.index("sunset direction"), line.index("overhead"))     # 41 points beat 19
        self.assertLess(line.index("overhead"), line.index("opposite"))
        res = self.run_case(mocks.stratus_everywhere)
        text = s.format_report(res)
        self.assertIn("Sun hidden by cloud", text)
        self.assertIn("sun hidden by cloud (-", text)

    def test_infrared_bonus_gets_its_own_line(self):
        ir = TestInfraredTexture()
        TestInfraredTexture.setUpClass()
        try:
            ir.tmp = TestInfraredTexture.tmp
            res, _, _ = ir.run_with(ir.cases["rough"])
        finally:
            TestInfraredTexture.tearDownClass()
        self.assertIn("infrared texture bonus", s.format_report(res))
        self.assertGreater(res["breakdown"]["regions"]["over"]["ir"], 0.05)

    def test_command_line_brief_flag(self):
        tc = TestCommandLine()
        tc.setUp()
        try:
            code, text = tc.call(["41.4278", "-74.1654", "2026-11-06", "--no-sat"])
            self.assertIn("Score breakdown", text)
            code, text = tc.call(["41.4278", "-74.1654", "2026-11-06", "--no-sat", "--brief"])
            self.assertEqual(code, 0)
            self.assertNotIn("Score breakdown", text)
            self.assertIn("SCORE: 73 / 100", text)
        finally:
            tc.tearDown()


# ============================================ v1.1: the view from the ground
class TestGroundView(unittest.TestCase):
    """Forecast and satellite as cloud squares on one shared 3 km grid, drawn in perspective from the observer's
    eye over a flat plain; the same sky again in sunset colours."""

    N = s.GROUND_CELLS                                                 # the lattice is N x N squares of 3 km

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.az = s.sunset_azimuth(WASH[0], 2026, 11, 6)

        def pattern(kind):
            def f(b, d):
                acm = np.zeros(b.shape)
                ht = np.full(b.shape, np.nan)
                sun = (np.abs((b - cls.az + 180) % 360 - 180) <= 14) & (d > 5) & (d <= 125)
                if kind == "bank":
                    acm[sun], ht[sun] = 3, 800.0
                return acm, ht
            return f
        cls.fields = {k: mocks.goes_field(WASH, cls.az, pattern(k)) for k in ("clear", "bank")}

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def png_size(self, path):
        with open(path, "rb") as fh:
            head = fh.read(24)
        self.assertEqual(head[:8], b"\x89PNG\r\n\x1a\n")
        return int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big")

    def pixel(self, img, az, el, yaw=None):
        """Colour of the picture at compass bearing az and elevation angle el (header skipped)."""
        yaw = self.az if yaw is None else yaw
        col = int(round(img.shape[1] / 2.0 + s._wrap_deg(az - yaw) * s.GROUND_PPD))
        row = 46 + int(round((s.GROUND_EL_MAX - el) * s.GROUND_PPD))
        return img[row, col].astype(float)

    def toward(self, bearing_off, d):
        """East / north (km) of the point d km away, bearing_off degrees from the sunset direction."""
        b = math.radians(self.az + bearing_off)
        return d * math.sin(b), d * math.cos(b)

    # ---- geometry
    def test_elevation_angle_matches_the_sight_line_formula(self):
        got = s._elev_deg(np.array([1000.0]), np.array([100.0]), np)[0]
        self.assertAlmostEqual(got, s.apparent_elevation_deg(1000.0, 100.0), delta=0.01)
        self.assertGreater(s._elev_deg(np.array([5000.0]), np.array([0.5]), np)[0], 80.0)      # nearly overhead
        self.assertAlmostEqual(s._elev_deg(np.array([1000.0]), np.array([1.0]), np)[0], 45.0, delta=0.5)
        # curvature: the same height angle is lower far away; beyond the horizon it goes negative
        self.assertLess(s._elev_deg(np.array([1000.0]), np.array([400.0]), np)[0], 0.0)

    def test_wrap_deg(self):
        self.assertEqual(s._wrap_deg(190.0), -170.0)
        self.assertEqual(s._wrap_deg(-190.0), 170.0)
        self.assertEqual(s._wrap_deg(10.0), 10.0)

    # ---- the shared 3 km grid
    def test_ground_and_satellite_share_one_3_km_grid(self):
        self.assertEqual(s.GROUND_STEP_KM, s.SAT_STEP_KM)
        self.assertEqual(s.GROUND_STEP_KM, 3.0)
        self.assertEqual(s.SPACING_KM % s.GROUND_STEP_KM, 0)           # a forecast cell is a whole number of squares
        self.assertEqual(s.SPACING_KM // s.GROUND_STEP_KM, 10)
        self.assertEqual(self.N * s.GROUND_STEP_KM / 2.0, s.N * s.SPACING_KM)       # the lattice reaches the outermost cell centres

    def test_snap_rounds_to_the_nearest_grid_line(self):
        self.assertEqual(s._snap(1.4), 0.0)
        self.assertEqual(s._snap(1.6), 3.0)
        self.assertEqual(s._snap(-4.4), -3.0)
        self.assertEqual(s._snap(91.0), 90.0)
        self.assertEqual(s._snap(90.0), 90.0)

    def test_satellite_scene_squares_line_up_with_the_lattice(self):
        # build_sat_scene's sample axis is the lattice's square centres: (i - n/2 + 0.5) * 3 km
        n = 300
        axis = (np.arange(-n // 2, n // 2) + 0.5) * s.SAT_STEP_KM
        lat = s.new_lattice(np)
        centre = (np.arange(lat["n"]) - lat["n"] / 2.0 + 0.5) * lat["step"]
        self.assertTrue(np.allclose(axis, centre))
        self.assertEqual(float(centre[0]), -448.5)
        self.assertEqual(float(centre[-1]), 448.5)

    # ---- the forecast as boxes, and boxes as lattice squares
    def test_forecast_boxes_sit_where_the_cells_are(self):
        low = uniform(0.0)
        low[s.N - 2][s.N + 3] = 0.8                                    # 60 km north, 90 km east
        sky = cube_sky(low=low)
        boxes = s.forecast_boxes(sky, 100.0, np)
        self.assertEqual(boxes.shape, (1, s.GROUND_BOX_COLS))
        east, north, half, bottom, top, layer, cover = boxes[0]
        self.assertEqual((east, north, half), (90.0, 60.0, 15.0))
        self.assertEqual((east % 3.0, north % 3.0), (0.0, 0.0))        # on a 3 km line
        self.assertEqual((bottom, top), (400.0, 2400.0))               # sea-level heights less the 100 m eye
        self.assertEqual((layer, cover), (0, 0.8))
        self.assertEqual(len(s.forecast_boxes(fake_sky(), 0.0, np)), 0)

    def test_forecast_boxes_without_a_cube_use_the_usual_layer_heights(self):
        sky = fake_sky(mid=uniform(0.5))
        boxes = s.forecast_boxes(sky, 0.0, np)
        self.assertEqual(len(boxes), s.SIZE * s.SIZE)
        lo, hi = s.DEFAULT_LAYER_ASL_M["mid"]
        self.assertTrue(np.all(boxes[:, 3] == lo) and np.all(boxes[:, 4] == hi))
        self.assertTrue(np.all(boxes[:, 5] == 1))

    def test_barely_there_cloud_is_not_drawn(self):
        sky = cube_sky(high=uniform(0.04))
        self.assertEqual(len(s.forecast_boxes(sky, 0.0, np)), 0)

    def test_a_forecast_cell_becomes_a_10_by_10_plane_of_3_km_squares(self):
        lat = s.boxes_to_lattice(np.array([[90.0, 60.0, 15.0, 1500.0, 2500.0, 1, 0.7]]), np)
        cover = lat["cover"]["mid"]
        ni, ei = np.nonzero(cover > 0)
        self.assertEqual(len(ni), 100)
        self.assertEqual((ni.max() - ni.min() + 1, ei.max() - ei.min() + 1), (10, 10))
        centre = lambda i: (i - self.N / 2.0 + 0.5) * 3.0
        self.assertEqual((centre(ei.min()) - 1.5, centre(ei.max()) + 1.5), (75.0, 105.0))       # the cell's own edges
        self.assertEqual((centre(ni.min()) - 1.5, centre(ni.max()) + 1.5), (45.0, 75.0))
        self.assertTrue(np.all(cover[ni, ei] == 0.7))
        self.assertTrue(np.all(lat["bottom"]["mid"][ni, ei] == 1500.0) and np.all(lat["top"]["mid"][ni, ei] == 2500.0))
        self.assertEqual(float(cover.sum()), 70.0)                      # nothing outside the plane, nothing in other layers
        self.assertEqual(float(lat["cover"]["low"].sum() + lat["cover"]["high"].sum()), 0.0)

    def test_a_box_a_little_off_the_grid_lands_on_the_same_squares(self):
        a = s.boxes_to_lattice(np.array([[90.0, 60.0, 15.0, 0.0, 1000.0, 0, 1.0]]), np)
        b = s.boxes_to_lattice(np.array([[91.4, 61.0, 15.0, 0.0, 1000.0, 0, 1.0]]), np)
        self.assertTrue(np.array_equal(a["cover"]["low"], b["cover"]["low"]))

    def test_lattice_orientation_and_the_observer_on_a_corner(self):
        lat = s.boxes_to_lattice(np.array([[1.5, 1.5, 1.5, 0.0, 500.0, 0, 1.0],            # north-east of the observer
                                           [-1.5, -1.5, 1.5, 0.0, 500.0, 1, 1.0]]), np)    # south-west of the observer
        c = self.N // 2
        self.assertEqual(float(lat["cover"]["low"][c, c]), 1.0)                  # [north, east], north increasing
        self.assertEqual(float(lat["cover"]["mid"][c - 1, c - 1]), 1.0)
        self.assertEqual(float(lat["cover"]["low"].sum()), 1.0)

    def test_the_stronger_box_wins_where_boxes_overlap(self):
        lat = s.boxes_to_lattice(np.array([[0.0, 0.0, 15.0, 100.0, 200.0, 0, 0.4],
                                           [3.0, 3.0, 4.5, 300.0, 400.0, 0, 0.9],
                                           [0.0, 0.0, 15.0, 500.0, 600.0, 0, 0.2]]), np)
        c = self.N // 2
        self.assertEqual(float(lat["cover"]["low"][c, c]), 0.9)
        self.assertEqual(float(lat["bottom"]["low"][c, c]), 300.0)
        self.assertEqual(float(lat["cover"]["low"][c - 5, c - 5]), 0.4)
        self.assertEqual(float(lat["bottom"]["low"][c - 5, c - 5]), 100.0)

    def test_no_boxes_make_an_empty_lattice(self):
        lat = s.boxes_to_lattice(np.zeros((0, s.GROUND_BOX_COLS)), np)
        self.assertEqual(float(sum(lat["cover"][L].sum() for L in s.LAYERS)), 0.0)
        self.assertTrue(np.isnan(lat["top"]["low"]).all())

    # ---- the scan as squares
    def scan(self, code=1):
        """A scan the size of the lattice (stored north edge first, as the scan is), all one class."""
        return np.full((self.N, self.N), code, dtype=int), np.full((self.N, self.N), np.nan)

    def put(self, codes, heights, north_i, east_i, code, top):
        """Set lattice squares (north / east indices, north increasing) in a scan stored north edge first."""
        codes[self.N - 1 - north_i, east_i] = code
        heights[self.N - 1 - north_i, east_i] = top

    def scene(self, codes, heights, shifted=None):
        return {"step": 3.0, "reach": 450.0, "observed": (codes, heights), "shifted": shifted}

    def test_scene_cells_flip_the_scan_north_up_and_split_it_by_layer(self):
        codes, heights = self.scan()
        codes[0, 0], heights[0, 0] = 3, 5000.0                        # the scan's first pixel: its north-west corner
        codes[10, 10], heights[10, 10] = 4, 9500.0
        codes[20, 20] = 0                                             # not covered
        codes[30, 30] = 5                                             # cloud of unknown height
        cells = s.scene_cells(self.scene(codes, heights), "observed", np)
        self.assertEqual(float(cells["share"]["mid"][self.N - 1, 0]), 1.0)       # north-west is the last row, first column
        self.assertEqual(float(cells["top"]["mid"][self.N - 1, 0]), 5000.0)
        self.assertEqual(float(cells["share"]["mid"].sum()), 1.0)
        self.assertEqual(float(cells["share"]["high"][self.N - 1 - 10, 10]), 1.0)
        self.assertEqual(float(cells["top"]["high"][self.N - 1 - 10, 10]), 9500.0)
        self.assertEqual(float(cells["known"][self.N - 1 - 20, 20]), 0.0)
        self.assertEqual(float(cells["known"].sum()), self.N * self.N - 1)
        self.assertEqual(float(cells["nohgt"][self.N - 1 - 30, 30]), 1.0)
        self.assertTrue(np.isnan(cells["top"]["low"]).all())

    def cells_with(self, code, top, squares=((150, 150), (150, 151), (151, 150), (151, 151))):
        codes, heights = self.scan()
        for ni, ei in squares:
            self.put(codes, heights, ni, ei, code, top)
        return s.scene_cells(self.scene(codes, heights), "observed", np)

    # ---- forecast and satellite united
    W1 = {"total": 1.0, "unshifted": 1.0, "shifted": 0.0}

    def test_satellite_clear_overrules_a_forecast_cloud_in_proportion_to_its_weight(self):
        sky = cube_sky(low=uniform(0.6))
        clear = s.scene_cells(self.scene(*self.scan()), "observed", np)
        full = s.unified_boxes(sky, 0.0, clear, None, self.W1, np)
        self.assertEqual(len(full), 0)                                 # a fresh scan sees no cloud: none is drawn
        half = s.unified_boxes(sky, 0.0, clear, None, {"total": 0.5, "unshifted": 0.5, "shifted": 0.0}, np)
        self.assertGreater(len(half), 0)
        self.assertTrue(np.allclose(half[:, 6], 0.3))                  # half of the forecast's 0.6
        none = s.unified_boxes(sky, 0.0, clear, None, {"total": 0.0, "unshifted": 0.0, "shifted": 0.0}, np)
        self.assertTrue(np.allclose(none[:, 6], 0.6))                  # no weight: the forecast alone

    def test_unified_boxes_are_3_km_squares_on_the_lattice(self):
        sky = cube_sky(low=uniform(0.6))
        none = s.unified_boxes(sky, 0.0, self.cells_with(2, 800.0), None, {"total": 0.0}, np)
        self.assertTrue(np.all(none[:, 2] == 1.5))
        self.assertTrue(np.all((none[:, 0] - 1.5) % 3.0 == 0) and np.all((none[:, 1] - 1.5) % 3.0 == 0))

    def test_satellite_top_sets_the_box_and_the_slab_model_its_depth(self):
        sky = cube_sky(mid=uniform(0.0))
        boxes = s.unified_boxes(sky, 200.0, self.cells_with(3, 5200.0), None, self.W1, np)
        self.assertEqual(len(boxes), 4)                                # four squares of cloud
        east, north, half, bottom, top, layer, cover = boxes[0]
        self.assertEqual(layer, 1)
        self.assertAlmostEqual(top, 5000.0)                            # satellite top less the 200 m eye
        self.assertAlmostEqual(top - bottom, s.SAT_THICKNESS_M["mid"])
        self.assertAlmostEqual(cover, 1.0)
        self.assertEqual(half, 1.5)
        self.assertEqual(sorted(set((boxes[:, 0] * 2).astype(int).tolist())), [3, 9])     # east 1.5 and 4.5

    def test_forecast_cloud_under_a_higher_satellite_top_is_kept_but_only_that_much(self):
        # satellite: high cloud over 4 squares, clear elsewhere; forecast: low cloud 0.9 everywhere
        sky = cube_sky(low=uniform(0.9))
        cells = self.cells_with(4, 10000.0)
        boxes = s.unified_boxes(sky, 0.0, cells, None, self.W1, np)
        low = boxes[boxes[:, 5] == 0]
        # the squares under high cloud keep low cloud (the satellite cannot see it); the clear squares lose it
        self.assertEqual(len(low), 4)
        self.assertTrue(np.allclose(low[:, 6], 0.9))
        self.assertEqual(len(boxes[boxes[:, 5] == 2]), 4)              # and the high cloud itself
        # satellite alone cannot see beneath
        sat_only = s.unified_boxes(sky, 0.0, cells, None, self.W1, np, forecast=False)
        self.assertEqual(sorted(set(sat_only[:, 5].astype(int))), [2])

    def test_a_square_the_scan_does_not_cover_falls_back_to_the_forecast(self):
        sky = cube_sky(low=uniform(0.7))
        cells = s.scene_cells(self.scene(*self.scan(code=0)), "observed", np)         # no data anywhere
        boxes = s.unified_boxes(sky, 0.0, cells, None, self.W1, np)
        self.assertGreater(len(boxes), 0)
        self.assertTrue(np.allclose(boxes[:, 6], 0.7))

    def test_shifted_and_observed_scans_are_mixed_by_their_weights(self):
        sky = cube_sky()
        obs, shf = self.scan(), self.scan()
        for ni, ei in ((150, 150), (150, 151)):
            self.put(*obs, ni, ei, 3, 5000.0)
            self.put(*shf, ni, ei, 3, 4000.0)
        scene = self.scene(*obs, shifted=shf)
        boxes = s.unified_boxes(sky, 0.0, s.scene_cells(scene, "observed", np), s.scene_cells(scene, "shifted", np),
                                {"total": 1.0, "unshifted": 0.25, "shifted": 0.75}, np)
        self.assertEqual(len(boxes), 2)
        self.assertTrue(np.allclose(boxes[:, 4], 0.25 * 5000.0 + 0.75 * 4000.0))       # tops mixed by weight
        self.assertTrue(np.allclose(boxes[:, 6], 1.0))

    # ---- what the score expects to be lit
    def lattice_with(self, L, east, north, bottom, top, cover=1.0):
        lat = s.new_lattice(np)
        ie, ni = int(math.floor(east / 3.0)) + self.N // 2, int(math.floor(north / 3.0)) + self.N // 2
        lat["cover"][L][ni, ie], lat["bottom"][L][ni, ie], lat["top"][L][ni, ie] = cover, bottom, top
        return lat, (ni, ie)

    @staticmethod
    def detail(fwd=0.0, over=0.0, anti=0.0):
        return {r: {L: (0.5, 0.5, v) for L in s.LAYERS} for r, v in (("fwd", fwd), ("over", over), ("anti", anti))}

    def test_lit_cloud_gets_the_scores_own_decoration_times_the_gate(self):
        e, n = self.toward(0.0, 100.0)
        lat, at = self.lattice_with("mid", e, n, 6000.0, 8000.0)
        lit = s.sunset_lit(lat, self.az, 0.0, self.detail(fwd=0.6), 1.0, np)
        self.assertAlmostEqual(float(lit["mid"][at]), 0.6, places=6)
        half = s.sunset_lit(lat, self.az, 0.0, self.detail(fwd=0.6), 0.5, np)
        self.assertAlmostEqual(float(half["mid"][at]), 0.3, places=6)               # a half-hidden sun lights half as much
        shut = s.sunset_lit(lat, self.az, 0.0, self.detail(fwd=0.6), 0.0, np)
        self.assertEqual(float(shut["mid"][at]), 0.0)
        self.assertEqual(float(lit["low"].sum() + lit["high"].sum()), 0.0)          # only the layer that has cloud

    def test_cloud_at_the_suns_height_is_a_silhouette_and_straddling_cloud_counts_its_share(self):
        e, n = self.toward(0.0, 100.0)
        low, at = self.lattice_with("low", e, n, -100.0, 500.0)                       # tops out below the sun line
        out = s.sunset_lit(low, self.az, 300.0, self.detail(fwd=0.8), 1.0, np)
        self.assertEqual(float(out["low"][at]), 0.0)
        part, at = self.lattice_with("low", e, n, -300.0, 1200.0)                     # the sun line crosses it
        share = s.sunset_lit(part, self.az, 300.0, self.detail(fwd=0.8), 1.0, np)["low"][at]
        cx, cy = (np.array(at[1] - self.N // 2 + 0.5) * 3.0), (np.array(at[0] - self.N // 2 + 0.5) * 3.0)
        dist = np.array([float(np.hypot(cx, cy))])                                    # the square's own distance
        e_t, e_b = (s._elev_deg(np.array([z]), dist, np)[0] for z in (1200.0, -300.0))
        hi = s.SUN_REF_DEG + s.SUN_HALF_DEG
        self.assertAlmostEqual(float(share), 0.8 * (e_t - hi) / (e_t - e_b), places=3)
        self.assertTrue(0.0 < float(share) < 0.8)

    def test_only_the_three_scored_regions_are_lit(self):
        det = self.detail(fwd=0.7, over=0.5, anti=0.3)
        for off, d, want, region in ((0.0, 100.0, 0.7, "toward the sun"), (180.0, 100.0, 0.3, "away from it"),
                                     (90.0, 20.0, 0.5, "overhead"), (90.0, 100.0, 0.0, "off to the side"),
                                     (0.0, 20.0, 0.7, "overhead and in the sunset wedge: the larger of the two")):
            e, n = self.toward(off, d)
            lat, at = self.lattice_with("high", e, n, 7000.0, 9000.0)
            got = float(s.sunset_lit(lat, self.az, 0.0, det, 1.0, np)["high"][at])
            self.assertAlmostEqual(got, want, places=6, msg=region)

    def test_clear_squares_are_never_lit(self):
        e, n = self.toward(0.0, 100.0)
        lat, at = self.lattice_with("mid", e, n, 6000.0, 8000.0, cover=0.01)
        self.assertEqual(float(s.sunset_lit(lat, self.az, 0.0, self.detail(fwd=0.6), 1.0, np)["mid"][at]), 0.0)

    # ---- the picture
    def render(self, boxes, gate=0.8, sun_deg=s.GROUND_SUN_DEG, yaw=None, elev=0.0, style="data", lit=None):
        arr = np.array(boxes, dtype=float).reshape(-1, s.GROUND_BOX_COLS)
        lattice = s.boxes_to_lattice(arr, np)
        if lit == "all":
            lit = {L: (lattice["cover"][L] >= s.GROUND_MIN_COVER).astype(float) for L in s.LAYERS}
        elif lit == "none":
            lit = {L: np.zeros((self.N, self.N)) for L in s.LAYERS}
        return s.render_ground_view(arr, self.az if yaw is None else yaw, elev, self.az, sun_deg, gate,
                                    "TITLE", "SUB", [[((90, 90, 100), "KEY")]], np, style=style, lattice=lattice, lit=lit)

    def test_picture_size_and_a_clear_sky(self):
        img = self.render([])
        w = int(round(s.GROUND_HFOV * s.GROUND_PPD))
        h = int(round((s.GROUND_EL_MAX - s.GROUND_EL_MIN) * s.GROUND_PPD))
        self.assertEqual(img.shape, (46 + h + 26 + 25, w, 3))
        zenith, near_horizon = self.pixel(img, self.az - 40, 30), self.pixel(img, self.az - 40, 2)
        self.assertGreater(near_horizon.sum(), zenith.sum())           # a brighter sky toward the horizon

    def test_the_ground_is_a_flat_plain_below_the_horizon(self):
        for style in ("data", "sunset"):
            img = self.render([], style=style, elev=300.0)
            near = np.array(s.GROUND_STYLES[style]["ground_near"], dtype=float)
            dip = s.horizon_dip_deg(300.0)
            below = np.median(self.pixel(img, self.az - 40, -4.5).reshape(1, 3), axis=0)
            self.assertTrue(np.all(np.abs(below - near) < 45), "%s plain %s" % (style, below))
            # the sky above the horizon is not the ground's colour, and the plain gets hazier toward the horizon
            sky = self.pixel(img, self.az - 40, 5.0)
            self.assertGreater(abs(sky - near).sum(), 60)
            haze = np.array(s.GROUND_STYLES[style]["sky_horizon"], dtype=float)
            far = self.pixel(img, self.az - 40, -dip - 0.25)
            self.assertLess(abs(far - haze).sum(), abs(below - haze).sum())

    def test_the_plain_is_gridded_every_3_km(self):
        st = s.GROUND_STYLES["data"]
        ppd = s.GROUND_PPD
        w, h = int(round(s.GROUND_HFOV * ppd)), int(round((s.GROUND_EL_MAX - s.GROUND_EL_MIN) * ppd))
        canvas = np.full((h, w, 3), 60.0)
        yaw, eye = 10.0, 300.0
        gy = s._ground_plain(canvas, yaw, ppd, eye, 0.0, None, st, np)
        self.assertEqual(gy, int(math.ceil((s.GROUND_EL_MAX + s.horizon_dip_deg(eye)) * ppd - 0.5)))
        col = canvas[gy + 1:, w // 2, 1]
        med = np.array([np.median(col[max(i - 4, 0):i + 5]) for i in range(len(col))])
        rows = np.nonzero(col - med > 10)[0] + gy + 1
        ds = np.linspace(0.05, 80.0, 40000)
        eg = -np.degrees(np.arctan2(eye, ds * 1000.0)) - np.degrees((1.0 - s.REFRACTION_K) * ds / (2.0 * s.EARTH_RADIUS_KM))
        hits = []
        for r in rows:
            d = float(ds[np.argmin(abs(eg - (s.GROUND_EL_MAX - (r + 0.5) / ppd)))])
            if 5.0 <= d <= 13.0:
                north, east = d * math.cos(math.radians(yaw)), d * math.sin(math.radians(yaw))
                off = min(abs(north - 3.0 * round(north / 3.0)), abs(east - 3.0 * round(east / 3.0)))
                self.assertLess(off, 0.4, "a line seen %.2f km out is not on the grid" % d)
                hits.append(round(north / 3.0))
        self.assertGreaterEqual(len(set(hits)), 3)                      # several different grid lines are drawn

    def test_sun_is_where_the_sun_is_and_its_shade_follows_the_gate(self):
        bright, dull = self.render([], gate=1.0), self.render([], gate=0.0)
        a = self.pixel(bright, self.az, s.GROUND_SUN_DEG)
        b = self.pixel(dull, self.az, s.GROUND_SUN_DEG)
        self.assertGreater(a.sum(), b.sum() + 200)
        self.assertGreater(a[0], 200)
        self.assertLess(b[2], 100)                                     # hidden sun: a dull red, not white
        off = self.pixel(bright, self.az + 40, s.GROUND_SUN_DEG)
        self.assertLess(off.sum(), a.sum() - 250)

    def test_a_box_appears_at_its_bearing_and_elevation(self):
        east, north = self.toward(0.0, 100.0)
        # a mid-cloud box 100 km out toward the sun, 3 to 5 km up
        e_bot = s.apparent_elevation_deg(3000.0, 100.0)
        e_top = s.apparent_elevation_deg(5000.0, 100.0)
        img = self.render([[east, north, 15.0, 3000.0, 5000.0, 1, 1.0]], gate=None, sun_deg=20.0)
        inside = self.pixel(img, self.az, 0.5 * (e_bot + e_top))
        outside_up = self.pixel(img, self.az, e_top + 3.0)
        outside_side = self.pixel(img, self.az + 25.0, 0.5 * (e_bot + e_top))
        self.assertGreater(inside[0], outside_up[0] + 40)              # amber in the box ...
        self.assertGreater(inside[0], inside[2] + 40)                  # ... red over blue
        self.assertLess(abs(outside_up[0] - outside_side[0]), 60)      # and sky outside it

    def test_the_cloud_stays_where_the_grid_puts_it(self):
        # the elevation of a square is the geometry of its own height and distance, not an eyeballed hull:
        # a square 60 km out from 1 to 2 km up covers exactly the rows between those two angles at its edges
        east, north = self.toward(0.0, 60.0)
        img = self.render([[s._snap(east), s._snap(north), 1.5, 1000.0, 2000.0, 1, 1.0]], gate=None, sun_deg=25.0)
        clear = self.render([], gate=None, sun_deg=25.0)
        diff = np.abs(img[46:46 + 518].astype(float) - clear[46:46 + 518].astype(float)).sum(axis=2)
        col = int(round(img.shape[1] / 2.0 + 0 * s.GROUND_PPD))
        near = math.hypot(s._snap(east), s._snap(north))
        top = s.apparent_elevation_deg(2000.0, near - 1.5)
        bottom = s.apparent_elevation_deg(1000.0, near + 1.5)
        rows = np.nonzero(diff[:, col - 12:col + 12].max(axis=1) > 30)[0]
        self.assertGreater(len(rows), 3)
        self.assertLessEqual(abs(s.GROUND_EL_MAX - rows.min() / s.GROUND_PPD - top), 0.35)
        self.assertLessEqual(abs(s.GROUND_EL_MAX - (rows.max() + 1) / s.GROUND_PPD - bottom), 0.35)

    def test_layers_use_their_own_colours(self):
        east, north = self.toward(0.0, 80.0)
        for li, check in ((0, lambda p: p[2] > p[0] + 30), (1, lambda p: p[0] > p[2] + 40), (2, lambda p: p[0] > p[1] + 30)):
            img = self.render([[east, north, 21.0, 1000.0, 8000.0, li, 1.0]], gate=None, sun_deg=25.0)
            self.assertTrue(check(self.pixel(img, self.az, 3.0)), "layer %d" % li)

    def test_cover_sets_the_opacity(self):
        east, north = self.toward(0.0, 80.0)
        thin = self.render([[east, north, 21.0, 1000.0, 8000.0, 1, 0.1]], gate=None, sun_deg=25.0)
        thick = self.render([[east, north, 21.0, 1000.0, 8000.0, 1, 1.0]], gate=None, sun_deg=25.0)
        clear = self.render([], gate=None, sun_deg=25.0)
        p0, p1, p2 = (self.pixel(i, self.az, 3.0)[0] for i in (clear, thin, thick))
        self.assertLess(p0, p1)
        self.assertLess(p1, p2)

    def test_more_squares_in_a_line_do_not_pile_up_into_solid_cloud(self):
        east, north = self.toward(0.0, 80.0)
        one = self.render([[s._snap(east), s._snap(north), 1.5, 1000.0, 8000.0, 1, 0.5]], gate=None, sun_deg=25.0)
        many = self.render([[s._snap(east), s._snap(north), 30.0, 1000.0, 8000.0, 1, 0.5]], gate=None, sun_deg=25.0)
        a, b = self.pixel(one, self.az, 3.0)[0], self.pixel(many, self.az, 3.0)[0]
        self.assertGreater(b, a - 1)
        self.assertLess(b, a + 12)                                     # twenty squares deep, still one square's opacity

    def test_cloud_beyond_the_curve_of_the_earth_is_hidden_by_the_ground(self):
        d = 440.0                                                      # a 1 km deep low cloud 440 km away is below the horizon
        e, n = self.toward(0.0, d)
        far = [[s._snap(e), s._snap(n), 15.0, 300.0, 1300.0, 0, 1.0]]
        img = self.render(far, gate=None, sun_deg=25.0)
        clear = self.render([], gate=None, sun_deg=25.0)
        self.assertTrue(np.array_equal(img[46:], clear[46:]))
        e, n = self.toward(0.0, 100.0)
        near = [[s._snap(e), s._snap(n), 15.0, 300.0, 1300.0, 0, 1.0]]
        self.assertFalse(np.array_equal(self.render(near, gate=None, sun_deg=25.0)[46:], clear[46:]))

    def test_an_overhead_deck_closes_the_sky_above_its_underside(self):
        deck = [[0.0, 0.0, 15.0, 1500.0, 3000.0, 0, 1.0]]               # the observer's own cell
        img = self.render(deck, gate=None, sun_deg=25.0)
        clear = self.render([], gate=None, sun_deg=25.0)
        high = self.pixel(img, self.az, 28.0)
        self.assertGreater(high[2], self.pixel(clear, self.az, 28.0)[2] + 30)       # cloud at 28 degrees ...
        low = self.pixel(img, self.az, 1.0)
        self.assertLess(abs(low.sum() - self.pixel(clear, self.az, 1.0).sum()), 15)  # ... none under its edge at 1 degree
        # a deck lower than the eye (the observer above it) draws nothing here
        under = self.render([[0.0, 0.0, 15.0, -800.0, -100.0, 0, 1.0]], gate=None, sun_deg=25.0)
        self.assertTrue(np.array_equal(under[46:], clear[46:]))

    def test_the_view_turns_with_the_yaw(self):
        e, n = self.toward(0.0, 80.0)
        box = [[s._snap(e), s._snap(n), 21.0, 1000.0, 8000.0, 1, 1.0]]
        ahead = self.render(box, gate=None, sun_deg=25.0)
        behind = self.render(box, gate=None, sun_deg=25.0, yaw=(self.az + 180.0) % 360.0)
        clear = self.render([], gate=None, sun_deg=25.0, yaw=(self.az + 180.0) % 360.0)
        self.assertTrue(np.array_equal(behind[46:], clear[46:]))
        self.assertFalse(np.array_equal(ahead[46:], self.render([], gate=None, sun_deg=25.0)[46:]))

    def test_the_grid_is_drawn_on_the_cloud(self):
        # a plane of 10 x 10 squares shows crisscrossing 3 km lines on its underside; a lone square only its own edges
        h, w = int(round((s.GROUND_EL_MAX - s.GROUND_EL_MIN) * s.GROUND_PPD)), int(round(s.GROUND_HFOV * s.GROUND_PPD))
        e, n = self.toward(0.0, 40.0)
        plane = s.boxes_to_lattice(np.array([[s._snap(e), s._snap(n), 15.0, 1000.0, 2000.0, 1, 1.0]]), np)
        lone = s.boxes_to_lattice(np.array([[s._snap(e), s._snap(n), 1.5, 1000.0, 2000.0, 1, 1.0]]), np)
        args = (self.az, s.GROUND_PPD, w, h, s.GROUND_HFOV, np)
        a = s._cloud_lines(plane["cover"]["mid"], plane["bottom"]["mid"], plane["top"]["mid"], *args)
        b = s._cloud_lines(lone["cover"]["mid"], lone["bottom"]["mid"], lone["top"]["mid"], *args)
        self.assertGreater(float(b.sum()), 0.0)
        self.assertGreater(float(a.sum()), 4.0 * float(b.sum()))
        none = s.boxes_to_lattice(np.zeros((0, s.GROUND_BOX_COLS)), np)
        self.assertEqual(float(s._cloud_lines(none["cover"]["mid"], none["bottom"]["mid"], none["top"]["mid"], *args).sum()), 0.0)

    def test_only_cloud_with_substance_gets_a_border(self):
        # none for wisps, a half border between, the full border for substantial cloud; high cloud has to be thicker
        bw = lambda cover, layer: float(s.border_weight(cover, layer, np))
        for cover, low, high in ((0.05, 0.0, 0.0), (0.10, 0.0, 0.0), (0.25, 0.5, 0.0), (0.45, 1.0, 0.5), (0.75, 1.0, 1.0), (1.0, 1.0, 1.0)):
            self.assertAlmostEqual(bw(cover, "low"), low, msg=cover)
            self.assertAlmostEqual(bw(cover, "mid"), low, msg=cover)
            self.assertAlmostEqual(bw(cover, "high"), high, msg=cover)
        # the grid lines follow it
        h, w = int(round((s.GROUND_EL_MAX - s.GROUND_EL_MIN) * s.GROUND_PPD)), int(round(s.GROUND_HFOV * s.GROUND_PPD))
        e, n = self.toward(0.0, 40.0)
        args = (self.az, s.GROUND_PPD, w, h, s.GROUND_HFOV, np)

        def lines(cover, layer):
            box = np.array([[s._snap(e), s._snap(n), 15.0, 1000.0, 2000.0, 1, cover]])
            lat = s.boxes_to_lattice(box, np)
            return s._cloud_lines(lat["cover"]["mid"], lat["bottom"]["mid"], lat["top"]["mid"], *args, layer=layer)
        self.assertEqual(float(lines(0.10, "mid").sum()), 0.0)                       # a wisp: no grid
        self.assertEqual(float(lines(0.30, "high").sum()), 0.0)                      # thin high cloud needs more
        self.assertAlmostEqual(float(lines(0.25, "mid").max()), 0.5)                 # in between: fainter lines
        self.assertAlmostEqual(float(lines(0.90, "mid").max()), 1.0)
        self.assertGreater(float(lines(0.90, "mid").sum()), 0.0)
        self.assertGreater(float(lines(0.10, None).sum()), 0.0)                      # no layer named: the old behaviour
        # and the picture: thin cloud is still drawn, but without its outline and grid
        thin = [[s._snap(e), s._snap(n), 15.0, 1000.0, 2000.0, 1, 0.10]]
        img = self.render(thin, gate=None, sun_deg=25.0)
        self.assertFalse(np.array_equal(img[46:], self.render([], gate=None, sun_deg=25.0)[46:]))
        saved = dict(s.GROUND_BORDER_STEPS)
        try:
            s.GROUND_BORDER_STEPS = {k: (0, 1) for k in saved}                       # let every cloud have a border
            bordered = self.render(thin, gate=None, sun_deg=25.0)
        finally:
            s.GROUND_BORDER_STEPS = saved
        self.assertFalse(np.array_equal(img[46:], bordered[46:]))

    def test_axis_labels_and_title_are_drawn(self):
        img = self.render([])
        self.assertGreater(int((img[:46] > 128).sum()), 300)            # header text
        self.assertGreater(int((img[-30:] > 100).sum()), 100)           # legend

    # ---- the sunset colours
    def test_the_lit_ramp_goes_pale_between_grey_and_the_hue(self):
        grey, hue = s._GREY["mid"], s.GROUND_STYLES["sunset"]["cloud"]["mid"][1]
        self.assertTrue(np.allclose(s._lit_shade(grey, hue, 0.0, np), grey))
        self.assertTrue(np.allclose(s._lit_shade(grey, hue, 1.0, np), hue))
        mid = s._lit_shade(grey, hue, 0.5, np)
        self.assertGreater(mid.sum(), sum(grey))                        # lighter than the grey ...
        self.assertGreater(mid.sum(), sum(hue))                         # ... and than the hue: pale, not brown

    def test_the_sunset_sky_is_blue_cloud_grey_and_lit_cloud_a_sunset_hue(self):
        east, north = self.toward(0.0, 80.0)
        box = [[s._snap(east), s._snap(north), 21.0, 1000.0, 8000.0, 1, 1.0]]
        grey = self.render(box, gate=1.0, sun_deg=25.0, style="sunset", lit="none")
        hued = self.render(box, gate=1.0, sun_deg=25.0, style="sunset", lit="all")
        sky = self.pixel(grey, self.az + 30.0, 12.0)
        self.assertGreater(sky[2], sky[0] + 60)                         # the sky is blue
        cloud = self.pixel(grey, self.az, 3.0)
        self.assertLess(cloud[2] - cloud[0], sky[2] - sky[0] - 30)      # unlit cloud: monotone grey, not the sky's blue
        self.assertLess(abs(cloud[0] - cloud[1]), 30)
        lit = self.pixel(hued, self.az, 3.0)
        self.assertGreater(lit[0], lit[2] + 60)                         # lit cloud: a red-orange hue
        self.assertGreater(lit[0], cloud[0] + 40)

    def test_a_little_decoration_stays_grey(self):
        east, north = self.toward(0.0, 80.0)
        box = np.array([[s._snap(east), s._snap(north), 21.0, 1000.0, 8000.0, 1, 1.0]])
        lattice = s.boxes_to_lattice(box, np)
        faint = {L: np.where(lattice["cover"][L] > 0, s.GROUND_LIT_FLOOR * 0.8, 0.0) for L in s.LAYERS}
        none = {L: np.zeros((self.N, self.N)) for L in s.LAYERS}
        a = self.render(box, gate=1.0, sun_deg=25.0, style="sunset", lit=faint)
        b = self.render(box, gate=1.0, sun_deg=25.0, style="sunset", lit=none)
        self.assertTrue(np.array_equal(a, b))

    def test_the_sunset_sun_is_a_deep_red_orange(self):
        img = self.render([], gate=1.0, style="sunset")
        sun = self.pixel(img, self.az, s.GROUND_SUN_DEG)
        self.assertGreater(sun[0], 200)
        self.assertLess(sun[1], 110)
        self.assertLess(sun[2], 60)
        data = self.pixel(self.render([], gate=1.0), self.az, s.GROUND_SUN_DEG)
        self.assertGreater(data[1], 190)                                # the analysis view keeps its pale-yellow sun

    def test_the_sunset_plain_is_green_and_distinct_from_the_data_view_plain(self):
        sunset = self.pixel(self.render([], style="sunset", elev=300.0), self.az - 40, -4.5)
        data = self.pixel(self.render([], elev=300.0), self.az - 40, -4.5)
        self.assertGreater(sunset[1], sunset[0] + 10)
        self.assertGreater(sunset[1], sunset[2] + 10)
        self.assertFalse(np.array_equal(sunset, data))

    # ---- the files
    def goes(self, kind):
        d = tempfile.mkdtemp(dir=self.tmp)
        return mocks.MockGoes(d, WASH, {(20, 36): self.fields[kind]}), d

    def test_forecast_only_view_without_a_scan(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        sky = cube_sky(low=uniform(0.5))
        paths = s.write_ground_views(out, *WASH, self.az, 140.0, sky, "17:00 LOCAL", "NOAA GFS", 3.0, 0.7, None,
                                     detail=self.detail(fwd=0.5, over=0.5, anti=0.5), log=lambda *a: None)
        self.assertEqual(paths, [os.path.join(out, s.GROUND_FILE), os.path.join(out, s.GROUND_SUNSET_FILE)])
        w, h = self.png_size(paths[0])
        self.assertEqual(w, int(round(s.GROUND_HFOV * s.GROUND_PPD)))
        self.assertEqual(self.png_size(paths[1]), (w, h))
        self.assertFalse(os.path.exists(os.path.join(out, s.MASK_DIR, "Ground_Satellite.png")))

    def test_the_sunset_view_needs_the_scores_detail(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        paths = s.write_ground_views(out, *WASH, self.az, 140.0, cube_sky(low=uniform(0.5)), "17:00 LOCAL", "NOAA GFS",
                                     3.0, 0.7, None, log=lambda *a: None)
        self.assertEqual(paths, [os.path.join(out, s.GROUND_FILE)])

    def run_view(self, kind, out, ground=True, now=None):
        g, d = self.goes(kind)
        ncss = mocks.MockNcss(WASH, mocks.bank_at(self.az, near=40, far=200, layer="low"))
        now = now or datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        logs = []
        res = s.run(*WASH, "2026-11-06", now_utc=now, cache_dir=os.path.join(d, "cache"), use_sat=True,
                    fetch_file=ncss, goes_get_text=g.get_text, goes_get_file=g.get_file, log=logs.append,
                    mask_dir=out, ground_view=ground)
        return res, logs

    def test_a_run_writes_the_united_view_the_sunset_view_and_the_comparison_views(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        res, logs = self.run_view("bank", out)
        self.assertIsNotNone(res["satellite"])
        self.png_size(os.path.join(out, s.GROUND_FILE))
        self.assertEqual(self.png_size(os.path.join(out, s.GROUND_SUNSET_FILE)), self.png_size(os.path.join(out, s.GROUND_FILE)))
        names = os.listdir(os.path.join(out, s.MASK_DIR))
        for want in ("Ground_Forecast.png", "Ground_Satellite.png", "Ground_Opposite.png"):
            self.assertIn(want, names)
        self.assertFalse(any(n.endswith(".tmp") for n in names))
        self.assertTrue(any("Ground view pictures:" in str(m) for m in logs))

    def test_the_united_view_shows_the_satellite_bank_the_forecast_alone_does_not_have(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        self.run_view("bank", out)
        try:
            from PIL import Image
        except ImportError:
            self.skipTest("Pillow not installed (only this test reads the picture back)")
        united = np.array(Image.open(os.path.join(out, s.GROUND_FILE)).convert("RGB")).astype(float)
        sat_only = np.array(Image.open(os.path.join(out, s.MASK_DIR, "Ground_Satellite.png")).convert("RGB")).astype(float)
        # the satellite's low bank (5-125 km toward the sun, tops at 800 m): blue just above the horizon
        probe = self.pixel(sat_only, self.az + 8, 0.7)
        sky = self.pixel(sat_only, self.az + 40, 0.7)
        self.assertGreater(probe[2] - probe[0], sky[2] - sky[0] + 20)
        self.assertEqual(united.shape[1], sat_only.shape[1])

    def test_no_ground_flag_removes_the_old_pictures_and_skips_new_ones(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        self.run_view("bank", out)
        self.assertTrue(os.path.exists(os.path.join(out, s.GROUND_FILE)))
        self.assertTrue(os.path.exists(os.path.join(out, s.GROUND_SUNSET_FILE)))
        self.run_view("bank", out, ground=False)
        self.assertFalse(os.path.exists(os.path.join(out, s.GROUND_FILE)))
        self.assertFalse(os.path.exists(os.path.join(out, s.GROUND_SUNSET_FILE)))
        self.assertEqual([n for n in os.listdir(os.path.join(out, s.MASK_DIR)) if n.startswith("Ground_")], [])
        self.assertTrue(os.path.exists(os.path.join(out, s.MASK_FILE)))        # the satellite pictures stay

    def test_ground_pictures_survive_clearing_the_satellite_ones(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        self.run_view("bank", out)
        s.clear_masks(out, log=lambda *a: None)
        self.assertTrue(os.path.exists(os.path.join(out, s.MASK_DIR, "Ground_Forecast.png")))
        self.assertFalse(os.path.exists(os.path.join(out, s.MASK_FILE)))
        s.clear_ground_views(out)
        self.assertFalse(os.path.exists(os.path.join(out, s.GROUND_FILE)))
        self.assertFalse(os.path.exists(os.path.join(out, s.GROUND_SUNSET_FILE)))

    def test_run_without_a_scan_gives_the_forecast_view(self):
        out = tempfile.mkdtemp(dir=self.tmp)
        ncss = mocks.MockNcss(WASH, mocks.bank_at(self.az, near=40, far=200, layer="low"))
        now = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        s.run(*WASH, "2026-11-06", now_utc=now, cache_dir=os.path.join(out, "cache"), use_sat=False,
              fetch_file=ncss, log=lambda *a: None, mask_dir=out)
        self.png_size(os.path.join(out, s.GROUND_FILE))
        self.png_size(os.path.join(out, s.GROUND_SUNSET_FILE))
        self.assertFalse(os.path.exists(os.path.join(out, s.MASK_DIR, "Ground_Satellite.png")))

    def test_command_line_flag(self):
        tc = TestCommandLine()
        tc.setUp()
        try:
            seen = {}
            real = s.run

            def spy(*a, **kw):
                seen.update(kw)
                return real(*a, **kw)
            s.run = spy
            try:
                tc.call(["41.4278", "-74.1654", "2026-11-06", "--no-sat", "--no-ground"])
                self.assertFalse(seen["ground_view"])
                tc.call(["41.4278", "-74.1654", "2026-11-06", "--no-sat"])
                self.assertTrue(seen["ground_view"])
            finally:
                s.run = real
        finally:
            tc.tearDown()
