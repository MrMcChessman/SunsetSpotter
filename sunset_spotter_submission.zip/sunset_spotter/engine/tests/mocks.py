"""Offline stand-ins for Open-Meteo and the GOES bucket.

They are deliberately built from *independent* geometry (spherical haversine
bearings, a real geostationary projection from pyproj) so that a mistake in
sunset_v1_1's flat-map or scan-angle code cannot hide by being self-consistent.
"""
import datetime
import math
import os
import shutil
import urllib.parse

import numpy as np

R_EARTH = 6371.0


# ---------------------------------------------------- independent geometry
def bearing_dist_km(lat0, lon0, lat, lon):
    """Great-circle initial bearing (deg from north) and distance (km)."""
    p1, p2 = math.radians(lat0), math.radians(lat)
    dl = math.radians(lon - lon0)
    a = math.sin((p2 - p1) / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    dist = 2 * R_EARTH * math.asin(math.sqrt(a))
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0, dist


def bearing_dist_km_np(lat0, lon0, lat, lon):
    p1, p2 = np.radians(lat0), np.radians(lat)
    dl = np.radians(lon - lon0)
    a = np.sin((p2 - p1) / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    dist = 2 * R_EARTH * np.arcsin(np.sqrt(np.clip(a, 0, 1)))
    y = np.sin(dl) * np.cos(p2)
    x = np.cos(p1) * np.sin(p2) - np.sin(p1) * np.cos(p2) * np.cos(dl)
    return (np.degrees(np.arctan2(y, x)) + 360.0) % 360.0, dist


def angdiff(a, b):
    return abs((a - b + 180.0) % 360.0 - 180.0)


# ------------------------------------------------------------ sky scenarios
# A scenario is a function (bearing_deg, dist_km, hour) -> dict of
# percentages {'low','mid','high'} plus 'precip' in mm.
def clear_sky(b, d, h):
    return {"low": 0, "mid": 0, "high": 0, "precip": 0.0}


def bank_at(bearing, half=25, near=0, far=400, layer="low", pct=100):
    """A solid cloud bank covering a sector: `layer` at `pct` percent."""
    def f(b, d, h):
        out = {"low": 0, "mid": 0, "high": 0, "precip": 0.0}
        if angdiff(b, bearing) <= half and near <= d <= far:
            out[layer] = pct
        return out
    return f


def _noise(east, north, seed=0.0):
    """Smooth deterministic noise in [-1, 1] with ~50-60 km structure."""
    return (math.sin(east / 21.0 + 1.3 + seed) * math.sin(north / 17.0 + 0.4 - seed)
            * 0.7 + math.sin((east + north) / 14.0 + 2.1 + 2 * seed) * 0.5
            + math.sin((east - 1.3 * north) / 19.0 - 0.6) * 0.3) / 1.5


def dappled_west(az, base_pct=15):
    """Broken, dappled mid/high cloud to the west (around the sunset
    direction), clear low layer, thin streaks in the east."""
    def f(b, d, h):
        e, n = d * math.sin(math.radians(b)), d * math.cos(math.radians(b))
        w = max(0.0, 1.0 - angdiff(b, az) / 70.0)           # strongest toward the sun
        high = 50 + 55 * _noise(e, n, 0.0) * w + base_pct * (1 - w)
        mid = 45 + 50 * _noise(e, n, 1.7) * w
        return {"low": 8, "mid": max(0, min(100, mid)),
                "high": max(0, min(100, high)), "precip": 0.0}
    return f


def solid_west(az):
    """Same overall amount of cloud as dappled_west but smooth and solid
    (no gaps): 50% everywhere in the west, 0 elsewhere."""
    def f(b, d, h):
        if angdiff(b, az) <= 70:
            return {"low": 8, "mid": 52, "high": 52, "precip": 0.0}
        return {"low": 8, "mid": 0, "high": 0, "precip": 0.0}
    return f


def stratus_everywhere(b, d, h):
    return {"low": 96, "mid": 30, "high": 40, "precip": 0.0}


# --------------------------------------------------------- mock Open-Meteo
class MockOpenMeteo:
    """Callable fetch_json(url) that answers like the documented Open-Meteo
    multi-location reply: a list with one dict per place, in request order."""

    def __init__(self, center, scenario, elevation_fn=None, day="2026-11-06"):
        self.center = center
        self.scenario = scenario
        self.elevation_fn = elevation_fn or (lambda lat, lon: 140.0)
        self.day = day
        self.calls = []
        self.drop_values = False

    def __call__(self, url):
        self.calls.append(url)
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        lats = [float(x) for x in q["latitude"][0].split(",")]
        lons = [float(x) for x in q["longitude"][0].split(",")]
        assert len(lats) == len(lons) <= 1000
        assert len(url) < 8000, "URL too long for a typical server"
        assert q["timezone"][0] == "America/New_York"
        day = q["start_date"][0]
        assert q["end_date"][0] == day
        for name in ("cloud_cover_low", "cloud_cover_mid", "cloud_cover_high", "precipitation"):
            assert name in q["hourly"][0].split(",")
        out = []
        for lat, lon in zip(lats, lons):
            b, d = bearing_dist_km(self.center[0], self.center[1], lat, lon)
            hourly = {"time": ["%sT%02d:00" % (day, h) for h in range(24)],
                      "cloud_cover_low": [], "cloud_cover_mid": [],
                      "cloud_cover_high": [], "precipitation": []}
            for h in range(24):
                s = self.scenario(b, d, h)
                hourly["cloud_cover_low"].append(s["low"])
                hourly["cloud_cover_mid"].append(s["mid"])
                hourly["cloud_cover_high"].append(s["high"])
                hourly["precipitation"].append(s["precip"])
            if self.drop_values:                       # Open-Meteo may send null
                hourly["cloud_cover_mid"][16] = None
            out.append({"latitude": lat, "longitude": lon,
                        "elevation": self.elevation_fn(lat, lon),
                        "hourly_units": {"time": "iso8601", "cloud_cover_low": "%"},
                        "hourly": hourly})
        return out[0] if len(out) == 1 else out


# ----------------------------------------------------------- mock GOES data
NX, NY = 2500, 1500
X0, DX = -0.101360, 5.6e-05
Y0, DY = 0.128240, -5.6e-05
H_SAT, REQ, RPOL, LON0 = 35786023.0, 6378137.0, 6356752.31414, -75.0


def _pixel_latlon():
    from pyproj import Proj
    p = Proj(proj="geos", h=H_SAT, lon_0=LON0, sweep="x", a=REQ, b=RPOL)
    xs = X0 + DX * np.arange(NX)
    ys = Y0 + DY * np.arange(NY)
    X, Y = np.meshgrid(xs * H_SAT, ys * H_SAT)
    lon, lat = p(X, Y, inverse=True)
    return lat, lon


_LATLON = None


def pixel_latlon():
    global _LATLON
    if _LATLON is None:
        _LATLON = _pixel_latlon()
    return _LATLON


def write_goes_file(path, product, acm=None, ht=None, mask_var="ACM", bt=None):
    """Write a synthetic CONUS-like GOES L2 NetCDF with the real structure:
    scaled short x/y, goes_imager_projection attributes, byte mask, scaled
    short heights with a fill value."""
    from netCDF4 import Dataset
    ds = Dataset(path, "w")
    ds.createDimension("y", NY)
    ds.createDimension("x", NX)
    xv = ds.createVariable("x", "i2", ("x",))
    xv.scale_factor, xv.add_offset = DX, X0 + 0.0
    yv = ds.createVariable("y", "i2", ("y",))
    yv.scale_factor, yv.add_offset = DY, Y0 + 0.0
    # store raw shorts so netCDF4 decodes x = raw*scale + offset
    xv.set_auto_maskandscale(False); yv.set_auto_maskandscale(False)
    xv[:] = np.arange(NX, dtype="i2")
    yv[:] = np.arange(NY, dtype="i2")
    xv.set_auto_maskandscale(True); yv.set_auto_maskandscale(True)
    pv = ds.createVariable("goes_imager_projection", "i4")
    pv.perspective_point_height = H_SAT
    pv.semi_major_axis = REQ
    pv.semi_minor_axis = RPOL
    pv.longitude_of_projection_origin = LON0
    pv.sweep_angle_axis = "x"
    if product.startswith("ABI-L2-CMIP"):
        # brightness temperature stored as scaled short, as the real band-13 files are
        cv = ds.createVariable("CMI", "i2", ("y", "x"), fill_value=-1, zlib=True)
        cv.scale_factor, cv.add_offset = 0.06145332, 89.62
        raw = np.where(np.isnan(bt), -1, np.round((bt - 89.62) / 0.06145332)).astype("i2")
        cv.set_auto_maskandscale(False)
        cv[:] = raw
        cv.set_auto_maskandscale(True)
    elif product.startswith("ABI-L2-ACM"):
        mv = ds.createVariable(mask_var, "u1", ("y", "x"), fill_value=255, zlib=True)
        mv[:] = np.ma.masked_array(acm, mask=(acm == 255)) if acm is not None else 0
    else:
        hv = ds.createVariable("HT", "i2", ("y", "x"), fill_value=-1, zlib=True)
        hv.scale_factor = 2.0
        raw = np.where(np.isnan(ht), -1, np.round(ht / 2.0)).astype("i2")
        hv.set_auto_maskandscale(False)
        hv[:] = raw
        hv.set_auto_maskandscale(True)
    ds.close()


class MockGoes:
    """get_text / get_file pair standing in for the NOAA bucket."""

    def __init__(self, tmpdir, observer, scan_fields, day=datetime.date(2026, 11, 6),
                 mask_var="ACM", ir_fields=None):
        """scan_fields: {(hh, mm): (acm_array, ht_array)} -> one file pair per scan.
        ir_fields: {(hh, mm): bt_array (K)} -> a band-13 file for that scan, plus a
        band-1 decoy with nonsense values so a wrong band would be noticed."""
        self.dir = tmpdir
        self.keys = {}                      # key -> local file
        self.listed = []
        self.fetched = []
        doy = day.timetuple().tm_yday
        for (hh, mm), (acm, ht) in scan_fields.items():
            for product, tag in (("ABI-L2-ACMC", "ACMC"), ("ABI-L2-ACHAC", "ACHAC")):
                name = "OR_ABI-L2-%s-M6_G19_s%04d%03d%02d%02d171_e%04d%03d%02d%02d539_c%04d%03d%02d%02d590.nc" % (
                    tag, day.year, doy, hh, mm, day.year, doy, hh, mm + 3,
                    day.year, doy, hh, mm + 4)
                key = "%s/%04d/%03d/%02d/%s" % (product, day.year, doy, hh, name)
                local = os.path.join(tmpdir, "src_" + os.path.basename(name))
                write_goes_file(local, product, acm=acm, ht=ht, mask_var=mask_var)
                self.keys[key] = local

        for (hh, mm), bt in (ir_fields or {}).items():
            for band, arr in (("C01", np.zeros_like(bt)), ("C13", bt)):
                name = "OR_ABI-L2-CMIPC-M6%s_G19_s%04d%03d%02d%02d171_e%04d%03d%02d%02d539_c%04d%03d%02d%02d590.nc" % (
                    band, day.year, doy, hh, mm, day.year, doy, hh, mm + 3, day.year, doy, hh, mm + 4)
                key = "ABI-L2-CMIPC/%04d/%03d/%02d/%s" % (day.year, doy, hh, name)
                local = os.path.join(tmpdir, "src_" + name)
                write_goes_file(local, "ABI-L2-CMIPC", bt=arr)
                self.keys[key] = local

    def get_text(self, url):
        self.listed.append(url)
        prefix = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["prefix"][0]
        body = "".join("<Contents><Key>%s</Key><Size>1</Size></Contents>" % k
                       for k in sorted(self.keys) if k.startswith(prefix))
        return ("<?xml version='1.0'?><ListBucketResult xmlns='http://s3.amazonaws.com/doc/2006-03-01/'>"
                "<Name>noaa-goes19</Name><Prefix>%s</Prefix>%s</ListBucketResult>" % (prefix, body))

    def get_file(self, url, dest):
        key = url.split(".amazonaws.com/")[1]
        self.fetched.append(key)
        shutil.copy(self.keys[key], dest)


def goes_field(observer, az, scenario):
    """Build (acm, ht) arrays from a scenario(bearing, dist) -> (acm, ht_m)
    vectorised over the pixel grid, using independent haversine geometry."""
    lat, lon = pixel_latlon()
    ok = np.isfinite(lat) & np.isfinite(lon)
    b, d = bearing_dist_km_np(observer[0], observer[1], np.where(ok, lat, 0.0), np.where(ok, lon, 0.0))
    acm, ht = scenario(b, d)
    acm = np.where(ok, acm, 255).astype("u1")
    ht = np.where(ok, ht, np.nan)
    return acm, ht


def ir_field(observer, scenario):
    """Band-13 brightness temperature (K) on the pixel grid from scenario(bearing, dist, checker)
    where checker is +-1 alternating from pixel to pixel (the finest texture there is)."""
    lat, lon = pixel_latlon()
    ok = np.isfinite(lat) & np.isfinite(lon)
    b, d = bearing_dist_km_np(observer[0], observer[1], np.where(ok, lat, 0.0), np.where(ok, lon, 0.0))
    checker = np.where((np.arange(NY)[:, None] + np.arange(NX)[None, :]) % 2 == 0, 1.0, -1.0)
    return np.where(ok, scenario(b, d, checker), np.nan)


# ------------------------------------------------------ mock UCAR THREDDS NCSS
class MockNcss:
    """fetch_file(url, dest) stand-in for the GFS NetCDF Subset Service.  It
    obeys the documented request (vars, box, time range) and writes a file
    shaped like the real one: latitude descending, longitude 0-360, time as
    'Hour since 2026-11-01T00:00:00Z' every 3 h."""

    def __init__(self, center, scenario, elevation_fn=None, reject_extras=False,
                 reject_cube=False, reject_geo_with_clouds=False, heights=None):
        """reject_extras: HTTP 400 for any precipitation / terrain variable.
        reject_cube: HTTP 400 for the interval-average (cloud cube) family.
        reject_geo_with_clouds: HTTP 400 when terrain height is asked together with
        other variables (it still answers when asked alone).
        heights: {layer: (bottom_m, top_m)} or f(bearing, dist, hour) -> that dict,
        the cloud base / top the cube files report where a layer has cloud."""
        self.center = center
        self.scenario = scenario
        self.elevation_fn = elevation_fn or (lambda lat, lon: 140.0)
        self.reject_extras = reject_extras
        self.reject_cube = reject_cube
        self.reject_geo_with_clouds = reject_geo_with_clouds
        self.heights = heights or {"low": (500.0, 2500.0), "mid": (4000.0, 5500.0),
                                   "high": (8500.0, 10500.0)}
        self.urls = []

    def __call__(self, url, dest):
        from netCDF4 import Dataset
        self.urls.append(url)
        q = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)
        names = q["var"]
        extras = [n for n in names if n.startswith(("Precipitation", "Geopotential"))]
        if extras and self.reject_extras:
            raise RuntimeError("HTTP 400 from ncss: Variable not found")
        cube = [n for n in names if n.endswith("_Mixed_intervals_Average")]
        if cube and self.reject_cube:
            raise RuntimeError("HTTP 400 from ncss: Variable not found")
        if "Geopotential_height_surface" in names and len(names) > 1 and self.reject_geo_with_clouds:
            raise RuntimeError("HTTP 400 from ncss: variables with different time axes")
        if names == ["Geopotential_height_surface"] or cube:
            return self._write_modern(url, dest, q, names)
        north, south = float(q["north"][0]), float(q["south"][0])
        east, west = float(q["east"][0]), float(q["west"][0])
        t0 = datetime.datetime.strptime(q["time_start"][0], "%Y-%m-%dT%H:%M:%SZ")
        t1 = datetime.datetime.strptime(q["time_end"][0], "%Y-%m-%dT%H:%M:%SZ")
        lats = np.arange(math.floor(south * 4) / 4, math.ceil(north * 4) / 4 + 0.001, 0.25)[::-1]
        lons = np.arange(math.floor(west * 4) / 4, math.ceil(east * 4) / 4 + 0.001, 0.25) % 360.0
        base = datetime.datetime(2026, 11, 1)
        times = []
        t = base + datetime.timedelta(hours=3 * math.ceil((t0 - base).total_seconds() / 3 / 3600))
        while t <= t1:
            times.append(t)
            t += datetime.timedelta(hours=3)
        assert times, "no model time inside the requested range"
        hrs = [(x - base).total_seconds() / 3600.0 for x in times]
        ds = Dataset(dest, "w", format="NETCDF4_CLASSIC")
        ds.createDimension("time", len(times))
        ds.createDimension("latitude", len(lats))
        ds.createDimension("longitude", len(lons))
        for nm in ("time", "reftime"):
            v = ds.createVariable(nm, "f8", ("time",))
            v.units = "Hour since 2026-11-01T00:00:00Z"
            v[:] = hrs if nm == "time" else [hrs[0]] * len(hrs)
        ds.createVariable("latitude", "f4", ("latitude",))[:] = lats
        ds.createVariable("longitude", "f4", ("longitude",))[:] = lons
        keymap = {"Low_cloud_cover_low_cloud": "low", "Medium_cloud_cover_middle_cloud": "mid",
                  "High_cloud_cover_high_cloud": "high", "Precipitation_rate_surface": "precip"}
        offset = -5                                   # the mock days are in EST
        data = {n: np.zeros((len(times), len(lats), len(lons))) for n in names if n in keymap}
        for ti, tt in enumerate(times):
            local_hour = (tt + datetime.timedelta(hours=offset)).hour
            for i, la in enumerate(lats):
                for j, lo in enumerate(lons):
                    lon = lo - 360.0 if lo > 180 else lo
                    b, d = bearing_dist_km(self.center[0], self.center[1], float(la), float(lon))
                    s = self.scenario(b, d, local_hour)
                    for n in data:
                        k = keymap[n]
                        data[n][ti, i, j] = s[k] / 3600.0 if k == "precip" else s[k]
        for n, arr in data.items():
            v = ds.createVariable(n, "f4", ("time", "latitude", "longitude"))
            v.units = "kg m-2 s-1" if n.startswith("Precip") else "%"
            v[:] = arr
        if "Geopotential_height_surface" in names:
            v = ds.createVariable("Geopotential_height_surface", "f4", ("time", "latitude", "longitude"))
            v.units = "gpm"
            el = np.array([[self.elevation_fn(float(la), float(lo - 360 if lo > 180 else lo))
                            for lo in lons] for la in lats])
            v[:] = np.stack([el] * len(times))
        ds.close()

    # ------------------------------------------------------------------
    def _write_modern(self, url, dest, q, names):
        """A file shaped like the real cloud-cube answer: interval averages on a
        'time3' axis with bounds (3 h and 6 h means from 6-hourly reference
        times, e.g. [12,15] [12,18] [18,21] [18,24] ...), pressures in Pa that
        are NaN where the layer has no cloud, and terrain height on its own
        'time' axis.  The value of a 3 h window is the scenario at the window's
        centre; a 6 h mean is the mean of its two halves, as the real ones are."""
        from netCDF4 import Dataset
        north, south = float(q["north"][0]), float(q["south"][0])
        east, west = float(q["east"][0]), float(q["west"][0])
        t0 = datetime.datetime.strptime(q["time_start"][0], "%Y-%m-%dT%H:%M:%SZ")
        t1 = datetime.datetime.strptime(q["time_end"][0], "%Y-%m-%dT%H:%M:%SZ")
        lats = np.arange(math.floor(south * 4) / 4, math.ceil(north * 4) / 4 + 0.001, 0.25)[::-1]
        lons = np.arange(math.floor(west * 4) / 4, math.ceil(east * 4) / 4 + 0.001, 0.25) % 360.0
        base = datetime.datetime(2026, 11, 1)
        ds = Dataset(dest, "w", format="NETCDF4_CLASSIC")
        ds.createDimension("latitude", len(lats))
        ds.createDimension("longitude", len(lons))
        ds.createVariable("latitude", "f4", ("latitude",))[:] = lats
        ds.createVariable("longitude", "f4", ("longitude",))[:] = lons
        units = "Hour since 2026-11-01T00:00:00Z"
        hrs = lambda x: (x - base).total_seconds() / 3600.0

        def local_hour(tt):
            return (tt + datetime.timedelta(hours=-5)).hour + (tt.minute / 60.0)

        def sample(tt, i, j):
            lon = lons[j] - 360.0 if lons[j] > 180 else lons[j]
            b, d = bearing_dist_km(self.center[0], self.center[1], float(lats[i]), float(lon))
            h = local_hour(tt)
            return b, d, h, self.scenario(b, d, h)

        cube = [n for n in names if n.endswith("_Mixed_intervals_Average")]
        if cube:
            windows = []                                   # (start, end, ref)
            ref = base + datetime.timedelta(hours=6 * math.floor(((t0 - base).total_seconds() / 3600.0 - 6) / 6))
            while ref <= t1:
                for span in (3, 6):
                    a, b = ref, ref + datetime.timedelta(hours=span)
                    if b >= t0 and a <= t1:
                        windows.append((a, b, ref))
                ref += datetime.timedelta(hours=6)
            n = len(windows)
            ds.createDimension("time3", n)
            ds.createDimension("bounds_dim", 2)
            tv = ds.createVariable("time3", "f8", ("time3",))
            tv.units = units
            tv[:] = [hrs(a) + (hrs(b) - hrs(a)) / 2 for a, b, _ in windows]
            bv = ds.createVariable("time3_bounds", "f8", ("time3", "bounds_dim"))
            bv[:] = [[hrs(a), hrs(b)] for a, b, _ in windows]
            rv = ds.createVariable("reftime3", "f8", ("time3",))
            rv.units = units
            rv[:] = [hrs(r) for _, _, r in windows]
            keymap = {"Low_cloud_cover_low_cloud": "low", "Medium_cloud_cover_middle_cloud": "mid",
                      "High_cloud_cover_high_cloud": "high",
                      "Precipitation_rate_surface": "precip"}
            half = datetime.timedelta(hours=1.5)
            cache = {}

            def third(tt, i, j):                           # scenario for the 3 h window starting at tt
                key = (tt, i, j)
                if key not in cache:
                    cache[key] = sample(tt + half, i, j)
                return cache[key]

            def window_value(a, b, i, j, fn):
                if (b - a) == datetime.timedelta(hours=3):
                    return fn(third(a, i, j))
                return 0.5 * (fn(third(a, i, j)) + fn(third(a + datetime.timedelta(hours=3), i, j)))

            for nm in cube:
                stem = nm[:-len("_Mixed_intervals_Average")]
                var = ds.createVariable(nm, "f4", ("time3", "latitude", "longitude"))
                arr = np.full((n, len(lats), len(lons)), np.nan)
                if stem in keymap:
                    k = keymap[stem]
                    var.units = "kg.m-2.s-1" if k == "precip" else "%"
                    for w, (a, b, _) in enumerate(windows):
                        for i in range(len(lats)):
                            for j in range(len(lons)):
                                v = window_value(a, b, i, j, lambda s_: s_[3][k])
                                arr[w, i, j] = v / 3600.0 if k == "precip" else v
                else:                                      # Pressure_<layer>_cloud_<edge>
                    var.units = "Pa"
                    layer = {"low": "low", "middle": "mid", "high": "high"}[stem.split("_")[1]]
                    edge = stem.split("_")[-1]
                    cov_key = layer
                    for w, (a, b, _) in enumerate(windows):
                        for i in range(len(lats)):
                            for j in range(len(lons)):
                                cov = window_value(a, b, i, j, lambda s_: s_[3][cov_key])
                                if cov < 10.0:
                                    continue               # no cloud: NaN, as the real files do
                                bb, dd, hh, _s = third(a, i, j)
                                hts = self.heights(bb, dd, hh) if callable(self.heights) else self.heights
                                height = hts[layer][0 if edge == "bottom" else 1]
                                arr[w, i, j] = 101325.0 * (1.0 - height / 44330.77) ** (1.0 / 0.190263)
                var[:] = arr
        if "Geopotential_height_surface" in names:
            ds.createDimension("time", 1)
            tv = ds.createVariable("time", "f8", ("time",))
            tv.units = units
            tv[:] = [hrs(t0)]
            v = ds.createVariable("Geopotential_height_surface", "f4", ("time", "latitude", "longitude"))
            v.units = "gpm"
            v[:] = np.array([[[self.elevation_fn(float(la), float(lo - 360 if lo > 180 else lo))
                               for lo in lons] for la in lats]])
        ds.close()
