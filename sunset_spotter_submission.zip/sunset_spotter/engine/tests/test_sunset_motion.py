import datetime
import json
import math
import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np

import mocks
import sunset_motion as m
import sunset_v1_1 as s
from test_sunset_v1_1 import WASH, UTC, cube_sky, fake_sky, uniform

EST = datetime.timezone(datetime.timedelta(hours=-5))
N = s.GROUND_CELLS


# ============================================================ the sun through time
class TestSunPath(unittest.TestCase):
    def test_sun_is_at_the_sunset_height_and_bearing_at_the_sunset_instant(self):
        for (lat, lon), date in ((WASH, datetime.date(2026, 11, 6)), ((42.7284, -73.6918), datetime.date(2026, 11, 7)),
                                 ((40.7, -74.0), datetime.date(2026, 6, 21)), ((44.0, -76.0), datetime.date(2026, 3, 20))):
            _, when = s.sunset_local(lat, lon, date)
            el, az = m.sun_geometry(lat, lon, when)
            self.assertAlmostEqual(el, m.SUNSET_GEO_DEG, delta=0.15, msg=str(date))
            self.assertAlmostEqual(az, s.sunset_azimuth(lat, date.year, date.month, date.day), delta=3.0, msg=str(date))

    def test_the_sun_sinks_through_the_slider_and_keeps_moving_west(self):
        _, when = s.sunset_local(*WASH, datetime.date(2026, 11, 6))
        seen = [m.sun_geometry(*WASH, when + datetime.timedelta(minutes=k)) for k in range(-45, 31, 15)]
        self.assertTrue(all(a[0] > b[0] for a, b in zip(seen, seen[1:])))
        self.assertTrue(all(a[1] < b[1] for a, b in zip(seen, seen[1:])))
        self.assertAlmostEqual(seen[0][0], 7.0, delta=1.0)             # 45 minutes before: low and golden
        self.assertAlmostEqual(seen[-1][0], -5.5, delta=1.0)           # 30 after: the end of civil twilight

    def test_noon_sun_is_high_in_the_south(self):
        noon = datetime.datetime(2026, 6, 21, 16, 55, tzinfo=UTC)
        el, az = m.sun_geometry(40.7, -74.0, noon)
        self.assertAlmostEqual(el, 72.7, delta=1.0)
        self.assertAlmostEqual(az, 180.0, delta=5.0)

    def test_refraction_lifts_the_sun_and_joins_up(self):
        self.assertAlmostEqual(m.apparent_elevation(m.SUNSET_GEO_DEG), -0.25, delta=0.1)       # sunset convention
        self.assertAlmostEqual(m.apparent_elevation(-1.0), m.apparent_elevation(-1.0001), delta=0.1)
        self.assertAlmostEqual(m.apparent_elevation(30.0), 30.0, delta=0.05)
        self.assertLess(m.apparent_elevation(-4.0), -3.0)


class TestHelpers(unittest.TestCase):
    def test_advect_moves_a_field_bilinearly(self):
        a = np.zeros((20, 20))
        a[10, 10] = 1.0
        moved = m.advect(a, 3, -2, np)                                  # three squares east, two south
        self.assertEqual(float(moved[8, 13]), 1.0)
        self.assertEqual(float(moved.sum()), 1.0)
        half = m.advect(a, 0.5, 0.0, np)                                # half a square east: split between two
        self.assertAlmostEqual(float(half[10, 10]), 0.5)
        self.assertAlmostEqual(float(half[10, 11]), 0.5)
        self.assertTrue(np.array_equal(m.advect(a, 0, 0, np), a))
        self.assertEqual(float(m.advect(a, 15, 0, np).sum()), 0.0)      # carried off the edge
        self.assertEqual(float(m.advect(a, -2.25, 1.75, np).sum()), 1.0)

    def test_hue_runs_from_cream_to_purple(self):
        self.assertEqual(m.hue_at(0.0), m.HUE_STOPS[0][1])
        self.assertEqual(m.hue_at(1.0), m.HUE_STOPS[-1][1])
        self.assertEqual(m.hue_at(5.0), m.HUE_STOPS[-1][1])
        self.assertGreater(m.hue_at(0.0)[1], m.hue_at(0.5)[1])          # less green as the sun goes down
        self.assertGreater(m.hue_at(0.5)[1], m.hue_at(1.0)[1])

    def test_the_sky_darkens_after_sunset_and_not_before(self):
        base = s.GROUND_STYLES["sunset"]
        day, setting, dusk = (m.frame_style(g, m.apparent_elevation(g), 0.9) for g in (6.0, m.SUNSET_GEO_DEG, -6.0))
        self.assertEqual(day["sky_zenith"], base["sky_zenith"])
        self.assertEqual(setting["sky_zenith"], base["sky_zenith"])
        self.assertLess(sum(dusk["sky_zenith"]), sum(base["sky_zenith"]) / 2)
        self.assertLess(sum(dusk["ground_near"]), sum(base["ground_near"]))
        self.assertGreater(day["sun_bright"][1], setting["sun_bright"][1])      # a high sun is yellower

    def test_unify_lattice_reports_what_the_satellite_set(self):
        sky = cube_sky(low=uniform(0.5))
        fl = s.forecast_lattice(sky, 0.0, np)
        codes, heights = np.full((N, N), 1, dtype=int), np.full((N, N), np.nan)
        codes[N - 1 - 150, 150], heights[N - 1 - 150, 150] = 2, 900.0           # one low-top pixel, north-east of the observer
        cells = s.scene_cells({"step": 3.0, "reach": 450.0, "observed": (codes, heights), "shifted": None}, "observed", np)
        lat = s.unify_lattice(fl, cells, None, {"total": 1.0, "unshifted": 1.0, "shifted": 0.0}, 0.0, np)
        self.assertEqual(float(lat["sat"]["low"][150, 150]), 1.0)
        self.assertAlmostEqual(float(lat["cover"]["low"][150, 150]), 1.0)
        self.assertEqual(float(lat["top"]["low"][150, 150]), 900.0)
        none = s.unify_lattice(fl, cells, None, {"total": 0.0}, 0.0, np)
        self.assertAlmostEqual(float(none["cover"]["low"][10, 10]), 0.5)
        self.assertEqual(float(none["sat"]["low"][10, 10]), 0.0)
        back = s.lattice_boxes(lat, np)
        self.assertTrue(np.array_equal(back, s.unified_boxes(sky, 0.0, cells, None, {"total": 1.0, "unshifted": 1.0, "shifted": 0.0}, np)))


# ============================================================ the timeline
def inputs_for(sky_by_hour, winds=None, sat=None, detail=None, gate=0.8, date=datetime.date(2026, 11, 6)):
    local, utc = s.sunset_local(*WASH, date)
    az = s.sunset_azimuth(WASH[0], date.year, date.month, date.day)
    det = detail or {r: {L: (0.5, 0.5, 0.5) for L in s.LAYERS} for r in ("fwd", "over", "anti")}
    return {"lat": WASH[0], "lon": WASH[1], "az": az, "elev_m": 0.0, "sunset_utc": utc, "sunset_local": local,
            "sky": sky_by_hour, "hours": sorted(sky_by_hour), "winds": winds, "detail": det, "gate": gate, "sat": sat,
            "source": "TEST", "lead_h": 2.0}


def cell(r, c, v=1.0):
    g = uniform(0.0)
    g[r][c] = v
    return g


class TestTimeline(unittest.TestCase):
    EAST_WIND = {"low": (10.0, 0.0), "mid": (10.0, 0.0), "high": (10.0, 0.0)}

    def centroid(self, cover):
        total = cover.sum()
        i = np.arange(N)
        return float((cover.sum(axis=0) * i).sum() / total), float((cover.sum(axis=1) * i).sum() / total)

    def test_forecast_cloud_travels_on_the_wind_and_is_never_made_or_lost(self):
        hours = {h: cube_sky(low=cell(s.N, s.N + 3)) for h in (16, 17, 18)}            # the same cell, 90 km east, at every hour
        still = m.Timeline(inputs_for(hours), np)
        windy = m.Timeline(inputs_for(hours, winds=self.EAST_WIND), np)
        t0 = windy.sunset
        a = self.centroid(windy.forecast_at(t0)["low"][0])[0]
        b = self.centroid(windy.forecast_at(t0 + datetime.timedelta(minutes=30))["low"][0])[0]
        back = self.centroid(windy.forecast_at(t0 - datetime.timedelta(minutes=30))["low"][0])[0]
        self.assertAlmostEqual((b - a) * 3.0, 18.0, delta=1.0)                          # 10 m/s for half an hour: 18 km
        self.assertAlmostEqual((a - back) * 3.0, 18.0, delta=1.0)                       # and it came from the other side
        c = self.centroid(still.forecast_at(t0 + datetime.timedelta(minutes=30))["low"][0])[0]
        self.assertAlmostEqual(c, a, delta=0.2)                                          # no wind: it stays put
        for w in (windy, still):
            tot = [w.forecast_at(t0 + datetime.timedelta(minutes=k))["low"][0].sum() for k in (-45, 0, 30)]
            self.assertAlmostEqual(max(tot), min(tot), delta=0.5)
        cov = windy.forecast_at(t0 + datetime.timedelta(minutes=30))["low"][0]
        self.assertAlmostEqual(float(cov.max()), 1.0, places=2)                         # one cloud, not two ghosts
        self.assertEqual(int((cov > 0.9).sum()), 100)

    def test_the_sunset_sky_is_the_hours_around_sunset_cross_faded(self):
        hours = {16: cube_sky(low=uniform(0.2)), 17: cube_sky(low=uniform(0.6)), 18: cube_sky(low=uniform(0.6))}
        tl = m.Timeline(inputs_for(hours), np)
        k = (tl.sunset - tl.hour_utc[16]).total_seconds() / 3600.0                      # about 0.75 h after 16:00
        self.assertAlmostEqual(float(tl.forecast_at(tl.sunset)["low"][0][100, 100]), 0.2 + 0.4 * k, places=3)
        self.assertEqual(float(tl.forecast_at(tl.sunset + datetime.timedelta(minutes=30))["low"][0][100, 100]),
                         float(tl.forecast_at(tl.sunset)["low"][0][100, 100]))          # the model's own change is not replayed

    def full_sky(self):
        return {h: cube_sky(low=uniform(0.5), mid=uniform(0.5), high=uniform(0.5)) for h in (16, 17, 18)}

    def test_high_cloud_and_cloud_toward_the_sun_keep_the_light_longest(self):
        tl = m.Timeline(inputs_for(self.full_sky()), np)
        st = tl.frame(10)
        ill = st["illum"]
        self.assertGreater(float(ill["high"].mean()), float(ill["mid"].mean()))
        self.assertGreater(float(ill["mid"].mean()), float(ill["low"].mean()))
        west, east = ill["low"][:, :N // 2 - 40].mean(), ill["low"][:, N // 2 + 40:].mean()     # sun is in the west
        self.assertGreater(float(west), float(east) + 0.3)
        self.assertGreater(float(st["eloc"][N // 2, 5]), float(st["eloc"][N // 2, N - 5]))      # the shadow comes from the east

    def test_everything_is_lit_in_the_afternoon_and_nothing_low_is_lit_at_dusk(self):
        tl = m.Timeline(inputs_for(self.full_sky()), np)
        early, late = tl.frame(-45), tl.frame(30)
        self.assertGreater(float(early["illum"]["low"].mean()), 0.99)
        self.assertLess(float(late["illum"]["low"].mean()), 0.05)
        self.assertGreater(float(late["illum"]["high"][:, :N // 2].mean()), 0.2)                # high cloud in the west still has light

    def test_colour_comes_in_as_the_sun_goes_down_and_goes_out_in_the_shadow(self):
        tl = m.Timeline(inputs_for(self.full_sky()), np)
        n_grey = len(m.SHADE_LEVELS)
        share = lambda st, L: float((st["keys"][L] >= n_grey).mean())
        high_sun, setting, dusk = tl.frame(-45), tl.frame(0), tl.frame(30)
        self.assertLess(share(high_sun, "mid"), 0.05)                    # a high sun colours nothing
        self.assertGreater(share(setting, "mid"), share(high_sun, "mid") + 0.02)        # only the scored regions take hue
        self.assertGreater(share(setting, "mid"), 0.02)
        self.assertLess(share(dusk, "low"), share(setting, "low"))      # low cloud is in shadow
        for st in (high_sun, setting, dusk):
            for L in s.LAYERS:
                self.assertLess(int(st["keys"][L].max()), len(tl.palette(L)))
                self.assertGreaterEqual(int(st["keys"][L].min()), 0)

    def test_the_decoration_the_score_gave_sets_how_much_hue(self):
        none = {r: {L: (0.5, 0.5, 0.0) for L in s.LAYERS} for r in ("fwd", "over", "anti")}
        tl = m.Timeline(inputs_for(self.full_sky(), detail=none), np)
        st = tl.frame(0)
        self.assertTrue(all(float((st["keys"][L] >= len(m.SHADE_LEVELS)).sum()) == 0 for L in s.LAYERS))
        shut = m.Timeline(inputs_for(self.full_sky(), gate=0.0), np).frame(0)                    # a hidden sun lights nothing
        self.assertTrue(all(float((shut["keys"][L] >= len(m.SHADE_LEVELS)).sum()) == 0 for L in s.LAYERS))

    def test_palette_has_one_colour_per_key_and_greys_darken_in_shadow(self):
        tl = m.Timeline(inputs_for(self.full_sky()), np)
        pal = tl.palette("mid")
        self.assertEqual(len(pal), len(m.SHADE_LEVELS) + m.HUE_LEVELS * m.WARM_LEVELS)
        self.assertTrue(pal.min() >= 0 and pal.max() <= 255)
        self.assertLess(pal[0].sum(), pal[1].sum())
        self.assertLess(pal[1].sum(), pal[2].sum())
        self.assertGreater(pal[len(m.SHADE_LEVELS) + m.WARM_LEVELS * 2 + 2][0], 180)             # strongest hue at mid warmth: red

    def test_a_frame_draws_both_pictures_and_they_change_through_time(self):
        tl = m.Timeline(inputs_for(self.full_sky(), winds=self.EAST_WIND), np)
        a, b = tl.frame(-30), tl.frame(20)
        ga, gb = tl.ground_frame(a), tl.ground_frame(b)
        ta, tb = tl.top_frame(a), tl.top_frame(b)
        self.assertEqual(ga.shape, gb.shape)
        self.assertEqual(ga.shape[1], int(round(s.GROUND_HFOV * s.GROUND_PPD)))
        self.assertEqual(ta.shape, tb.shape)
        self.assertEqual(ta.shape[1], N * m.TOP_SCALE)
        self.assertFalse(np.array_equal(ga, gb))
        self.assertFalse(np.array_equal(ta, tb))
        night, day = tb[60:80, 5:25].astype(float).mean(), ta[60:80, 5:25].astype(float).mean()   # sky and ground are darker at dusk
        self.assertLess(gb[60:120, 5:60].astype(float).mean(), ga[60:120, 5:60].astype(float).mean())

    def test_the_sun_is_drawn_while_it_is_up_and_gone_when_it_is_not(self):
        tl = m.Timeline(inputs_for({h: cube_sky() for h in (16, 17, 18)}), np)
        up, down = tl.frame(-20), tl.frame(20)
        a, b = tl.ground_frame(up), tl.ground_frame(down)
        col = lambda st: int(round(a.shape[1] / 2.0 + s._wrap_deg(st["sun_az"] - tl.az_bias - tl.az) * s.GROUND_PPD))
        row = lambda st: 46 + int(round((s.GROUND_EL_MAX - st["app"]) * s.GROUND_PPD))
        p = a[row(up), col(up)].astype(float)
        self.assertGreater(p[0], 180)                                    # a red-orange disc
        self.assertLess(p[2], 120)
        self.assertGreater(b[46:46 + 300, :, 0].astype(float).max() - b[46:46 + 300, :, 2].astype(float).max(), -60)
        self.assertFalse(np.any((b[46:46 + 460, :, 0] > 200) & (b[46:46 + 460, :, 1] < 110) & (b[46:46 + 460, :, 2] < 60)))

    def test_without_a_scan_the_sky_is_the_forecast_alone(self):
        tl = m.Timeline(inputs_for(self.full_sky()), np)
        st = tl.frame(0)
        self.assertEqual(st["weights"]["total"], 0.0)
        self.assertAlmostEqual(float(st["lattice"]["cover"]["low"][100, 100]), 0.5, places=3)
        self.assertEqual(float(st["lattice"]["sat"]["low"].max()), 0.0)


# ============================================================ a whole query
class TestFramesFromARun(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.az = s.sunset_azimuth(WASH[0], 2026, 11, 6)

        def bank(b, d):
            acm, ht = np.zeros(b.shape), np.full(b.shape, np.nan)
            sun = (np.abs((b - cls.az + 180) % 360 - 180) <= 14) & (d > 5) & (d <= 125)
            acm[sun], ht[sun] = 3, 800.0
            return acm, ht
        cls.field = mocks.goes_field(WASH, cls.az, bank)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def run_frames(self):
        d = tempfile.mkdtemp(dir=self.tmp)
        g = mocks.MockGoes(d, WASH, {(20, 36): self.field})
        ncss = mocks.MockNcss(WASH, mocks.bank_at(self.az, near=40, far=200, layer="low"))
        now = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)
        return s.run(*WASH, "2026-11-06", now_utc=now, cache_dir=os.path.join(d, "cache"), use_sat=True,
                     fetch_file=ncss, goes_get_text=g.get_text, goes_get_file=g.get_file, log=lambda *a: None, frames=True)

    def test_run_hands_over_what_the_frames_need(self):
        res = self.run_frames()
        inp = res["motion_inputs"]
        self.assertIsNotNone(inp)
        for key in ("lat", "lon", "az", "elev_m", "sunset_utc", "sunset_local", "sky", "hours", "detail", "gate", "sat"):
            self.assertIn(key, inp)
        self.assertIsNotNone(inp["sat"]["scene"])
        self.assertIsNone(s.run(*WASH, "2026-11-06", now_utc=datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC),
                                cache_dir=tempfile.mkdtemp(dir=self.tmp), use_sat=False, log=lambda *a: None,
                                fetch_file=mocks.MockNcss(WASH, mocks.bank_at(self.az, near=40, far=200, layer="low")))["motion_inputs"])

    def test_the_satellite_bank_is_in_the_frames_and_drifts(self):
        inp = self.run_frames()["motion_inputs"]
        tl = m.Timeline(inp, np)
        st = tl.frame(0)
        self.assertGreater(float(st["lattice"]["sat"]["low"].max()), 0.5)
        self.assertGreater(float(st["lattice"]["cover"]["low"].max()), 0.9)

    def test_frames_are_written_with_their_description(self):
        inp = self.run_frames()["motion_inputs"]
        out = tempfile.mkdtemp(dir=self.tmp)
        meta = m.render_frames(inp, out, (-30, 0, 20), np, log=lambda *a: None)
        self.assertEqual([x["minutes"] for x in meta], [-30, 0, 20])
        for x in meta:
            self.assertTrue(os.path.exists(os.path.join(out, x["ground"])))
            self.assertTrue(os.path.exists(os.path.join(out, x["top"])))
        self.assertEqual(m.frame_name("ground", -30), "ground_m030.png")
        self.assertEqual(m.frame_name("top", 5), "top_p005.png")
        with open(os.path.join(out, "frames.json")) as fh:
            doc = json.load(fh)
        self.assertEqual(len(doc["frames"]), 3)
        self.assertGreater(doc["frames"][0]["sun_elevation"], doc["frames"][2]["sun_elevation"])



# ============================================================ views, layer filters, reverse, overhead
class TestViews(unittest.TestCase):
    def tl(self, **kw):
        sky = {h: cube_sky(low=uniform(0.6), mid=uniform(0.5), high=uniform(0.5)) for h in (16, 17, 18)}
        return m.Timeline(inputs_for(sky, **kw), np)

    def test_only_layers_takes_the_others_out_and_leaves_the_light_alone(self):
        tl = self.tl()
        st = tl.frame(0)
        one = tl.only_layers(st, ("high",))
        self.assertGreater(float(one["lattice"]["cover"]["high"].max()), 0.0)
        self.assertEqual(float(one["lattice"]["cover"]["low"].max()), 0.0)
        self.assertEqual(float(one["lattice"]["cover"]["mid"].max()), 0.0)
        self.assertTrue((one["keys"]["high"] == st["keys"]["high"]).all())              # the light was worked out with the whole sky
        self.assertGreater(float(st["lattice"]["cover"]["low"].max()), 0.0)             # the original is not touched
        self.assertIs(tl.only_layers(st, None), st)
        self.assertIs(tl.only_layers(st, ("low", "mid", "high")), st)

    def test_a_layer_filter_changes_both_pictures_and_says_so_in_the_title(self):
        tl = self.tl()
        st = tl.frame(0)
        for fn in (tl.ground_frame, tl.top_frame, tl.reverse_frame, tl.dome_frame):
            full, high = fn(st), fn(st, layers=("high",))
            self.assertEqual(full.shape, high.shape)
            self.assertFalse((full == high).all(), fn.__name__)
        self.assertIn("HIGH CLOUD ONLY", tl._tag(("high",)))
        self.assertEqual(tl._tag(None), "")

    def test_forecast_and_satellite_sources(self):
        tl = self.tl()
        fc = tl.frame(0, source="forecast")
        self.assertEqual(fc["weights"]["total"], 0.0)
        self.assertEqual(fc["source"], "forecast")
        with self.assertRaises(ValueError):                       # no scan, nothing to show on its own
            tl.frame(0, source="satellite")
        data = tl.ground_frame(fc, "forecast")
        self.assertEqual(data.shape, tl.ground_frame(fc).shape)
        self.assertFalse((data == tl.ground_frame(fc)).all())     # data colours, not sunset colours

    def test_reverse_and_overhead_can_be_drawn_in_data_colours(self):
        tl = self.tl()
        st = tl.frame(0)
        for fn in (tl.reverse_frame, tl.dome_frame):
            sunset, data = fn(st), fn(st, view="data")
            self.assertEqual(sunset.shape[1], data.shape[1])
            h = min(sunset.shape[0], data.shape[0]) - 40                            # the legends differ in height
            self.assertFalse((sunset[:h] == data[:h]).all(), fn.__name__)           # no lighting, so no shadow or belt either
            high = fn(st, layers=("high",), view="data")
            self.assertEqual(high.shape, data.shape)
            self.assertFalse((data == high).all(), fn.__name__)
        fc = tl.frame(0, source="forecast")
        a, b = tl.reverse_frame(fc, view="forecast"), tl.reverse_frame(fc, view="data")
        self.assertEqual(a.shape, b.shape)
        self.assertFalse((a == b).all())                                            # the title names the source

    def test_the_visibility_radii_are_the_scores(self):
        tl = self.tl()
        for L in s.LAYERS:
            self.assertAlmostEqual(tl.rad[L], s.visibility_radius(s.LAYER_HEIGHT_M[L], 0.0), places=6)
        self.assertEqual(tl.rmax, max(tl.rad.values()))
        typical = {L: (500.0 + 100.0 * i, 2500.0 + 1000.0 * i) for i, L in enumerate(s.LAYERS)}
        inp = inputs_for({h: cube_sky() for h in (16, 17, 18)})
        inp["typical"] = typical
        tl = m.Timeline(inp, np)
        self.assertAlmostEqual(tl.rad["mid"], s.visibility_radius(typical["mid"][1], 0.0), places=6)

    def test_top_down_draws_the_scored_regions_where_the_score_looks(self):
        tl = self.tl()
        st = tl.frame(0)
        img = tl.top_frame(st).astype(int)
        S, reach, step = m.TOP_SCALE, s.GROUND_CELLS * s.GROUND_STEP_KM / 2.0, s.GROUND_STEP_KM
        head = 46

        def px(bearing, km):
            b = math.radians(bearing)
            return (int(round((reach - km * math.cos(b)) / step * S)) + head, int(round((reach + km * math.sin(b)) / step * S)))

        def near(bearing, km, kind):
            r, c = px(bearing, km)
            p = img[r - 2:r + 3, c - 2:c + 3].reshape(-1, 3)
            R, G, B = p[:, 0], p[:, 1], p[:, 2]
            hit = {"orange": (R > 200) & (G > 100) & (G < 180) & (B < 90), "cyan": (R < 90) & (G > 150) & (B > 150),
                   "green": (G > 190) & (R < 130) & (B < 130), "red": (R > 200) & (G < 110) & (B < 110)}[kind]
            return bool(hit.any())

        far = tl.rad["low"] * 0.5
        self.assertTrue(near(tl.az + s.WEDGE_HALF, far, "orange"))                    # sunset wedge edge
        self.assertTrue(near(tl.az + 180.0 + s.WEDGE_HALF, far, "cyan"))               # opposite wedge edge
        self.assertTrue(near(90.0, s.OVERHEAD_KM, "green"))                            # overhead disc
        self.assertTrue(near(tl.az, far, "red"))                                       # sun ray
        self.assertFalse(near(tl.az + 40.0, tl.rmax * 1.05, "orange"))                  # nothing drawn outside the wedge

    def test_reverse_view_faces_away_with_a_shadow_and_no_sun(self):
        tl = self.tl()
        st = tl.frame(6)
        rev = tl.reverse_frame(st)
        fwd = tl.ground_frame(st)
        self.assertEqual(rev.shape[1], fwd.shape[1])
        self.assertFalse((rev[:300] == fwd[:300]).all())
        clear = m.Timeline(inputs_for({h: cube_sky() for h in (16, 17, 18)}), np)
        sky = clear.reverse_frame(clear.frame(8))
        h0 = 46 + int((s.GROUND_EL_MAX - 1.0) * s.GROUND_PPD)                       # 1 degree up, at the middle
        h1 = 46 + int((s.GROUND_EL_MAX - 9.0) * s.GROUND_PPD)
        mid = sky.shape[1] // 2
        self.assertLess(int(sky[h0, mid].sum()), int(sky[h1, mid].sum()) - 30)       # dark shadow band below the lighter belt above
        nosun = clear.reverse_frame(clear.frame(-30))
        self.assertTrue(np.isfinite(nosun).all())

    def test_the_shadow_stands_as_high_as_the_sun_is_deep_and_sinks_away_from_the_antisolar_point(self):
        el = np.linspace(0.0, 30.0, 3001)
        for depth in (1.0, 3.0, 6.0):
            sh, belt = s.anti_twilight(el, np.zeros_like(el), depth, np)
            top = float(el[np.argmin(np.abs(sh - 0.5))]) if sh.max() > 0.5 else 0.0
            self.assertAlmostEqual(top, depth, delta=0.3)
            self.assertGreater(float(belt[el > depth].max()), float(belt[el < depth - 0.5].max()))   # the belt is above the shadow
        sh0, _ = s.anti_twilight(np.array([3.0]), np.array([0.0]), 4.0, np)          # 3 degrees up, depth 4: inside the shadow
        sh60, _ = s.anti_twilight(np.array([4.0]), np.array([60.0]), 4.0, np)        # 4 degrees up, 60 away: the shadow's top is 2
        self.assertGreater(float(sh0[0]), 0.6)
        self.assertLess(float(sh60[0]), 0.1)
        for before in (0.0, -2.0):
            sh, belt = s.anti_twilight(el, np.zeros_like(el), before, np)
            self.assertEqual(float(sh.max()), 0.0)
            self.assertEqual(float(belt.max()), 0.0)

    def test_overhead_dome_puts_east_on_the_left_and_overhead_cloud_in_the_middle(self):
        np_ = np
        n = s.GROUND_CELLS
        empty = {"n": n, "step": s.GROUND_STEP_KM, "cover": {L: np_.zeros((n, n)) for L in s.LAYERS},
                 "bottom": {L: np_.full((n, n), np_.nan) for L in s.LAYERS},
                 "top": {L: np_.full((n, n), np_.nan) for L in s.LAYERS}, "sat": {L: np_.zeros((n, n)) for L in s.LAYERS}}
        tl = self.tl()
        st = tl.frame(0)
        frame = {"style": m.frame_style(st["geo"], st["app"], 0.9), "keys": st["keys"],
                 "palette": {L: tl.palette(L) for L in s.LAYERS}}
        kw = dict(elev_m=0.0, sun_az=250.0, sun_deg=-0.2, gate=0.9, frame=frame, title="T", subtitle="S", legend=[], np=np_,
                  radius=120)
        base = s.render_dome_view(empty, **kw)
        cx = base.shape[1] // 2
        cy = 46 + 26 + 120
        east = {k: v.copy() for k, v in empty.items() if k in ("cover", "bottom", "top", "sat")}
        east.update({"n": n, "step": s.GROUND_STEP_KM})
        for k in ("cover", "bottom", "top", "sat"):
            east[k] = {L: v.copy() for L, v in empty[k].items()}
        east["cover"]["mid"][n // 2 - 3:n // 2 + 3, n // 2 + 3:n // 2 + 30] = 1.0       # 10 to 90 km east of the observer
        east["bottom"]["mid"][:] = np_.where(east["cover"]["mid"] > 0, 4000.0, np_.nan)
        east["top"]["mid"][:] = np_.where(east["cover"]["mid"] > 0, 5500.0, np_.nan)
        img = s.render_dome_view(east, **kw)
        diff = np_.abs(img.astype(int) - base.astype(int)).sum(axis=2) > 12
        rows = slice(46 + 26, 46 + 26 + 240)
        left, right = diff[rows, :cx].sum(), diff[rows, cx:].sum()
        self.assertGreater(int(left), 200)
        self.assertEqual(int(right), 0)                                              # east is on the left, only
        over = {k: ({L: v.copy() for L, v in east[k].items()} if isinstance(east[k], dict) else east[k]) for k in east}
        over["cover"]["mid"][:] = 0.0
        over["cover"]["mid"][n // 2 - 2:n // 2 + 2, n // 2 - 2:n // 2 + 2] = 1.0       # straight overhead
        over["bottom"]["mid"][:] = np_.where(over["cover"]["mid"] > 0, 4000.0, np_.nan)
        over["top"]["mid"][:] = np_.where(over["cover"]["mid"] > 0, 5500.0, np_.nan)
        img2 = s.render_dome_view(over, **kw)
        centre = np_.abs(img2[cy - 6:cy + 6, cx - 6:cx + 6].astype(int) - base[cy - 6:cy + 6, cx - 6:cx + 6].astype(int)).sum()
        self.assertGreater(int(centre), 100)

    def test_a_frame_can_be_the_current_moment(self):
        tl = self.tl()
        st = tl.frame(-83.4)
        st["now"] = True
        self.assertIn("NOW", tl._when(st))
        self.assertEqual(tl._when(tl.frame(-9)), tl.frame(-9)["local"].strftime("%H:%M") + "  SUNSET -9 MIN")
        self.assertEqual(tl.ground_frame(st).ndim, 3)


if __name__ == "__main__":
    unittest.main()
