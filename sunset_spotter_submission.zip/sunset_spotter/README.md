# Sunset Spotter (HackRPI 2026, John Kosowicz)

Enter a place and a date and get a 0 to 100 sunset score with the reasons behind it, plus four views of the sky
(forward ground view, top-down map, reverse view, overhead dome) that you can scrub through time with a slider.

Live site: https://sunset-score.vercel.app

## What is in this zip

```
engine/   the scoring engine (standard library + numpy/netCDF4) and its tests
  sunset_v1_1.py         score, explanation, satellite check, command-line tool
  sunset_motion.py       the slider: sun path, Earth shadow, clouds drifting on the real winds
  tests/                 offline tests (NOAA and satellite are replaced by mocks, no network needed)
web/      the website (this is what Vercel serves)
  src/page.html          the page source;  python build.py  writes public/index.html
  public/                the built page, 2 saved example sunsets (public/demo), the Shoutouts photos
  api/sunset.py          the server function;  api/_lib/ holds a copy of the engine and the glue
  server.py              run the whole site on your own computer
  vercel.json, .vercelignore, requirements.txt
```

No downloaded data is included. The forecast (NOAA GFS) and the satellite scan (NOAA GOES-East) are fetched live the
first time a place is queried and cached in a `cache/` folder, so nothing needs to be copied over to run it.

## Run it

Command line (one location, one date):

```
pip install numpy netCDF4
python engine/sunset_v1_1.py 41.4278 -74.1654 2026-11-06
```

The website on your own computer:

```
pip install numpy netCDF4
cd web
python server.py            # then open http://localhost:8000
```

The saved examples show immediately; **Calculate** does a live run (about 10 to 30 s for the score, then the slider
frames fill in).

## How the score works, in short

The sky is read as a 31 x 31 grid of 30 km cells (forecast layers low / mid / high, with the satellite adding real cloud
heights and texture when a scan covers the sunset). Three regions are scored: the sunset direction (a +-15 degree wedge, weight
0.55), overhead (a 45 km disc, 0.25) and the opposite sky (0.20). High cloud lights up best, so layers are weighted
low / mid / high; a visibility gate checks that low cloud toward the sun is not blocking the sight line; the result is a
range over the hours around sunset with a confidence level. See `web/README.md` for the page and API details.

## Tests

```
python -m unittest discover -s engine/tests
python -m unittest discover -s web/tests
```
