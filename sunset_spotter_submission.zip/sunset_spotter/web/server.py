"""Run the site on your own computer:  python server.py  then open http://localhost:8000

Serves public/ and answers /api/sunset exactly like the Vercel function does.
Needs: pip install numpy netCDF4
"""
import os
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

HERE = os.path.dirname(os.path.abspath(__file__))
os.environ.setdefault("SUNSET_CACHE", os.path.join(HERE, "cache"))
sys.path.insert(0, os.path.join(HERE, "api"))
import sunset as api  # noqa: E402  (api/sunset.py)


class Site(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=os.path.join(HERE, "public"), **kwargs)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/sunset":
            status, headers, body = api.handle(parse_qs(parsed.query))
            self.send_response(status)
            for k, v in headers.items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)
        else:
            super().do_GET()

    def log_message(self, fmt, *args):
        sys.stderr.write("%s\n" % (fmt % args))


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print("Sunset Score on http://localhost:%d  (Ctrl+C to stop)" % port)
    ThreadingHTTPServer(("127.0.0.1", port), Site).serve_forever()
