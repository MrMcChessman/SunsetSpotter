"""Glue between the web page and the sunset engine.

One call (`compute`) = one HTTP request: run the score, then render the
requested frames of the sunset slider as PNGs (base64) in the same response.
Nothing is kept between requests except the on-disk download cache, so it
works on a serverless host where every request may land on a fresh machine.
"""
import base64
import datetime
import json
import math
import os
import threading
import time

import sunset_v1_1 as s
import sunset_motion as m

FRAME_MINUTES = tuple(m.FRAME_MINUTES)          # -45 ... +30 in steps of 3
VIEWS = ("sunset", "data", "forecast", "satellite", "reverse", "dome")   # reverse/dome: old spellings of panel=
PANELS = ("ground", "reverse", "dome")                                   # which picture a frame carries
LAYERS = tuple(s.LAYERS)
NOW_WINDOW_H = 3.0                               # the current-sky frame is offered within this many hours of sunset
MAX_FRAMES_PER_REQUEST = 8
MAX_RESPONSE_BYTES = 3_600_000                  # Vercel caps a response at 4.5 MB
CACHE_MAX_AGE_S = 6 * 3600
CACHE_MAX_BYTES = 300_000_000
NEW_YORK_BOX = (40.4, 45.1, -79.9, -71.7)       # (lat0, lat1, lon0, lon1) the engine was tuned for


# netCDF4 / HDF5 is not safe to call from several threads at once (it crashes the whole process),
# so one request at a time per process; the work is CPU-bound anyway.
_LOCK = threading.Lock()


class BadRequest(ValueError):
    """The visitor asked for something we can say no to politely."""


def parse_minutes(text):
    if text is None or text == "":
        return [0]
    try:
        vals = [int(x) for x in str(text).split(",") if x.strip() != ""]
    except ValueError:
        raise BadRequest("minutes must be a comma list of whole numbers")
    out = []
    for v in vals:
        if v not in FRAME_MINUTES:
            raise BadRequest("minutes must be multiples of 3 from %d to %d" % (FRAME_MINUTES[0], FRAME_MINUTES[-1]))
        if v not in out:
            out.append(v)
    if len(out) > MAX_FRAMES_PER_REQUEST:
        raise BadRequest("at most %d frames per request" % MAX_FRAMES_PER_REQUEST)
    return out or [0]


def parse_view(text):
    v = (text or "sunset").strip().lower()
    if v not in VIEWS:
        raise BadRequest("view must be one of: %s" % ", ".join(VIEWS))
    return v


def parse_panel(text, view="sunset"):
    """Which picture: the forward ground view (with the top-down map), the reverse view, or the overhead dome.
    The old spelling view=reverse / view=dome still works and means that panel in sunset colours."""
    if view in ("reverse", "dome"):
        return view, "sunset"
    p = (text or "ground").strip().lower()
    if p not in PANELS:
        raise BadRequest("panel must be one of: %s" % ", ".join(PANELS))
    return p, view


def parse_layers(text):
    """"low,mid" -> ("low", "mid"); nothing or all three -> None (no filter)."""
    if text is None or str(text).strip() == "" or str(text).strip().lower() == "all":
        return None
    got = [x.strip().lower() for x in str(text).split(",") if x.strip()]
    if any(x not in LAYERS for x in got):
        raise BadRequest("layers must be a comma list of: %s" % ", ".join(LAYERS))
    got = tuple(L for L in LAYERS if L in got)
    return None if len(got) == len(LAYERS) else got


def parse_place(lat, lon, date_str, now_utc=None):
    try:
        lat, lon = float(lat), float(lon)
        date = datetime.date.fromisoformat(str(date_str))
    except (TypeError, ValueError):
        raise BadRequest("Enter a latitude, a longitude and a date like 2026-11-06.")
    if not (math.isfinite(lat) and math.isfinite(lon) and -60 < lat < 70 and -180 <= lon <= 180):
        raise BadRequest("That latitude/longitude is outside the range this tool handles.")
    now_utc = now_utc or datetime.datetime.now(datetime.timezone.utc)
    today = now_utc.date()
    if date < today - datetime.timedelta(days=2) or date > today + datetime.timedelta(days=10):
        raise BadRequest("Pick a date from two days ago to ten days ahead (the forecast reaches that far).")
    return round(lat, 4), round(lon, 4), date.isoformat()


def prune_cache(cache_dir, now=None):
    """Keep the download cache small: drop old files, then the oldest until it fits."""
    now = now or time.time()
    try:
        entries = []
        for name in os.listdir(cache_dir):
            path = os.path.join(cache_dir, name)
            if os.path.isfile(path):
                st = os.stat(path)
                entries.append([st.st_mtime, st.st_size, path])
        entries.sort()
        total = sum(e[1] for e in entries)
        for mtime, size, path in entries:
            if now - mtime > CACHE_MAX_AGE_S or total > CACHE_MAX_BYTES:
                try:
                    os.remove(path)
                    total -= size
                except OSError:
                    pass
    except OSError:
        pass


def summarize(res, now_utc=None):
    """The numbers and sentences the page shows next to the pictures."""
    t = res["sunset_local"]
    mid = res["mid_hour"]
    sat = res.get("satellite")
    return {
        "lat": res["lat"], "lon": res["lon"], "date": res["date"],
        "score": int(res["score"]), "low": int(res["low"]), "high": int(res["high"]),
        "confidence": round(float(res["confidence"]), 2), "verdict": s.verdict(res["score"]),
        "sunset_local": t.strftime("%H:%M"),
        "tz": "EDT" if t.utcoffset() == datetime.timedelta(hours=-4) else "EST",
        "azimuth": round(float(res["azimuth"]), 1), "elevation_m": int(round(res["elevation_m"])),
        "gate": round(float(mid["gate"]), 2), "decoration": round(float(mid["decoration"]), 2),
        "regions": {k: round(float(v), 2) for k, v in mid["regions"].items()},
        "explain": s.explain(res),
        "source": res["source"], "lead_h": round(float(res["lead_h"]), 1),
        "satellite": bool(sat), "satellite_note": res.get("satellite_note"),
        "report": s.format_report(res, brief=False),
        "calculated": (now_utc or datetime.datetime.now(datetime.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "scan_utc": sat["scan_utc"].strftime("%Y-%m-%dT%H:%M:%SZ") if sat and sat.get("scan_utc") else None,
    }


def compute(lat, lon, date_str, minutes=(0,), cache_dir="/tmp/sunset_cache", now_utc=None, view="sunset",
            layers=None, now=False, panel="ground", **run_kwargs):
    with _LOCK:
        return _compute(lat, lon, date_str, minutes, cache_dir, now_utc, view, layers, now, panel, **run_kwargs)


def render_one(tl, minutes, view, layers, np, now=False, panel="ground"):
    """One frame of the slider as (state, picture, top-down map or None) for a panel, a view (the colouring and
    which source: sunset, data, forecast, satellite) and a set of cloud layers."""
    panel, view = parse_panel(panel, view)
    source = view if view in ("forecast", "satellite") else "fused"
    st = tl.frame(minutes, source=source)
    if now:
        st["now"] = True
    if panel == "reverse":
        return st, tl.reverse_frame(st, layers, view), None
    if panel == "dome":
        return st, tl.dome_frame(st, layers, view), None
    return st, tl.ground_frame(st, view, layers), tl.top_frame(st, view, layers)


def _compute(lat, lon, date_str, minutes, cache_dir, now_utc, view="sunset", layers=None, now=False, panel="ground",
             **run_kwargs):
    """Score + the requested frames.  Returns a JSON-ready dict.

    run_kwargs are passed to sunset_v1_1.run (tests inject offline data sources)."""
    import numpy as np
    panel, view = parse_panel(panel, view)
    now_utc = now_utc or datetime.datetime.now(datetime.timezone.utc)
    lat, lon, date_str = parse_place(lat, lon, date_str, now_utc)
    minutes = list(minutes)
    os.makedirs(cache_dir, exist_ok=True)
    prune_cache(cache_dir, now_utc.timestamp())
    notes = []
    t0 = time.time()
    try:
        res = s.run(lat, lon, date_str, now_utc=now_utc, cache_dir=cache_dir, mask_dir=None,
                    ground_view=False, frames=True, log=lambda *a: notes.append(" ".join(str(x) for x in a)),
                    **run_kwargs)
    except (RuntimeError, ValueError) as err:
        raise BadRequest("Could not compute a score: %s" % err)
    out = {"ok": True, "info": summarize(res, now_utc), "frames": [], "pending": [], "all_minutes": list(FRAME_MINUTES),
           "warning": None, "notes": [n for n in notes if "skipped" in n or "unavailable" in n or "falling back" in n][:4]}
    if not (NEW_YORK_BOX[0] <= lat <= NEW_YORK_BOX[1] and NEW_YORK_BOX[2] <= lon <= NEW_YORK_BOX[3]):
        out["warning"] = "This version is tuned for New York and uses Eastern time, so results elsewhere will be off."
    inputs = res.get("motion_inputs")
    if inputs is None:
        out["frame_error"] = "No frames for this request."
        return out
    try:
        tl = m.Timeline(inputs, np)
        sunset_utc = inputs["sunset_utc"]
        now_min = (now_utc - sunset_utc).total_seconds() / 60.0
        out["info"]["now"] = {"available": abs(now_min) <= NOW_WINDOW_H * 60.0, "minutes": round(now_min, 1),
                              "local": now_utc.astimezone(tl.tz).strftime("%H:%M")}
        if view == "satellite" and tl.cells is None:
            raise BadRequest("There is no satellite scan for this query (a scan is used within 3 hours of sunset).")
        if now and not out["info"]["now"]["available"]:
            raise BadRequest("The current sky is shown within %d hours of sunset." % NOW_WINDOW_H)
        used = 0
        for mi in ([now_min] if now else minutes):
            st, ground, top = render_one(tl, mi, view, layers, np, now=now, panel=panel)
            g = base64.b64encode(s._png_bytes(ground, np)).decode("ascii")
            tp = base64.b64encode(s._png_bytes(top, np)).decode("ascii") if top is not None else None
            size = len(g) + (len(tp) if tp else 0)
            if out["frames"] and used + size > MAX_RESPONSE_BYTES:
                out["pending"].append(mi)
                continue
            used += size
            fr = {"minutes": mi if not now else round(mi, 1), "local": st["local"].strftime("%H:%M"),
                  "sun_elevation": round(float(st["app"]), 2),
                  "satellite_weight": round(float(st["weights"]["total"]), 3),
                  "view": view, "panel": panel, "layers": list(layers) if layers else None, "now": bool(now),
                  "ground": g}
            if tp is not None:
                fr["top"] = tp                                     # only the forward panel comes with its map
            out["frames"].append(fr)
    except BadRequest:
        raise
    except Exception as err:                       # the score is still worth showing
        out["frame_error"] = "Could not draw the pictures (%s)." % str(err)[:120]
    out["seconds"] = round(time.time() - t0, 1)
    return out


def to_json(obj):
    return json.dumps(obj, separators=(",", ":"))
