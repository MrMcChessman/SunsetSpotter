"""Vercel serverless function: GET /api/sunset?lat=..&lon=..&date=YYYY-MM-DD&minutes=-45,-42"""
import json
import os
import sys
from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "_lib"))
import sunset_service as svc  # noqa: E402

CACHE_DIR = os.environ.get("SUNSET_CACHE", "/tmp/sunset_cache")


def respond(status, payload):
    body = svc.to_json(payload).encode("utf-8")
    headers = {"Content-Type": "application/json; charset=utf-8", "Content-Length": str(len(body))}
    if status == 200:
        headers["Cache-Control"] = "public, s-maxage=600, stale-while-revalidate=600"
    else:
        headers["Cache-Control"] = "no-store"
    return status, headers, body


def handle(query):
    """Pure function: query string dict -> (status, headers, body).  server.py reuses it."""
    q = {k: v[0] for k, v in query.items()}
    if q.get("ping"):
        return respond(200, {"ok": True, "pong": True})
    try:
        minutes = svc.parse_minutes(q.get("minutes"))
        view, layers = svc.parse_view(q.get("view")), svc.parse_layers(q.get("layers"))
        panel, view = svc.parse_panel(q.get("panel"), view)
        return respond(200, svc.compute(q.get("lat"), q.get("lon"), q.get("date"), minutes, CACHE_DIR,
                                        view=view, layers=layers, now=q.get("now") in ("1", "true"), panel=panel))
    except svc.BadRequest as err:
        return respond(400, {"ok": False, "error": str(err)})
    except Exception as err:                                  # never leak a traceback to the visitor
        return respond(500, {"ok": False, "error": "Something went wrong on the server (%s)." % str(err)[:100]})


class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        status, headers, body = handle(parse_qs(urlparse(self.path).query))
        self.send_response(status)
        for k, v in headers.items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass
