"""Build public/index.html from src/page.html (adds the document wrapper).  Run:  python build.py"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
# Vercel Web Analytics for a plain HTML site: no npm needed. Turn Analytics on in the Vercel dashboard (Project > Analytics) and
# redeploy; the script is served by Vercel itself. It is only added to the built page (the claude.ai preview does not get it).
VA = ('<script>window.va = window.va || function () { (window.vaq = window.vaq || []).push(arguments); };</script>\n'
      '<script defer src="/_vercel/insights/script.js"></script>')
src = open(os.path.join(HERE, "src", "page.html"), encoding="utf-8").read()
head, body = src.split("<!--body-->", 1)
doc = ("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
       "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n"
       + head.strip() + "\n" + VA + "\n</head>\n<body>\n" + body.strip() + "\n</body>\n</html>\n")
with open(os.path.join(HERE, "public", "index.html"), "w", encoding="utf-8") as fh:
    fh.write(doc)
print("wrote public/index.html (%d bytes)" % len(doc))
