"""Tests for the web service layer, with offline stand-ins for NOAA (no network needed).

Run:  cd sunset_web && python -m unittest discover -s tests
"""
import base64
import datetime
import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "api", "_lib"))
sys.path.insert(0, os.path.join(HERE, "..", "api"))
# the offline mocks live with the engine's own tests
for cand in (HERE, os.path.join(HERE, "..", "..", "sunset_v1_1", "tests"), os.path.join(HERE, "..", "..", "tests"),
             "/home/claude/sunset_v1_1/tests"):
    if os.path.exists(os.path.join(cand, "mocks.py")):
        sys.path.insert(0, cand)
        break

import sunset_service as svc  # noqa: E402
import sunset_v1_1 as s  # noqa: E402
import sunset  # noqa: E402  (api/sunset.py)

try:
    import mocks  # noqa: E402
except ImportError:                                    # engine tests not next to the web app
    mocks = None

UTC = datetime.timezone.utc
WASH = (41.4278, -74.1654)
NOW = datetime.datetime(2026, 11, 6, 20, 40, tzinfo=UTC)


class TestParsing(unittest.TestCase):
    def test_minutes(self):
        self.assertEqual(svc.parse_minutes(None), [0])
        self.assertEqual(svc.parse_minutes("-45,-42,0"), [-45, -42, 0])
        self.assertEqual(svc.parse_minutes("3,3,3"), [3])
        for bad in ("1", "abc", "-48", "33", ",".join(str(x) for x in range(-45, -20, 3))):
            with self.assertRaises(svc.BadRequest):
                svc.parse_minutes(bad)

    def test_view_and_layers(self):
        self.assertEqual(svc.parse_view(None), "sunset")
        self.assertEqual(svc.parse_view("Reverse"), "reverse")
        with self.assertRaises(svc.BadRequest):
            svc.parse_view("sideways")
        self.assertIsNone(svc.parse_layers(None))
        self.assertIsNone(svc.parse_layers("all"))
        self.assertIsNone(svc.parse_layers("low,mid,high"))
        self.assertEqual(svc.parse_layers("high,low"), ("low", "high"))
        with self.assertRaises(svc.BadRequest):
            svc.parse_layers("low,cirrus")

    def test_place(self):
        self.assertEqual(svc.parse_place("41.42784", "-74.16543", "2026-11-06", NOW), (41.4278, -74.1654, "2026-11-06"))
        for args in (("x", "1", "2026-11-06"), ("41", "-74", "not-a-date"), ("95", "0", "2026-11-06"),
                     ("41", "-74", "2026-12-30"), ("41", "-74", "2026-10-01"), ("nan", "0", "2026-11-06")):
            with self.assertRaises(svc.BadRequest):
                svc.parse_place(*args, now_utc=NOW)

    def test_prune_removes_old_files_only(self):
        d = tempfile.mkdtemp()
        try:
            old, new = os.path.join(d, "old.nc"), os.path.join(d, "new.nc")
            for p in (old, new):
                open(p, "w").write("x")
            os.utime(old, (1000, 1000))
            svc.prune_cache(d, now=1000 + svc.CACHE_MAX_AGE_S + 5)
            self.assertFalse(os.path.exists(old))
            self.assertTrue(os.path.exists(new) or os.stat(new).st_mtime < 1000 + 5)
        finally:
            shutil.rmtree(d, ignore_errors=True)


@unittest.skipIf(mocks is None, "needs the engine's tests/mocks.py")
class TestCompute(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp()
        cls.az = s.sunset_azimuth(WASH[0], 2026, 11, 6)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def compute(self, minutes, use_sat=False, now=NOW, current=False, **kw):
        d = tempfile.mkdtemp(dir=self.tmp)
        ncss = mocks.MockNcss(WASH, mocks.bank_at(self.az, near=40, far=200, layer="low"))
        return svc.compute(WASH[0], WASH[1], "2026-11-06", minutes, cache_dir=os.path.join(d, "cache"), now_utc=now,
                           use_sat=use_sat, fetch_file=ncss, now=current, **kw)

    def test_every_view_draws_and_a_layer_filter_changes_the_picture(self):
        plain = self.compute([0])["frames"][0]
        for view in ("sunset", "data", "forecast", "reverse", "dome"):
            out = self.compute([0], view=view)
            f = out["frames"][0]
            self.assertIsNone(out.get("frame_error"), view)
            panel = view if view in ("reverse", "dome") else "ground"
            self.assertEqual((f["view"], f["layers"], f["now"], f["panel"]), (view if panel == "ground" else "sunset", None, False, panel))
            for kind in ("ground", "top"):
                if kind == "top" and panel != "ground":
                    self.assertNotIn("top", f)                       # reverse and dome come without a map
                    continue
                self.assertTrue(base64.b64decode(f[kind]).startswith(b"\x89PNG"))
        only = self.compute([0], layers=("high",))["frames"][0]
        self.assertEqual(only["layers"], ["high"])
        self.assertNotEqual(only["ground"], plain["ground"])
        self.assertNotEqual(self.compute([0], view="dome")["frames"][0]["ground"], plain["ground"])

    def test_panels_follow_the_view_and_the_layer_filter(self):
        base = {p: self.compute([0], panel=p)["frames"][0] for p in ("ground", "reverse", "dome")}
        self.assertEqual(len({base[p]["ground"] for p in base}), 3)             # three different pictures
        for p in ("reverse", "dome"):
            data = self.compute([0], panel=p, view="data")["frames"][0]
            self.assertEqual((data["panel"], data["view"]), (p, "data"))
            self.assertNotEqual(data["ground"], base[p]["ground"])              # data colours, not sunset colours
            high = self.compute([0], panel=p, layers=("high",))["frames"][0]
            self.assertEqual(high["layers"], ["high"])
            self.assertNotEqual(high["ground"], base[p]["ground"])
        with self.assertRaises(svc.BadRequest):
            svc.parse_panel("sideways")
        self.assertEqual(svc.parse_panel(None), ("ground", "sunset"))
        self.assertEqual(svc.parse_panel("reverse", "data"), ("reverse", "data"))
        self.assertEqual(svc.parse_panel(None, "dome"), ("dome", "sunset"))

    def test_satellite_view_needs_a_scan(self):
        with self.assertRaises(svc.BadRequest):
            self.compute([0], view="satellite")

    def test_the_current_sky_is_offered_near_sunset_and_drawn_at_now(self):
        out = self.compute([0])
        info = out["info"]["now"]
        self.assertTrue(info["available"])
        self.assertAlmostEqual(info["minutes"], -65.0, delta=1.0)           # 20:40 UTC against a 21:45 UTC sunset
        cur = self.compute([0], current=True)["frames"][0]
        self.assertTrue(cur["now"])
        self.assertAlmostEqual(cur["minutes"], info["minutes"], delta=0.2)
        late = datetime.datetime(2026, 11, 7, 20, 40, tzinfo=UTC)           # a day after the sunset asked about
        self.assertFalse(self.compute([0], now=late)["info"]["now"]["available"])
        with self.assertRaises(svc.BadRequest):
            self.compute([0], now=late, current=True)

    def test_forecast_only_returns_score_and_frames(self):
        out = self.compute([-30, 0, 15])
        self.assertTrue(out["ok"])
        info = out["info"]
        self.assertTrue(0 <= info["score"] <= 100)
        self.assertEqual(info["sunset_local"], "16:45")
        self.assertIn("report", info)
        self.assertEqual([f["minutes"] for f in out["frames"]], [-30, 0, 15])
        for f in out["frames"]:
            for kind in ("ground", "top"):
                self.assertTrue(base64.b64decode(f[kind]).startswith(b"\x89PNG"))
        self.assertGreater(out["frames"][0]["sun_elevation"], out["frames"][2]["sun_elevation"])
        self.assertIsNone(out["warning"])
        json.dumps(out)                                   # must be serialisable

    def test_open_meteo_fallback_still_draws_frames(self):
        d = tempfile.mkdtemp(dir=self.tmp)
        om = mocks.MockOpenMeteo(WASH, mocks.bank_at(self.az, near=40, far=200, layer="low"))
        out = svc.compute(WASH[0], WASH[1], "2026-11-06", [-30, 0], cache_dir=d, now_utc=NOW,
                          use_sat=False, source="openmeteo", fetch_json=om)
        self.assertTrue(out["ok"])
        self.assertEqual(out["info"]["source"], "Open-Meteo")
        self.assertEqual(len(out["frames"]), 2)

    def test_outside_new_york_gets_a_warning(self):
        d = tempfile.mkdtemp(dir=self.tmp)
        ncss = mocks.MockNcss((34.05, -118.24), mocks.bank_at(250.0, near=40, far=200, layer="low"))
        out = svc.compute(34.05, -118.24, "2026-11-06", [0], cache_dir=os.path.join(d, "cache"), now_utc=NOW,
                          use_sat=False, fetch_file=ncss)
        self.assertTrue(out["ok"])
        self.assertIn("New York", out["warning"])

    def test_response_size_cap_defers_frames(self):
        old = svc.MAX_RESPONSE_BYTES
        svc.MAX_RESPONSE_BYTES = 1000
        try:
            out = self.compute([-30, 0, 15])
        finally:
            svc.MAX_RESPONSE_BYTES = old
        self.assertEqual(len(out["frames"]), 1)
        self.assertEqual(out["pending"], [0, 15])

    def test_api_handler_paths(self):
        status, _, body = sunset.handle({"ping": ["1"]})
        self.assertEqual(status, 200)
        self.assertTrue(json.loads(body)["pong"])
        status, headers, body = sunset.handle({"lat": ["abc"], "lon": ["-74"], "date": ["2026-11-06"]})
        self.assertEqual(status, 400)
        self.assertFalse(json.loads(body)["ok"])
        self.assertEqual(headers["Cache-Control"], "no-store")
        status, _, body = sunset.handle({"lat": ["41.4"], "lon": ["-74.1"], "date": ["2026-11-06"], "minutes": ["7"]})
        self.assertEqual(status, 400)
        for bad in ({"view": ["sideways"]}, {"layers": ["low,cirrus"]}, {"panel": ["sideways"]}):
            q = {"lat": ["41.4"], "lon": ["-74.1"], "date": ["2026-11-06"]}
            q.update(bad)
            status, _, body = sunset.handle(q)
            self.assertEqual(status, 400)
            self.assertFalse(json.loads(body)["ok"])


if __name__ == "__main__":
    unittest.main()
