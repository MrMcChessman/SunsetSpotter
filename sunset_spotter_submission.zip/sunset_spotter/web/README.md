# Sunset Spotter web app

A page where you enter a place and a date, get the 0 to 100 sunset score with reasons, and drag a
slider through the sunset: ground view and top-down map move together (sun path, Earth shadow,
clouds drifting on the real winds).

```
public/index.html      the page (built from src/page.html by build.py)
public/demo/wash/      historical example: Washingtonville NY, Nov 6 2026 (26 frames, every view and filter, demo.json)
public/demo/troy/      historical example: Troy NY, Nov 7 2026 (same files)
api/sunset.py          the server function:  GET /api/sunset?lat=..&lon=..&date=YYYY-MM-DD&minutes=-45,-42
                       optional: &view=sunset|data|forecast|satellite  &panel=ground|reverse|dome  &layers=low,mid,high  &now=1 (the sky right now)
                       (reverse and dome frames carry only their own picture, no top-down map)
api/_lib/              the engine (sunset_v1_1.py, sunset_motion.py) and sunset_service.py (glue)
server.py              run everything on your own computer
vercel.json            gives the function up to 300 s
requirements.txt       numpy, netCDF4
tests/test_service.py  offline tests (no network needed)
```

## 1. Run it on your computer (do this first; it is the real test of the live NOAA/GOES fetch)

```
pip install numpy netCDF4
python server.py
```

Open http://localhost:8000. The saved example shows immediately. Press **Calculate** for a live
run: the score appears after the downloads finish (10 to 30 s), then the 26 slider frames fill in
(about 30 s more). The first live run downloads the forecast and the satellite scan into `cache/`.

Satellite pictures are only used when the sunset is within 3 hours. For a date further out the page
says so and uses the forecast alone.

## 2. Put it on the internet with Vercel (free Hobby plan)

1. Make a free account at vercel.com and a free account at github.com.
2. Create a new GitHub repository and upload this whole folder to it (the `sunset_web` contents at the top level, so `api/`, `public/`, `vercel.json` sit in the repo root).
3. In Vercel choose **Add New > Project**, import that repository, leave every setting at its default, press **Deploy**.
4. Vercel installs `numpy` and `netCDF4` from `requirements.txt`, publishes `public/` as the site and `api/sunset.py` as the server function.

Or skip GitHub: install Node, then run `vercel --prod` (Windows: `vercel.cmd --prod`) from this folder. `.vercelignore` keeps `server.py`, `cache`, `tests` and `src` out of the upload.

Things to know:
- The function may take up to 300 s (the Hobby maximum). If Vercel refuses the setting, lower `maxDuration` in `vercel.json` to 60.
- Each request answers with a few frames (4.5 MB response limit). The page asks for them in four parallel groups.
- Downloads are cached in `/tmp` on the server for 6 hours; a fresh server instance downloads again.
- The Hobby plan is for non-commercial use. Check Vercel's current limits before sharing the link widely.
- If a live run fails on the server, the saved example still works.

## 3. Change the page or the engine

- Edit `src/page.html`, then run `python build.py` to rebuild `public/index.html`.
- The engine files in `api/_lib/` are copies. If you edit `sunset_v1_1.py` or `sunset_motion.py` elsewhere, copy them over.
- Tests: `python -m unittest discover -s tests` (they need the engine's `tests/mocks.py`, found in `../sunset_v1_1/tests`, `../tests`, or this folder's parent).

## Four views at sunset, source and cloud filters, the current sky, historical examples

At sunset the page shows four pictures: Forward (toward the sunset), Top-down (the regions the score reads), Reverse
(facing away: front-lit cloud, the Earth's shadow, the Belt of Venus) and Overhead (a straight-up fisheye, north up,
east left). Slide away from sunset and Reverse and Overhead fade out; come back and they return. The source buttons
(Sunset, Data, Forecast only, Satellite only) and the cloud-height buttons (All, Low, Mid, High) change all four
pictures together. Current sky shows the forward view and map at this moment (only today, within 3 hours of sunset; the button is greyed out otherwise). Data and Satellite-only are greyed out when no satellite scan covers the query, because Data then equals Forecast. The reverse and overhead views wait about 0.7 s before appearing while the slider plays or scrubs, so they don't flicker. Cloud-square borders and grid lines are only drawn for squares with real substance (low/mid layers from about 17% cover, high layer from about 33%).
Each Reverse or Overhead picture is one extra request (`panel=reverse|dome`), about 3 to 6 seconds, cached by the
page afterwards. The two **Historical examples** buttons load saved sunsets with satellite data; they ship every
picture as a file: `g_/t_<source>_<layers>.png` (forward and map), `r_...` (reverse), `d_...` (overhead), `now_*.png`.
The "How the hard parts got solved" section and the Shoutouts collage at the bottom of `src/page.html` are meant to be
edited; the Shoutouts photos live in `public/photos/` (monsters, doppler, gascalc, claude, family-1, family-2).

## Known limits

- Tuned for New York (Eastern time). Elsewhere the page shows a warning.
- The slider's lighting colours are a physical estimate that has not been checked against photographs.
- During the slider the sun-visibility factor stays at its sunset value; only the lighting and cloud positions change.
- Only the sunset view gets the slider; other pictures are single frames from the command-line tool.

## Vercel Web Analytics (no npm needed)
`build.py` adds Vercel's two-line script to the built `public/index.html` only. Turn it on in the Vercel dashboard (project > Analytics > Enable), then redeploy with `vercel --prod`. The numbers appear after the first visits.
